/* CyberDex backend UI: login, assistant, announcement, report form. Inactive unless config.js is filled. */
(function () {
  'use strict';
  var C = window.CDX_CONFIG || {};
  if (!C.SUPABASE_URL || !C.SUPABASE_ANON_KEY) return;
  var me = document.currentScript, base = me ? new URL('../../', me.src).href : '';
  var sb = null, session = null, profile = null, profLoaded = false;

  function el(tag, attrs, kids) {
    var n = document.createElement(tag);
    for (var k in (attrs || {})) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); }
    (kids || []).forEach(function (c) { if (c) n.appendChild(c); });
    return n;
  }
  function ar(e) {
    var m = String((e && e.message) || e || '');
    if (/invalid login/i.test(m)) return 'البريد أو كلمة المرور غير صحيحة.';
    if (/already registered|already been registered/i.test(m)) return 'هذا البريد مسجّل بالفعل، جرّب تسجيل الدخول.';
    if (/password.*(short|least|weak)/i.test(m)) return 'كلمة المرور ضعيفة: استخدم 8 أحرف على الأقل.';
    if (/registration_closed|database error saving new user/i.test(m)) return 'التسجيل الجديد مغلق مؤقتًا.';
    if (/rate|too many/i.test(m)) return 'محاولات كثيرة، انتظر قليلًا ثم أعد المحاولة.';
    if (/confirm/i.test(m)) return 'فعّل بريدك أولًا من الرسالة التي وصلتك.';
    return 'حدث خطأ. حاول مرة أخرى.';
  }

  // ---------- modal
  var modal;
  function openAuth(msg) {
    closeAuth();
    var mode = 'login';
    var email = el('input', { type: 'email', placeholder: 'البريد الإلكتروني', autocomplete: 'email', required: '', dir: 'ltr' });
    var pass = el('input', { type: 'password', placeholder: 'كلمة المرور (8 أحرف على الأقل)', autocomplete: 'current-password', required: '', minlength: '8', dir: 'ltr' });
    var note = el('p', { class: 'cdx-note', text: msg || '' });
    var go = el('button', { class: 'btn cdx-go', type: 'submit', text: 'دخول' });
    var tabL = el('button', { type: 'button', class: 'on', text: 'تسجيل الدخول' });
    var tabR = el('button', { type: 'button', text: 'حساب جديد' });
    var forgot = el('button', { type: 'button', class: 'cdx-link', text: 'نسيت كلمة المرور؟' });
    function setMode(m) { mode = m; tabL.className = m === 'login' ? 'on' : ''; tabR.className = m === 'reg' ? 'on' : ''; go.textContent = m === 'login' ? 'دخول' : 'إنشاء الحساب'; go.disabled = (m === 'reg' && FLAGS.reg === false); pass.setAttribute('autocomplete', m === 'login' ? 'current-password' : 'new-password'); forgot.style.display = m === 'login' ? '' : 'none'; note.textContent = (m === 'reg' && FLAGS.reg === false) ? 'التسجيل الجديد مغلق مؤقتًا. يمكنك تسجيل الدخول إن كان لديك حساب.' : ''; }
    tabL.onclick = function () { setMode('login'); }; tabR.onclick = function () { setMode('reg'); };
    forgot.onclick = function () {
      if (!email.value) { note.textContent = 'اكتب بريدك أولًا ثم اضغط "نسيت كلمة المرور".'; return; }
      sb.auth.resetPasswordForEmail(email.value, { redirectTo: location.origin + location.pathname }).then(function () { note.textContent = 'إن كان البريد مسجّلًا ستصلك رسالة لإعادة التعيين.'; });
    };
    var form = el('form', { class: 'cdx-form' }, [email, pass, go, forgot, note]);
    form.onsubmit = function (ev) {
      ev.preventDefault(); go.disabled = true; note.textContent = '';
      var p = mode === 'login' ? sb.auth.signInWithPassword({ email: email.value.trim(), password: pass.value }) : sb.auth.signUp({ email: email.value.trim(), password: pass.value });
      p.then(function (r) {
        go.disabled = false;
        if (r.error) { note.textContent = ar(r.error); return; }
        if (mode === 'reg' && !r.data.session) { note.textContent = 'تم إنشاء الحساب. افتح بريدك واضغط رابط التفعيل ثم سجّل الدخول.'; return; }
        closeAuth();
      }, function () { go.disabled = false; note.textContent = 'تعذّر الاتصال، حاول لاحقًا.'; });
    };
    var box = el('div', { class: 'cdx-box', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'تسجيل الدخول' }, [
      el('button', { class: 'cdx-x', type: 'button', 'aria-label': 'إغلاق', text: '×' }),
      el('h3', { text: 'حسابك في CyberDex' }),
      el('p', { class: 'cdx-sub', text: 'الحساب مجاني ويفتح لك المساعد الذكي وإرسال الملاحظات.' }),
      el('div', { class: 'cdx-tabs' }, [tabL, tabR]), form]);
    box.querySelector('.cdx-x').onclick = closeAuth;
    modal = el('div', { class: 'cdx-overlay' }, [box]);
    modal.addEventListener('click', function (e) { if (e.target === modal) closeAuth(); });
    document.addEventListener('keydown', escClose);
    document.body.appendChild(modal); email.focus();
  }
  function escClose(e) { if (e.key === 'Escape') closeAuth(); }
  function closeAuth() { if (modal) { modal.remove(); modal = null; document.removeEventListener('keydown', escClose); } }

  // ---------- user menu
  var slot, menuBtn;
  function renderUser() {
    if (!slot) return;
    slot.textContent = '';
    if (!session) { slot.appendChild(el('button', { class: 'btn sm', type: 'button', text: 'دخول' })).onclick = function () { openAuth(); }; return; }
    var b = el('button', { class: 'btn sm cdx-me', type: 'button', text: 'حسابي ▾', 'aria-expanded': 'false' });
    var m = el('div', { class: 'cdx-menu', hidden: '' }, [el('div', { class: 'cdx-mail', text: session.user.email || '' })]);
    if (profile && profile.role === 'admin') m.appendChild(el('a', { href: base + 'admin.html', text: 'لوحة الإدارة' }));
    m.appendChild(el('a', { href: base + 'profile.html', text: 'ملفي العام' }));
    var out = el('button', { type: 'button', text: 'تسجيل الخروج' }); out.onclick = function () { sb.auth.signOut(); };
    m.appendChild(out);
    var del = el('button', { type: 'button', class: 'cdx-danger', text: 'حذف حسابي' }); del.onclick = openDelete; m.appendChild(del);
    b.onclick = function (e) { e.stopPropagation(); var h = m.hasAttribute('hidden'); if (h) m.removeAttribute('hidden'); else m.setAttribute('hidden', ''); b.setAttribute('aria-expanded', String(h)); };
    document.addEventListener('click', function () { m.setAttribute('hidden', ''); b.setAttribute('aria-expanded', 'false'); });
    slot.appendChild(b); slot.appendChild(m);
  }
  function loadProfile() {
    if (!session) { profile = null; profLoaded = true; renderUser(); try { document.dispatchEvent(new CustomEvent('cdx-profile')); } catch (e) {} return Promise.resolve(); }
    return sb.from('profiles').select('role,banned').eq('id', session.user.id).maybeSingle().then(function (r) { profile = r.data; profLoaded = true; renderUser(); try { document.dispatchEvent(new CustomEvent('cdx-profile')); } catch (e) {} });
  }

  // ---------- delete my account (immediate and permanent)
  var CONFIRM_WORD = 'حذف';
  function openDelete() {
    if (!session) return; closeAuth();
    var typed = el('input', { type: 'text', placeholder: 'اكتب: ' + CONFIRM_WORD, autocomplete: 'off', 'aria-label': 'تأكيد الحذف' });
    var wipe = el('input', { type: 'checkbox' });
    var note = el('p', { class: 'cdx-note', text: '' });
    var go = el('button', { class: 'btn cdx-go cdx-danger-btn', type: 'submit', text: 'احذف حسابي نهائيًا' }); go.disabled = true;
    typed.oninput = function () { go.disabled = typed.value.trim() !== CONFIRM_WORD; };
    var form = el('form', { class: 'cdx-form' }, [typed, el('label', { class: 'cdx-chk' }, [wipe, el('span', { text: 'امسح أيضًا التقدّم المحفوظ على هذا الجهاز' })]), go, note]);
    form.onsubmit = function (ev) {
      ev.preventDefault(); if (typed.value.trim() !== CONFIRM_WORD) return;
      go.disabled = true; note.textContent = 'جارٍ الحذف…';
      sb.rpc('delete_my_account').then(function (r) {
        if (r.error || !r.data) { go.disabled = false; note.textContent = 'تعذّر الحذف الآن. حاول لاحقًا.'; return; }
        if (r.data === 'last_admin') { go.disabled = false; note.textContent = 'أنت الأدمن الوحيد. رقِّ أدمن آخر أولًا ثم احذف حسابك.'; return; }
        if (r.data !== 'ok') { go.disabled = false; note.textContent = 'تعذّر الحذف.'; return; }
        if (wipe.checked) { try { Object.keys(localStorage).forEach(function (k) { if (/^cdx/i.test(k)) localStorage.removeItem(k); }); } catch (e) {} }
        try { sb.auth.signOut({ scope: 'local' }); } catch (e) {}
        var ok = el('button', { class: 'btn', type: 'button', text: 'تم' });
        ok.onclick = function () { location.href = base + 'index.html'; };
        clear2(); box.appendChild(el('h3', { text: 'تم حذف حسابك' }));
        box.appendChild(el('p', { class: 'cdx-sub', text: 'حُذفت بياناتك من الخادم نهائيًا: البريد والتقدّم والشهادات وصفّك في لوحة المتصدرين ورسائلك. ' + (wipe.checked ? 'ومُسح التقدّم المحفوظ على هذا الجهاز.' : 'التقدّم المحفوظ على هذا الجهاز ما زال موجودًا في متصفحك، ويمكنك مسحه من إعدادات المتصفح.') }));
        box.appendChild(ok);
      }, function () { go.disabled = false; note.textContent = 'تعذّر الاتصال، حاول لاحقًا.'; });
    };
    var box = el('div', { class: 'cdx-box', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'حذف الحساب' }, [
      el('button', { class: 'cdx-x', type: 'button', 'aria-label': 'إغلاق', text: '×' }),
      el('h3', { text: 'حذف حسابك نهائيًا' }),
      el('p', { class: 'cdx-sub', text: 'الحذف فوري ولا يمكن التراجع عنه. سيُحذف من الخادم: بريدك وكلمة المرور والتقدّم المنسوخ والشهادات المحفوظة (يتعذّر التحقق منها بعد ذلك) وصفّك في لوحة المتصدرين ورسائلك.' }),
      form]);
    function clear2() { while (box.firstChild) box.removeChild(box.firstChild); }
    box.querySelector('.cdx-x').onclick = closeAuth;
    modal = el('div', { class: 'cdx-overlay' }, [box]);
    modal.addEventListener('click', function (e) { if (e.target === modal) closeAuth(); });
    document.addEventListener('keydown', escClose);
    document.body.appendChild(modal); typed.focus();
  }

  // ---------- site switches set by the admin: maintenance banner, features on/off, registration
  var FLAGS = { features: {}, reg: true };
  var PAGE_FEATURE = { 'lab.html': 'lab', 'exams.html': 'exams', 'leaderboard.html': 'leaderboard' };
  function flags() {
    sb.from('settings').select('key,value').in('key', ['features', 'maintenance', 'registration_open']).then(function (r) {
      var cur = {}; (r.data || []).forEach(function (x) { cur[x.key] = x.value; });
      FLAGS.features = cur.features && typeof cur.features === 'object' ? cur.features : {};
      FLAGS.reg = cur.registration_open !== false;
      window.CDX_FLAGS = FLAGS;
      try { document.dispatchEvent(new CustomEvent('cdx-flags', { detail: FLAGS })); } catch (e) {}
      var isAdmin = function () { return profile && profile.role === 'admin'; };
      var mt = cur.maintenance;
      var apply = function () {
        if (!profLoaded) return;
        var old = document.querySelector('.cdx-maint'); if (old) old.remove();
        if (mt && mt.active && !isAdmin()) document.body.insertBefore(el('div', { class: 'cdx-ann cdx-maint', role: 'status', text: mt.text || 'الموقع في وضع الصيانة مؤقتًا. بعض الميزات قد لا تعمل.' }), document.body.firstChild);
        var pg = location.pathname.split('/').pop() || 'index.html', f = PAGE_FEATURE[pg];
        var main = document.getElementById('main');
        if (f && FLAGS.features[f] === false && main && !main.dataset.cdxOff) {
          if (isAdmin()) { main.insertBefore(el('div', { class: 'cdx-ann', text: 'هذه الميزة متوقفة للزوار، وتظهر لك لأنك أدمن.' }), main.firstChild); main.dataset.cdxOff = 'admin'; return; }
          main.dataset.cdxOff = '1'; main.textContent = '';
          main.appendChild(el('div', { class: 'wrap' }, [el('div', { class: 'page-hero' }, [el('h1', { text: 'هذه الميزة متوقفة مؤقتًا' })]), el('p', { class: 'cdx-sub', text: 'نعمل على تحسينها وسنعيدها قريبًا. يمكنك متابعة تصفّح باقي الموقع.' }), el('a', { class: 'btn', href: base + 'index.html', text: 'العودة للرئيسية' })]));
        }
      };
      apply(); document.addEventListener('cdx-profile', apply);
    });
  }

  // ---------- announcement
  function announce() {
    sb.from('settings').select('value').eq('key', 'announcement').maybeSingle().then(function (r) {
      var v = r.data && r.data.value; if (!v || !v.active || !v.text) return;
      var key = 'cdx-ann:' + v.text; try { if (sessionStorage.getItem(key)) return; } catch (e) {}
      var x = el('button', { type: 'button', 'aria-label': 'إخفاء', text: '×' });
      var bar = el('div', { class: 'cdx-ann', role: 'status' }, [el('span', { text: v.text }), x]);
      x.onclick = function () { bar.remove(); try { sessionStorage.setItem(key, '1'); } catch (e) {} };
      document.body.insertBefore(bar, document.body.firstChild);
    });
  }

  // ---------- assistant
  var panel, log, input, left;
  function say(role, text, sources) {
    var b = el('div', { class: 'cdx-msg ' + role }, [el('div', { text: text })]);
    if (sources && sources.length) {
      var s = el('div', { class: 'cdx-src' }, [el('span', { text: 'من الموقع: ' })]);
      sources.forEach(function (x) { if (/^(tools\/[a-z0-9-]+\.html|glossary\.html#[a-z0-9-]+)$/.test(x.url)) s.appendChild(el('a', { href: base + x.url, text: x.title })); });
      b.appendChild(s);
    }
    log.appendChild(b); log.scrollTop = log.scrollHeight; return b;
  }
  function demoAnswer(q) { // preview only (C.DEMO): plain local search, no AI, no server
    return fetch(base + 'assets/tools.json').then(function (r) { return r.json(); }).then(function (tools) {
      var w = q.toLowerCase().split(/\s+/).filter(function (x) { return x.length > 1; });
      var best = tools.map(function (t) { var h = (t.name + ' ' + t.short + ' ' + t.purpose).toLowerCase(), n = t.name.toLowerCase(), sc = 0; w.forEach(function (x) { if (n.indexOf(x) > -1) sc += 5; if (h.indexOf(x) > -1) sc += 1; }); return { t: t, s: sc }; }).filter(function (x) { return x.s >= 2; }).sort(function (a, b) { return b.s - a.s; }).slice(0, 3);
      if (!best.length) return { answer: 'لم أجد هذا في محتوى الموقع. جرّب البحث في صفحة الأدوات أو القاموس.', sources: [], remaining: 7 };
      return { answer: '[نسخة تجريبية بدون ذكاء اصطناعي]\n' + best[0].t.name + ': ' + best[0].t.purpose, sources: best.map(function (x) { return { title: x.t.name, url: 'tools/' + x.t.id + '.html' }; }), remaining: 7 };
    });
  }
  function ask(q) {
    var wait = say('bot', 'جارٍ البحث في الموقع…'); input.disabled = true;
    if (C.DEMO) { demoAnswer(q).then(function (d) { wait.remove(); say('bot', d.answer, d.sources); left.textContent = 'متبقّي لك اليوم: ' + d.remaining; input.disabled = false; input.focus(); }); return; }
    fetch(C.SUPABASE_URL + '/functions/v1/assistant', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + session.access_token },
      body: JSON.stringify({ question: q })
    }).then(function (r) { return r.json().catch(function () { return {}; }); }).then(function (d) {
      wait.remove();
      if (d.answer) { say('bot', d.answer, d.sources); } else { say('bot', d.message || 'حدث خطأ، حاول لاحقًا.'); }
      if (typeof d.remaining === 'number') left.textContent = 'متبقّي لك اليوم: ' + d.remaining;
    }).catch(function () { wait.remove(); say('bot', 'تعذّر الاتصال بالمساعد.'); }).then(function () { input.disabled = false; input.focus(); });
  }
  function buildAssistant() {
    var fab = el('button', { class: 'cdx-fab', type: 'button', 'aria-label': 'مساعد CyberDex', text: '💬 اسأل المساعد' });
    log = el('div', { class: 'cdx-log', 'aria-live': 'polite' });
    input = el('input', { type: 'text', maxlength: '400', placeholder: 'اسأل عن أداة أو مصطلح…', 'aria-label': 'سؤالك' });
    left = el('div', { class: 'cdx-left' });
    var send = el('button', { class: 'btn sm', type: 'submit', text: 'إرسال' });
    var form = el('form', { class: 'cdx-ask' }, [input, send]);
    var close = el('button', { class: 'cdx-x', type: 'button', 'aria-label': 'إغلاق', text: '×' });
    panel = el('section', { class: 'cdx-panel', hidden: '', 'aria-label': 'المساعد' }, [
      close, el('h4', { text: 'مساعد CyberDex' }), el('p', { class: 'cdx-sub', text: 'يجيب من محتوى الموقع فقط (أدوات وقاموس).' }), log, form, left]);
    say('bot', 'أهلًا! اسألني مثلًا: "يعني إيه DNS؟" أو "أستخدم Nmap إزاي؟"');
    fab.onclick = function () { if (!session) { openAuth('سجّل الدخول لاستخدام المساعد.'); return; } panel.removeAttribute('hidden'); input.focus(); };
    close.onclick = function () { panel.setAttribute('hidden', ''); };
    form.onsubmit = function (e) { e.preventDefault(); var q = input.value.trim(); if (q.length < 2) return; say('me', q); input.value = ''; ask(q); };
    document.body.appendChild(fab); document.body.appendChild(panel);
    sb.from('settings').select('value').eq('key', 'assistant_enabled').maybeSingle().then(function (r) { if (r.data && r.data.value === false) fab.remove(); });
  }

  // ---------- report form (contact page)
  function wireReport() {
    var f = document.getElementById('reportForm'); if (!f) return;
    f.removeAttribute('hidden');
    var st = f.querySelector('.cdx-note');
    f.onsubmit = function (e) {
      e.preventDefault();
      if (!session) { openAuth('سجّل الدخول لإرسال رسالتك.'); return; }
      var body = f.elements.body.value.trim();
      if (body.length < 5) { st.textContent = 'اكتب رسالة أطول قليلًا.'; return; }
      st.textContent = 'جارٍ الإرسال…';
      sb.from('messages').insert({ user_id: session.user.id, email: session.user.email, kind: f.elements.kind.value, page: (f.elements.page.value || '').slice(0, 300) || null, body: body })
        .then(function (r) { if (r.error) { st.textContent = 'تعذّر الإرسال: قد يكون حسابك غير مسموح له.'; } else { f.reset(); st.textContent = 'وصلتنا رسالتك، شكرًا لك.'; } });
    };
  }

  // ---------- anonymous page-view counter: sends only the page path (no id, no cookie, no IP stored). Honors Do Not Track.
  function trackView() {
    try {
      if (C.DEMO || navigator.doNotTrack === '1' || window.doNotTrack === '1' || /^(localhost|127\.)/.test(location.hostname)) return;
      if (localStorage.getItem('cdx-owner') === '1') return;
      var root = new URL(base).pathname, rel = location.pathname.indexOf(root) === 0 ? location.pathname.slice(root.length) : location.pathname.replace(/^\//, '');
      if (!rel || /\/$/.test(rel)) rel += 'index.html';
      var k = 'cdx-v:' + rel; if (sessionStorage.getItem(k)) return; sessionStorage.setItem(k, '1');
      var fresh = !sessionStorage.getItem('cdx-sess'); if (fresh) sessionStorage.setItem('cdx-sess', '1');
      Promise.resolve(sb.rpc('track_view', { p_page: rel.toLowerCase(), p_new: fresh })).catch(function () {});
    } catch (e) {}
  }

  // ---------- boot
  (C.DEMO ? import(base + 'assets/js/demo-sb.js') : import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/+esm')).then(function (m) {
    sb = m.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true } });
    var acts = document.querySelector('.top-actions');
    if (acts) { slot = el('div', { class: 'cdx-user' }); acts.insertBefore(slot, acts.firstChild); }
    window.CDX_SB = sb;
    sb.auth.getSession().then(function (r) { session = r.data.session; window.CDX_SESSION = session; try { document.dispatchEvent(new CustomEvent('cdx-auth', { detail: session })); } catch (e) {} return loadProfile(); });
    sb.auth.onAuthStateChange(function (ev, s) { session = s; window.CDX_SESSION = s; try { document.dispatchEvent(new CustomEvent('cdx-auth', { detail: s })); } catch (e) {} loadProfile(); if (ev === 'SIGNED_IN') closeAuth(); });
    if (C.DEMO) document.body.insertBefore(el('div', { class: 'cdx-ann', style: 'background:rgba(245,184,75,.15)', text: 'وضع تجريبي للمعاينة: خادم وهمي وبيانات مزيفة، لا يوجد حساب حقيقي ولا ذكاء اصطناعي.' }), document.body.firstChild);
    trackView(); buildAssistant(); announce(); flags(); wireReport(); renderUser();
  }).catch(function () { /* CDN unreachable: site stays fully usable without accounts */ });
})();
