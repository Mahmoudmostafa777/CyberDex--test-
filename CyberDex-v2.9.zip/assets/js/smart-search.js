// CyberDex smart search: Arabic-aware matching, synonyms in Arabic and English, tool-name transliteration,
// typo correction and relevance ranking. Pure logic (no DOM) so it runs in the page and in tests.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(); else root.CDXS = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ---------- normalisation (same letters folded on both the query and the data)
  function norm(s) {
    return String(s == null ? '' : s).toLowerCase()
      .replace(/[ً-ْٰـ]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي')
      .replace(/[٠-٩]/g, function (d) { return '٠١٢٣٤٥٦٧٨٩'.indexOf(d); })
      .replace(/[^a-z0-9ء-ي\s\-\._+#]/g, ' ')
      .replace(/\s+/g, ' ').trim();
  }
  var STOP = {};
  ('اريد عايز عاوز ان عن من في علي هل كيف ازاي ما ماذا هو هي و او الي ده دي اداه ادوات برنامج برامج لو فيه عندي ممكن انا اعمل اعرف ابحث ابغي ' +
    'tool tools how to the a an for of with using use what is best which i want need me my').split(' ').forEach(function (w) { STOP[w] = 1; });

  var PRE = ['وال', 'بال', 'كال', 'فال', 'لل', 'ال', 'ل', 'و', 'ب', 'ف'], SUF = ['ات', 'ان', 'ين', 'ون', 'ها', 'يه', 'ه', 'ي'];
  function stems(t) {
    var out = [t]; if (!/[ء-ي]/.test(t)) return out;
    var b = t;
    for (var i = 0; i < PRE.length; i++) { var p = PRE[i]; if (t.indexOf(p) === 0 && t.length - p.length >= (p.length === 1 ? 4 : 3)) { b = t.slice(p.length); break; } }
    if (b !== t) out.push(b);
    SUF.forEach(function (s) { if (b.length - s.length >= 3 && b.slice(-s.length) === s) { var x = b.slice(0, -s.length); if (out.indexOf(x) < 0) out.push(x); } });
    return out;
  }

  // ---------- synonyms: any term in a group expands to the whole group
  var GROUPS = [
    // tool names written in Arabic letters
    ['nmap', 'نماب', 'انماب', 'نمب', 'ان ماب'], ['wireshark', 'وايرشارك', 'وايرشرك', 'ويرشارك'], ['burp', 'بيرب', 'برب', 'burp suite', 'بيرب سويت'],
    ['metasploit', 'ميتاسبلويت', 'ميتاسبلوت', 'ميتاسبلويت فريمورك', 'msf'], ['hydra', 'هيدرا'], ['john', 'جون', 'john the ripper', 'جون ذا ريبر'],
    ['hashcat', 'هاشكات', 'هاش كات'], ['sqlmap', 'اس كيو ال ماب', 'اسكيوالماب'], ['aircrack', 'ايركراك', 'اير كراك', 'aircrack-ng'],
    ['tcpdump', 'تي سي بي دمب'], ['nikto', 'نيكتو'], ['netcat', 'نيتكات', 'nc', 'ncat'], ['gobuster', 'جوباستر'], ['ghidra', 'جيدرا', 'غيدرا'],
    ['autopsy', 'اوتوبسي'], ['volatility', 'فولاتيليتي'], ['zap', 'زاب', 'owasp zap'], ['openssl', 'اوبن اس اس ال'], ['wpscan', 'دبليو بي سكان'],
    ['fail2ban', 'فيل تو بان'], ['docker', 'دوكر', 'دوكير'], ['git', 'جيت'], ['openvpn', 'اوبن في بي ان'], ['wireguard', 'وايرجارد'],
    ['traceroute', 'تريسروت', 'tracert'], ['whois', 'هو اس'], ['gpg', 'جي بي جي', 'pgp'], ['yara', 'يارا'], ['snort', 'سنورت'], ['suricata', 'سوريكاتا'],
    ['bettercap', 'بيتركاب'], ['masscan', 'ماسكان'], ['strings', 'سترينجز'], ['binwalk', 'بينوك'], ['foremost', 'فورموست'], ['lynis', 'لينيس'],
    ['nuclei', 'نوكلاي'], ['trivy', 'تريفي'], ['tmux', 'تي ماكس'], ['rsync', 'ار سنك'], ['crunch', 'كرنش'], ['ufw', 'يو اف دبليو'],
    ['iptables', 'ايب تيبلز'], ['cron', 'كرون', 'crontab'], ['sudo', 'سودو'], ['chmod', 'تشمود'], ['systemctl', 'سيستم سي تي ال', 'systemd'],
    ['veracrypt', 'فيراكربت'], ['grep', 'جريب'], ['curl', 'كيرل'], ['ping', 'بينج', 'بنج'], ['dig', 'ديج'], ['kali', 'كالي', 'kali linux', 'كالي لينكس'],
    ['linux', 'لينكس', 'لينوكس'], ['ssh', 'اس اس اتش', 'secure shell'], ['wireshark', 'tshark'],
    ['--concepts--'],
    // concepts
    ['كلمه سر', 'كلمات سر', 'كلمه المرور', 'كلمات المرور', 'كلمه السر', 'كلمات السر', 'باسورد', 'باسوورد', 'بسورد', 'password', 'passwords', 'passwd', 'رمز الدخول', 'credentials'],
    ['كسر', 'اكسر', 'كسر الباسورد', 'crack', 'cracking', 'brute', 'brute force', 'تخمين', 'هجوم القاموس', 'dictionary attack', 'wordlist', 'قائمه كلمات'],
    ['هاش', 'hash', 'hashes', 'بصمه', 'تجزئه', 'تجزئات', 'checksum', 'digest', 'sha256', 'md5', 'sha1'],
    ['تشفير', 'encryption', 'encrypt', 'تعميه', 'cipher', 'crypto', 'كريبتو', 'فك التشفير', 'decrypt', 'decryption'],
    ['شبكه', 'شبكات', 'network', 'networks', 'نتورك', 'نيتورك', 'networking'],
    ['فحص', 'افحص', 'امسح', 'مسح', 'scan', 'scanner', 'scanning', 'سكان', 'سكانر', 'استكشاف', 'اكتشاف', 'discover', 'discovery', 'enumeration', 'تعداد'],
    ['منفذ', 'منافذ', 'port', 'ports', 'بورت', 'بورتات'],
    ['ثغره', 'ثغرات', 'vulnerability', 'vulnerabilities', 'vuln', 'exploit', 'exploits', 'استغلال', 'cve', 'اختراق', 'penetration', 'pentest', 'pen test', 'اختبار الاختراق'],
    ['ويب', 'web', 'موقع', 'مواقع', 'website', 'تطبيقات الويب', 'webapp', 'http', 'https'],
    ['حقن', 'injection', 'sql injection', 'sqli', 'xss', 'قواعد البيانات', 'قاعده بيانات', 'database', 'databases', 'mysql', 'postgres'],
    ['واي فاي', 'وايرلس', 'wifi', 'wi-fi', 'wireless', 'لاسلكي', 'لاسلكيه', 'الشبكات اللاسلكيه', 'wlan', 'wpa', 'wep'],
    ['حزم', 'حزمه', 'packet', 'packets', 'sniffer', 'sniffing', 'شم', 'التقاط', 'capture', 'pcap', 'تحليل الحزم'],
    ['جنائي', 'forensics', 'forensic', 'ادله', 'تحقيق رقمي', 'dfir', 'استعاده', 'recovery', 'carving', 'ذاكره', 'memory dump', 'التحليل الجنائي'],
    ['هندسه عكسيه', 'الهندسه العكسيه', 'reverse engineering', 'reversing', 'تفكيك', 'decompile', 'disassemble', 'assembly', 'ثنائي', 'binary'],
    ['فيروس', 'فيروسات', 'malware', 'virus', 'antivirus', 'مضاد فيروسات', 'برمجيات خبيثه', 'خبيث', 'trojan', 'ransomware', 'فديه'],
    ['جدار', 'جدار حمايه', 'جدار ناري', 'firewall', 'iptables', 'ufw', 'nftables'],
    ['مراقبه', 'monitor', 'monitoring', 'سجلات', 'logs', 'log', 'لوج', 'اكتشاف التسلل', 'ids', 'ips', 'siem', 'الدفاع والمراقبه'],
    ['وصول عن بعد', 'الوصول عن بعد', 'remote', 'remote access', 'اتصال عن بعد', 'terminal', 'طرفيه', 'shell'],
    ['dns', 'نطاق', 'نطاقات', 'دومين', 'domain', 'domains', 'subdomain', 'نطاق فرعي', 'subdomains'],
    ['osint', 'جمع المعلومات', 'جمع معلومات', 'استطلاع', 'recon', 'reconnaissance', 'معلومات عامه'],
    ['حاويات', 'حاويه', 'container', 'containers', 'عزل', 'sandbox', 'vm', 'جهاز افتراضي', 'virtual machine', 'افتراضي'],
    ['خصوصيه', 'privacy', 'تخفي', 'anonymity', 'اخفاء الهويه', 'vpn', 'proxy', 'بروكسي', 'tor', 'تور'],
    ['صلاحيات', 'permissions', 'permission', 'حسابات', 'مستخدمين', 'users', 'root', 'جذر', 'الحسابات والصلاحيات'],
    ['قرص', 'اقراص', 'disk', 'disks', 'تخزين', 'storage', 'partition', 'تقسيم', 'usb', 'النظام والاقراص'],
    ['ضغط', 'compress', 'compression', 'zip', 'tar', 'gz', 'ارشفه', 'archive', 'فك الضغط', 'extract', 'الضغط والارشفه'],
    ['نص', 'نصوص', 'text', 'ابحث في الملفات', 'search files', 'sed', 'awk', 'معالجه النصوص'],
    ['سكربت', 'سكربتات', 'script', 'scripting', 'اتمته', 'automation', 'bash', 'جدوله', 'schedule'],
    ['عمليات', 'process', 'processes', 'cpu', 'معالج', 'ram', 'موارد', 'resources', 'اداء', 'performance', 'العمليات والموارد'],
    ['اسرار', 'secrets', 'api key', 'مفاتيح', 'leak', 'تسريب', 'كشف الاسرار', 'static analysis', 'فحص الكود', 'sast'],
    ['ssl', 'tls', 'شهاده', 'شهادات', 'certificate', 'certificates', 'شهاده رقميه'],
    ['smb', 'samba', 'مشاركه ملفات', 'netbios', 'ويندوز', 'windows'],
    ['بيانات وصفيه', 'metadata', 'exif', 'صور', 'image', 'images', 'صوره'],
    ['ستيجانوجرافي', 'steganography', 'stego', 'اخفاء بيانات', 'اخفاء داخل صوره'],
    ['نسخ احتياطي', 'backup', 'backups', 'نقل ملفات', 'transfer', 'scp', 'sftp'],
    ['اتصال', 'connectivity', 'تتبع', 'مسار', 'route', 'latency', 'تاخير', 'زمن الاستجابه'],
    ['مبتدئ', 'beginner', 'beginners', 'من الصفر', 'اساسيات', 'basics', 'مبتدئين', 'سهل']
  ];
  var GI = {}, PHRASES = [];
  var CONCEPT_FROM = 0;
  GROUPS.forEach(function (g, i) { if (g[0] === '--concepts--') CONCEPT_FROM = i; });
  GROUPS = GROUPS.map(function (g, gi) {
    var t = g.map(norm).filter(function (x, i, a) { return x && a.indexOf(x) === i; });
    t.forEach(function (x) { (GI[x] = GI[x] || []).push(gi); if (x.indexOf(' ') > 0) PHRASES.push([x, gi]); });
    return t;
  });
  PHRASES.sort(function (a, b) { return b[0].length - a[0].length; });


  // ---------- curated intents: when a question clearly asks for a job, the usual tools come first
  var BOOSTS = [
    [[['port', 'ports', 'منفذ', 'منافذ', 'بورت', 'بورتات'], ['scan', 'scanning', 'فحص', 'افحص', 'مسح', 'سكان', 'امسح']], ['nmap', 'masscan', 'nping', 'hping3', 'netcat']],
    [[['اجهزه', 'جهاز', 'devices', 'hosts', 'اكتشاف', 'discover', 'discovery'], ['شبكه', 'network', 'lan']], ['nmap', 'arp-scan', 'netdiscover', 'nbtscan', 'arping']],
    [[['كلمه سر', 'كلمات سر', 'كلمه المرور', 'كلمات المرور', 'كلمات السر', 'كلمه السر', 'باسورد', 'password', 'passwords', 'باسوورد'], ['كسر', 'اكسر', 'crack', 'cracking', 'brute', 'تخمين', 'اختبار', 'تدقيق', 'قوه', 'ضعف']], ['john', 'hashcat', 'hydra', 'medusa', 'crunch', 'cewl']],
    [[['كلمه سر', 'كلمات سر', 'كلمه المرور', 'كلمات المرور', 'كلمات السر', 'كلمه السر', 'باسورد', 'password', 'passwords', 'باسوورد']], ['john', 'hashcat', 'hydra', 'medusa'], 70],
    [[['بصمه', 'هاش', 'hash', 'checksum', 'تجزئه'], ['ملف', 'ملفات', 'file', 'files', 'سلامه', 'integrity', 'تحقق']], ['sha256sum', 'md5sum', 'hashdeep', 'sha1sum', 'sha512sum'], 110],
    [[['تغيير', 'تغير', 'غير', 'change', 'reset', 'اعاده ضبط'], ['كلمه سر', 'كلمات سر', 'كلمه المرور', 'كلمه السر', 'باسورد', 'password']], ['passwd', 'chpasswd', 'gpasswd', 'sudo'], 150],
    [[['crack', 'cracking', 'brute', 'bruteforce', 'brute force']], ['hydra', 'john', 'hashcat', 'medusa']],
    [[['sniff', 'sniffer', 'sniffing', 'packets', 'packet', 'حزم', 'حزمه', 'التقاط', 'pcap', 'شم']], ['wireshark', 'tcpdump', 'tshark', 'ettercap', 'bettercap']],
    [[['ويب', 'web', 'موقع', 'مواقع', 'website', 'webapp'], ['ثغرات', 'ثغره', 'vulnerability', 'vulnerabilities', 'vuln', 'فحص', 'افحص', 'scan', 'scanner', 'ماسح']], ['nikto', 'zap', 'burp', 'nuclei', 'wpscan', 'sqlmap']],
    [[['sql', 'sqli', 'حقن', 'injection']], ['sqlmap', 'burp', 'zap']],
    [[['wifi', 'wi-fi', 'واي فاي', 'وايرلس', 'wireless', 'لاسلكي', 'لاسلكيه', 'wpa', 'wep']], ['aircrack', 'kismet', 'bettercap']],
    [[['directories', 'directory', 'dirs', 'مجلدات', 'مسارات', 'brute', 'fuzz', 'fuzzing', 'ffuf']], ['gobuster', 'ffuf', 'dirb', 'dirsearch', 'wfuzz']],
    [[['subdomain', 'subdomains', 'نطاق فرعي', 'نطاقات فرعيه']], ['amass', 'subfinder', 'dnsrecon', 'dnsenum', 'fierce']],
    [[['استرجاع', 'استعاده', 'recover', 'recovery', 'undelete', 'محذوفه', 'محذوف', 'deleted'], ['ملفات', 'files', 'file', 'صور', 'بيانات']], ['photorec', 'testdisk', 'foremost', 'scalpel', 'autopsy']],
    [[['ذاكره', 'memory', 'ram', 'dump'], ['تحليل', 'forensics', 'جنائي', 'forensic', 'analysis']], ['volatility', 'autopsy', 'bulk_extractor']],
    [[['reverse', 'reversing', 'عكسيه', 'تفكيك', 'decompile', 'disassemble']], ['ghidra', 'radare2', 'gdb', 'objdump', 'jadx', 'apktool']],
    [[['فيروس', 'فيروسات', 'malware', 'antivirus', 'خبيث', 'خبيثه', 'virus']], ['clamav', 'yara', 'rkhunter', 'chkrootkit']],
    [[['تقويه', 'تقوية', 'harden', 'hardening', 'تامين', 'تأمين', 'audit', 'تدقيق'], ['نظام', 'انظمه', 'system', 'systems', 'سيرفر', 'server', 'لينكس', 'linux']], ['lynis', 'ufw', 'fail2ban', 'auditd', 'aide']],
    [[['intrusion', 'ids', 'ips', 'تسلل', 'اكتشاف التسلل', 'siem', 'edr']], ['suricata', 'snort', 'zeek', 'wazuh', 'crowdsec']],
    [[['اخفاء', 'اخفي', 'hide', 'steganography', 'stego', 'ستيجانوجرافي']], ['steghide', 'exiftool', 'binwalk']],
    [[['تشفير', 'encrypt', 'encryption', 'شفر', 'تشفيرها', 'cipher'], ['ملفات', 'ملف', 'files', 'file', 'قرص', 'disk', 'رسائل', 'ايميل', 'email']], ['gpg', 'openssl', 'veracrypt', 'cryptsetup']],
    [[['identify', 'تعرف', 'نوع', 'تحديد'], ['hash', 'هاش', 'بصمه', 'تجزئه']], ['hashid', 'hashcat', 'john']],
    [[['ssl', 'tls', 'https', 'شهاده', 'شهادات', 'certificate']], ['testssl', 'sslscan', 'sslyze', 'openssl']],
    [[['تخفي', 'anonymous', 'anonymity', 'privacy', 'خصوصيه', 'اخفاء الهويه', 'vpn']], ['tor', 'proxychains', 'openvpn', 'wireguard']],
    [[['listening', 'مفتوحه', 'مفتوح', 'استماع'], ['ports', 'port', 'منافذ', 'منفذ', 'connections', 'اتصالات']], ['ss', 'lsof', 'nmap']],
    [[['bandwidth', 'عرض النطاق', 'سرعه', 'speed', 'استهلاك'], ['شبكه', 'network', 'انترنت', 'internet', 'نت']], ['iftop', 'iperf3', 'mtr']],
    [[['vulnerability', 'ثغرات', 'ثغره', 'vulnerabilities', 'vuln'], ['scanner', 'ماسح', 'سكانر', 'فحص', 'scan']], ['openvas', 'nuclei', 'nikto', 'lynis', 'trivy']],
    [[['secrets', 'اسرار', 'api key', 'مفاتيح', 'leak', 'تسريب', 'كود', 'code', 'source', 'سورس']], ['gitleaks', 'semgrep', 'bandit', 'trivy']],
    [[['metadata', 'بيانات وصفيه', 'exif']], ['exiftool', 'strings', 'file']],
    [[['dns', 'نطاق', 'دومين', 'domain', 'whois'], ['lookup', 'استعلام', 'بحث', 'سجلات', 'records', 'معلومات']], ['dig', 'nslookup', 'whois', 'dnsrecon']],
    [[['backup', 'نسخ', 'احتياطي', 'احتياطيه', 'مزامنه', 'sync']], ['rsync', 'tar', 'dd', 'cp']],
    [[['ضغط', 'compress', 'zip', 'ارشفه', 'archive', 'extract', 'فك']], ['tar', 'gzip', 'zip', '7z', 'unzip']],
    [[['ping', 'بنج', 'اتصال', 'connectivity', 'يرد', 'reachable']], ['ping', 'traceroute', 'mtr', 'nmap']]
  ];
  function boosts(nq) {
    var tk = {}; nq.split(' ').forEach(function (t) { if (!t) return; tk[t] = 1; stems(t).forEach(function (x) { tk[x] = 1; }); });
    var pad = ' ' + nq + ' ', out = {};
    BOOSTS.forEach(function (b) {
      var ok = b[0].every(function (alts) { return alts.some(function (a) { a = norm(a); return a.indexOf(' ') > 0 ? pad.indexOf(' ' + a + ' ') > -1 : tk[a]; }); });
      if (!ok) return;
      b[1].forEach(function (id, i) { var v = (b[2] || 160) - i * 12; if (!out[id] || out[id] < v) out[id] = v; });
    });
    return out;
  }

  // ---------- edit distance (optimal string alignment)
  function dl(a, b, max) {
    var la = a.length, lb = b.length; if (Math.abs(la - lb) > max) return max + 1;
    var d = [], i, j, c, m;
    for (i = 0; i <= la; i++) { d[i] = [i]; } for (j = 1; j <= lb; j++) d[0][j] = j;
    for (i = 1; i <= la; i++) {
      m = max + 1;
      for (j = 1; j <= lb; j++) {
        c = a.charAt(i - 1) === b.charAt(j - 1) ? 0 : 1;
        d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + c);
        if (i > 1 && j > 1 && a.charAt(i - 1) === b.charAt(j - 2) && a.charAt(i - 2) === b.charAt(j - 1)) d[i][j] = Math.min(d[i][j], d[i - 2][j - 2] + 1);
        if (d[i][j] < m) m = d[i][j];
      }
      if (m > max) return max + 1;
    }
    return d[la][lb];
  }
  function words(s) { var o = {}; s.split(' ').forEach(function (w) { if (w) o[w] = 1; }); return o; }

  // ---------- engine over rows: {id, name, cat, short, cmd, extra}
  function create(rows) {
    var R = rows.map(function (r, i) {
      var n = norm(r.name + ' ' + r.id);
      return { i: i, r: r, id: norm(r.id), n: n, nw: words(n), c: norm(r.cat || ''), s: norm(r.short || ''), m: norm(r.cmd || ''), mw: words(norm(r.cmd || '')), x: norm(r.extra || '') };
    });
    var vocab = {};
    function addV(w, disp, wt) { if (w.length < 3 || /^\d+$/.test(w)) return; var v = vocab[w]; if (!v) vocab[w] = { w: w, d: disp || w, n: wt }; else v.n += wt; }
    R.forEach(function (x) {
      x.n.split(' ').forEach(function (w) { addV(w, w === x.id ? x.r.name : w, 3); });
      addV(x.id, x.r.name, 3); x.c.split(' ').forEach(function (w) { addV(w, null, 1); }); x.s.split(' ').forEach(function (w) { addV(w, null, 1); });
    });
    var V = Object.keys(vocab).map(function (k) { return vocab[k]; });

    function has(field, a, latin) {
      var p = field.indexOf(a); if (p < 0) return false; if (!latin) return true;
      while (p > -1) { if (p === 0 || field.charAt(p - 1) === ' ') return true; p = field.indexOf(a, p + 1); } return false;
    }
    function fieldScore(a, x) {
      var L = a.length, best = 0, f = '', lat = /^[a-z0-9._+#\-]+$/.test(a);
      function up(s, ff) { if (s > best) { best = s; f = ff; } }
      if (x.id === a || x.nw[a]) return [100, 'name'];
      if (L >= 3) {
        var p = x.n.indexOf(a); if (p === 0) up(85, 'name'); else if (p > 0) up(65, 'name');
        if (x.m && has(x.m, a, lat)) up(38, 'cmd');
        if (has(x.c, a, lat)) up(45, 'cat');
        if (has(x.s, a, lat)) up(35, 'short');
        if (x.x && has(x.x, a, lat)) up(22, 'extra');
      } else if (x.mw[a]) up(40, 'cmd');
      return [best, f];
    }
    function itemOf(tok) { return { tok: tok, alts: [{ t: tok, w: 1, k: 'q' }] }; }
    function addAlt(it, t, w, k) { if (t.length < 2) return; for (var i = 0; i < it.alts.length; i++) if (it.alts[i].t === t) return; it.alts.push({ t: t, w: w, k: k }); }
    function expand(it, base, wq) {
      stems(base).forEach(function (s, i) { if (i) addAlt(it, s, .85, 'q'); });
      var seen = {};
      stems(base).forEach(function (s) { (GI[s] || []).forEach(function (gi) { if (seen[gi]) return; seen[gi] = 1; GROUPS[gi].forEach(function (t) { addAlt(it, t, gi < CONCEPT_FROM ? .92 : (wq || .7), gi < CONCEPT_FROM ? 'tr' : 'syn'); }); }); });
    }
    function build(q) {
      var nq = norm(q), items = [];
      var padded = ' ' + nq + ' ';
      PHRASES.forEach(function (p) {
        var k = padded.indexOf(' ' + p[0] + ' '); if (k < 0) return;
        padded = padded.slice(0, k) + ' ' + padded.slice(k + p[0].length + 1);
        var it = itemOf(p[0]); it.phrase = true; GROUPS[p[1]].forEach(function (t) { addAlt(it, t, t === p[0] ? 1 : (p[1] < CONCEPT_FROM ? .92 : .8), t === p[0] ? 'q' : (p[1] < CONCEPT_FROM ? 'tr' : 'syn')); }); items.push(it);
      });
      var toks = padded.split(' ').filter(Boolean), keep = toks.filter(function (t) { return !STOP[t]; });
      if (!keep.length && !items.length) keep = toks;
      keep.forEach(function (t) { var it = itemOf(t); expand(it, t); items.push(it); });
      return items;
    }
    function hits(it) {
      var n = 0; for (var k = 0; k < R.length; k++) { for (var a = 0; a < it.alts.length; a++) if (fieldScore(it.alts[a].t, R[k])[0]) { n++; break; } } return n;
    }
    function fixes(it) {
      var t = it.tok; if (it.phrase || t.length < (/[\u0621-\u064A]/.test(t) ? 5 : 4) || /^[\d\-\.]+$/.test(t)) return [];
      var max = t.length <= 7 ? 1 : 2, c = [];
      V.forEach(function (v) { if (v.w === t) return; var d = dl(t, v.w, max); if (d <= max) c.push([d, -v.n, v]); });
      c.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
      return c.slice(0, 3).map(function (x) { return x[2]; });
    }
    function search(q, o) {
      o = o || {}; var items = build(q), did = null, fixedTok = {};
      if (!items.length) return { items: [], did: null, approx: false };
      items.forEach(function (it) {
        if (hits(it)) return;
        var fx = fixes(it); if (!fx.length) return;
        fx.forEach(function (v) { addAlt(it, v.w, .65, 'fix'); expand(it, v.w, .55); });
        fixedTok[it.tok] = fx[0].d;
      });
      var res = [], bo = boosts(norm(q));
      R.forEach(function (x) {
        if (o.filter && !o.filter(x.r)) return;
        var total = 0, matched = 0, why = '', whyBest = 0, kind = 'q';
        items.forEach(function (it) {
          var b = 0, bf = '', bk = 'q';
          it.alts.forEach(function (a) { var s = fieldScore(a.t, x), v = s[0]; if (a.k === 'syn' && s[1] === 'name' && v === 100) v = 40; var sc = v * a.w; s = [v, s[1]]; if (sc > b) { b = sc; bf = s[1]; bk = a.k; } });
          if (b > 0) { matched++; total += b; if (b > whyBest) { whyBest = b; why = bf; kind = bk; } }
        });
        var bst = bo[x.id] || 0;
        if (!matched && !bst) return;
        var full = matched === items.length || bst > 0; total += bst;
        if (full) total += 40; if (norm(q) === x.n || norm(q) === x.id) total += 60;
        res.push({ i: x.i, row: x.r, score: total + matched * 10, full: full, why: bst && !why ? 'boost' : why, kind: kind, boost: bst > 0 });
      });
      res.sort(function (a, b) { return (b.full - a.full) || (b.score - a.score) || (a.i - b.i); });
      var nFull = res.filter(function (x) { return x.full; }).length;
      var out = res.filter(function (x) { return x.full; });
      var approx = false;
      if (nFull < (o.min || 6)) { out = out.concat(res.filter(function (x) { return !x.full; })); approx = nFull === 0 || out.length > nFull; }
      var fixedKeys = Object.keys(fixedTok);
      if (fixedKeys.length) {
        var parts = norm(q).split(' ').map(function (t) { var it = items.filter(function (x) { return x.tok === t && fixedTok.hasOwnProperty(t); })[0]; if (!it) return t; var fx = fixes(it)[0]; return fx ? fx.d : t; });
        did = parts.join(' ');
      }
      return { items: out.slice(0, o.limit || 500), did: did, approx: approx && nFull < (o.min || 6), nFull: nFull, total: out.length };
    }
    return { search: search, rows: R };
  }
  return { create: create, norm: norm, stems: stems, dl: dl };
});
