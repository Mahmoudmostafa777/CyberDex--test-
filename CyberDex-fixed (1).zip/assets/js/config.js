// Public values only (safe to expose). NEVER put the service_role key or any AI key here.
window.CDX_CONFIG = { SUPABASE_URL: 'https://akuqrwgponincvbbxpyv.supabase.co', SUPABASE_ANON_KEY: 'sb_publishable_Co4zkMrdH0Bs5xO9kvSxYw_1Jn--Qst' };
