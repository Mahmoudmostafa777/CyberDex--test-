// CyberDex section exams: questions come from the per-tool quizzes. Pass = 70%.
(function () {
  var root = document.getElementById('examApp');
  if (!root) return;
  var SELF = document.currentScript && document.currentScript.src;
  var URL_ = SELF ? SELF.replace(/js\/exams\.js.*$/, 'exams.json') : 'assets/exams.json';
  var N = 10, PASS = 0.7, NEED = 0.5;
  var BANK = [], cur = null;
  var P = function () { return window.CDXP; };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function shuf(a) { a = a.slice(); for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)), t = a[i]; a[i] = a[j]; a[j] = t; } return a; }
  function learnedOf(c) { var S = P().state(), n = 0; c.t.forEach(function (t) { if (S.learned[t[0]]) n++; }); return n; }
  function needOf(c) { return Math.max(1, Math.ceil(c.t.length * NEED)); }
  function certOf(cat) { var S = P().state(), r = null; Object.keys(S.certs).forEach(function (k) { if (S.certs[k].cat === cat) r = k; }); return r; }

  function list() {
    var S = P().state(), st = P().stats();
    var h = '<div class="ex-sum"><div><b>' + st.examsPassed + '</b><span>قسمًا نجحت فيه</span></div><div><b>' + st.certs + '</b><span>شهادة</span></div><div><b>29</b><span>قسمًا متاحًا</span></div></div>';
    h += '<p class="ex-rule">كل اختبار 10 أسئلة (أو كل أسئلة القسم إن قلّت) وتنجح بـ 70%. لفتح الاختبار علّم نصف أدوات القسم على الأقل كمتعلَّمة. الأسئلة تتغيّر في كل محاولة.</p><div class="ex-grid">';
    BANK.forEach(function (c, i) {
      var e = S.exams[c.n], l = learnedOf(c), need = needOf(c), open = l >= need, code = certOf(c.n);
      var st2 = e && e.passed ? '<span class="ex-st ok">✓ نجحت · أفضل نتيجة ' + e.best + '%</span>' : (open ? '<span class="ex-st go">جاهز</span>' : '<span class="ex-st lock">🔒 علّم ' + (need - l) + ' أداة أخرى</span>');
      h += '<div class="ex-card' + (e && e.passed ? ' done' : '') + (open ? '' : ' locked') + '"><b>' + esc(c.n) + '</b><small>' + l + ' من ' + c.t.length + ' أداة تعلّمتها</small>' + st2 + '<div class="ex-act">' +
        (open ? '<button class="btn primary sm" data-start="' + i + '">' + (e ? 'أعد الاختبار' : 'ابدأ الاختبار') + '</button>' : '<a class="btn sm" href="tools.html?cat=' + encodeURIComponent(c.n) + '">أدوات القسم</a>') +
        (code ? '<a class="btn sm" href="certificate.html?code=' + code + '">الشهادة</a>' : '') + '</div></div>';
    });
    root.innerHTML = h + '</div>';
  }

  function start(i) {
    var c = BANK[i], qs = shuf(c.q).slice(0, N).map(function (q) {
      var idx = shuf(q[2].map(function (_, k) { return k; }));
      return { t: q[0], q: q[1], o: idx.map(function (k) { return q[2][k]; }), a: idx.indexOf(q[3]), w: q[4] };
    });
    cur = { i: i, c: c, qs: qs, k: 0, right: 0, wrong: [] };
    ask();
  }
  function ask() {
    var q = cur.qs[cur.k], n = cur.qs.length;
    root.innerHTML = '<div class="ex-run"><div class="ex-top"><button class="btn sm" id="exQuit" type="button">إنهاء</button><b>' + esc(cur.c.n) + '</b><span>سؤال ' + (cur.k + 1) + ' من ' + n + '</span></div><div class="pg-bar"><i style="width:' + Math.round(cur.k * 100 / n) + '%"></i></div><h2 class="ex-q">' + esc(q.q) + '</h2><div class="ex-opts">' +
      q.o.map(function (o, k) { return '<button type="button" data-k="' + k + '">' + esc(o) + '</button>'; }).join('') + '</div><div class="ex-why" hidden></div><div class="ex-next" hidden><button class="btn primary" id="exNext" type="button"></button></div></div>';
    root.scrollIntoView({ block: 'start' });
  }
  function answer(k) {
    var q = cur.qs[cur.k], btns = root.querySelectorAll('.ex-opts button');
    if (root.querySelector('.ex-opts.done')) return;
    root.querySelector('.ex-opts').classList.add('done');
    [].forEach.call(btns, function (b, j) { b.disabled = true; if (j === q.a) b.classList.add('ok'); else if (j === k) b.classList.add('bad'); });
    if (k === q.a) cur.right++; else cur.wrong.push(q);
    var w = root.querySelector('.ex-why'); w.textContent = (k === q.a ? 'إجابة صحيحة. ' : 'الإجابة الصحيحة موضّحة بالأخضر. ') + q.w; w.hidden = false;
    var nb = root.querySelector('#exNext'); nb.textContent = cur.k + 1 < cur.qs.length ? 'السؤال التالي ←' : 'اعرض النتيجة'; root.querySelector('.ex-next').hidden = false;
  }
  function finish() {
    var n = cur.qs.length, need = Math.ceil(n * PASS), pct = Math.round(cur.right * 100 / n), ok = cur.right >= need;
    P().examResult(cur.c.n, pct, ok);
    document.dispatchEvent(new CustomEvent('cdx-progress'));
    var h = '<div class="ex-res ' + (ok ? 'ok' : 'no') + '"><div class="ex-score"><b>' + cur.right + ' / ' + n + '</b><span>' + pct + '%</span></div><h2>' + (ok ? 'أحسنت! نجحت في اختبار «' + esc(cur.c.n) + '»' : 'لم تصل للنجاح هذه المرة') + '</h2><p>' + (ok ? 'تجاوزت حد النجاح (' + need + ' من ' + n + ').' : 'تحتاج ' + need + ' من ' + n + ' للنجاح. راجع الأخطاء أدناه ثم أعد المحاولة بأسئلة جديدة.') + '</p>';
    if (ok) {
      var old = certOf(cur.c.n), nm = '';
      try { nm = localStorage.getItem('cdx-cert-name') || ''; } catch (e) {}
      h += old ? '<p><a class="btn primary" href="certificate.html?code=' + old + '">افتح شهادتك</a></p>' :
        '<form class="ex-cert" id="exCert"><label>الاسم الذي سيظهر على الشهادة<input id="exName" maxlength="60" required placeholder="اسمك الكامل" value="' + esc(nm) + '"></label><button class="btn primary" type="submit">أصدر الشهادة</button><small>الشهادة تعليمية من CyberDex وليست معتمدة من جهة رسمية.</small></form>';
    }
    if (cur.wrong.length) {
      h += '<h3>راجع هذه الأسئلة</h3><div class="ex-wrong">' + cur.wrong.map(function (q) { return '<div><b>' + esc(q.q) + '</b><p>الصحيح: ' + esc(q.o[q.a]) + '</p><small>' + esc(q.w) + '</small> <a href="tools/' + q.t + '.html">صفحة الأداة ←</a></div>'; }).join('') + '</div>';
    }
    h += '<p class="ex-end"><button class="btn" id="exAgain" type="button">أعد الاختبار</button> <button class="btn" id="exBack" type="button">كل الأقسام</button></p></div>';
    root.innerHTML = h; root.scrollIntoView({ block: 'start' });
    if (ok && window.CDX_ACH) setTimeout(function () { window.CDX_ACH.evaluate(); }, 100);
  }
  function genCode(c) {
    var A = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ', b = new Uint8Array(8), s = '';
    (window.crypto || window.msCrypto).getRandomValues(b); for (var i = 0; i < 8; i++) s += A[b[i] % A.length];
    return 'CDX-' + s.slice(0, 4) + '-' + s.slice(4);
  }
  function issue(name) {
    var code = genCode(), c = { cat: cur.c.n, name: name, score: Math.round(cur.right * 100 / cur.qs.length), ts: Date.now() };
    try { localStorage.setItem('cdx-cert-name', name); } catch (e) {}
    P().addCert(code, c);
    document.dispatchEvent(new CustomEvent('cdx-progress'));
    if (window.CDX_ACH && window.CDX_ACH.publishCerts) window.CDX_ACH.publishCerts();
    location.href = 'certificate.html?code=' + code;
  }

  root.addEventListener('click', function (e) {
    var t = e.target;
    var s = t.closest('[data-start]'); if (s) return start(+s.getAttribute('data-start'));
    var o = t.closest('.ex-opts button'); if (o) return answer(+o.getAttribute('data-k'));
    if (t.closest('#exNext')) { if (cur.k + 1 < cur.qs.length) { cur.k++; ask(); } else finish(); return; }
    if (t.closest('#exQuit') && confirm('إنهاء الاختبار؟ لن تُحتسب هذه المحاولة.')) { cur = null; list(); return; }
    if (t.closest('#exAgain')) return start(cur.i);
    if (t.closest('#exBack')) { cur = null; list(); }
  });
  root.addEventListener('submit', function (e) { if (e.target.id === 'exCert') { e.preventDefault(); var v = document.getElementById('exName').value.trim(); if (v.length >= 2) issue(v); } });

  function init() {
    fetch(URL_).then(function (r) { return r.json(); }).then(function (j) { BANK = j; var w = function () { if (!P()) return setTimeout(w, 100); list(); document.addEventListener('cdx-progress', function () { if (!cur) list(); }); document.addEventListener('cdx-auth', function () { setTimeout(function () { if (!cur) list(); }, 400); }); }; w(); })
      .catch(function () { root.innerHTML = '<p class="ex-rule">تعذّر تحميل الأسئلة. تحقق من الاتصال ثم أعد تحميل الصفحة.</p>'; });
  }
  if (document.readyState === 'complete') init(); else addEventListener('load', init);
})();
