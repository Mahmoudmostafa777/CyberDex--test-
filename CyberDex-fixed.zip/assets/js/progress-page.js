(function () {
  function init() {
  var P = window.CDXP; var $ = function (i) { return document.getElementById(i); };
  if (!$('pgLevel')) return;
  var tools = []; try { tools = JSON.parse($('pgTools').textContent); } catch (e) {}
  var BADGES = [
    ['first', 'الخطوة الأولى', 'علّمت أول أداة', function (x) { return x.learned >= 1; }],
    ['ten', 'عشر أدوات', 'تعلّمت 10 أدوات', function (x) { return x.learned >= 10; }],
    ['fifty', 'خمسون أداة', 'تعلّمت 50 أداة', function (x) { return x.learned >= 50; }],
    ['term', 'ابن الطرفية', 'أنهيت أول محاكاة', function (x) { return x.sims >= 1; }],
    ['term5', 'خمس محاكاة', 'أنهيت 5 محاكاة', function (x) { return x.sims >= 5; }],
    ['ace', 'درجة كاملة', 'أجبت اختبار أداة بلا خطأ', function (x) { return x.aces >= 1; }],
    ['ace5', 'عبقري الاختبارات', '5 اختبارات بدرجة كاملة', function (x) { return x.aces >= 5; }],
    ['s3', 'ملتزم', '3 أيام متتالية', function (x) { return x.streak >= 3; }],
    ['s7', 'أسبوع كامل', '7 أيام متتالية', function (x) { return x.streak >= 7; }],
    ['cat', 'مجال مكتمل', 'أنهيت كل أدوات مجال', function (x, c) { return c.some(function (k) { return k.total > 0 && k.done === k.total; }); }]
  ];
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function render() {
    var st = P.stats(), S = P.state();
    $('pgLevel').textContent = st.level; $('pgLearned').textContent = st.learned; $('pgAces').textContent = st.aces; $('pgSims').textContent = st.sims; $('pgStreak').textContent = st.streak;
    var pct = st.nextMin ? Math.round((st.points - st.levelMin) * 100 / (st.nextMin - st.levelMin)) : 100;
    $('pgBar').style.width = pct + '%';
    $('pgNext').textContent = st.nextMin ? st.points + ' نقطة — تحتاج ' + (st.nextMin - st.points) + ' للوصول إلى «' + st.nextName + '»' : st.points + ' نقطة — وصلت لأعلى مستوى';
    var cats = {}; tools.forEach(function (t) { var c = cats[t.c] || (cats[t.c] = { name: t.c, total: 0, done: 0 }); c.total++; if (S.learned[t.id]) c.done++; });
    var cl = Object.keys(cats).map(function (k) { return cats[k]; }).sort(function (a, b) { return b.total - a.total; });
    $('pgCats').innerHTML = cl.map(function (c) { return '<div class="pg-cat"><div><b>' + esc(c.name) + '</b><span>' + c.done + ' / ' + c.total + '</span></div><div class="pg-bar"><i style="width:' + Math.round(c.done * 100 / c.total) + '%"></i></div></div>'; }).join('');
    $('pgBadges').innerHTML = BADGES.map(function (b) { var ok = b[3](st, cl); return '<div class="badge' + (ok ? ' on' : '') + '"><span class="bi">' + (ok ? '★' : '🔒') + '</span><b>' + b[1] + '</b><small>' + b[2] + '</small></div>'; }).join('');
    var names = {}; tools.forEach(function (t) { names[t.id] = t.n; });
    var ids = Object.keys(S.learned).filter(function (i) { return names[i]; });
    $('pgList').innerHTML = ids.map(function (i) { return '<a class="chip" href="tools/' + i + '.html">' + esc(names[i]) + '</a>'; }).join('');
    $('pgEmpty').hidden = ids.length > 0;
    $('pgSync').textContent = window.CDX_SESSION ? '✔ مسجّل الدخول: تقدّمك يُحفظ بحسابك على كل أجهزتك.' : 'تقدّمك محفوظ على هذا الجهاز فقط. سجّل الدخول من أعلى الصفحة لحفظه بحسابك.';
  }
  document.addEventListener('cdx-progress', render); document.addEventListener('cdx-auth', function () { setTimeout(render, 300); });
  $('pgReset').onclick = function () { if (confirm('سيُمسح تقدّمك من هذا الجهاز. متأكد؟')) { P.reset(); render(); } };
  render();
  }
  if (document.readyState === 'complete') init(); else window.addEventListener('load', init);
})();
