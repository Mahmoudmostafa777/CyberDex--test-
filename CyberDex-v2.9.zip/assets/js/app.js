(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };

  /* ---------- mobile menu ---------- */
  var mb = $('#menuBtn'), nav = $('#nav');
  if (mb && nav) {
    mb.addEventListener('click', function () {
      var o = nav.classList.toggle('open');
      mb.setAttribute('aria-expanded', o ? 'true' : 'false');
    });
    $$('a', nav).forEach(function (a) { a.addEventListener('click', function () { nav.classList.remove('open'); }); });
  }

  /* ---------- splash (home page, once per session) ---------- */
  var sp = $('#splash');
  if (sp) {
    var done = false;
    var end = function () {
      if (done) return; done = true;
      sp.classList.add('out');
      setTimeout(function () { if (sp.parentNode) sp.parentNode.removeChild(sp); }, 700);
    };
    try { sessionStorage.setItem('cdx-s', '1'); } catch (e) {}
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    setTimeout(end, reduce ? 700 : 3000);
    sp.addEventListener('click', end);
    document.addEventListener('keydown', end, { once: true });
  }


  /* ---------- developer contact links (kept out of the visible page text) ---------- */
  $$('[data-l]').forEach(function (a) {
    var h = '';
    try { h = atob(a.getAttribute('data-l')); } catch (e) { return; }
    if (!/^mailto:/.test(h)) {
      a.setAttribute('href', h); a.setAttribute('target', '_blank'); a.setAttribute('rel', 'noopener noreferrer');
      return;
    }
    // email: mailto links do not work everywhere (embedded viewers, no mail app), so offer alternatives
    var m = h.match(/^mailto:([^?]+)(?:\?subject=(.*))?$/) || [];
    var addr = m[1] || '', subj = m[2] || '';
    var wrap = document.createElement('span'); wrap.className = 'dev-wrap';
    a.parentNode.insertBefore(wrap, a); wrap.appendChild(a);
    a.setAttribute('href', h); a.setAttribute('aria-haspopup', 'true'); a.setAttribute('aria-expanded', 'false');
    var menu = document.createElement('div'); menu.className = 'dev-menu'; menu.hidden = true; menu.setAttribute('role', 'menu');
    var g = document.createElement('a'); g.textContent = 'فتح في Gmail';
    g.href = 'https://mail.google.com/mail/?view=cm&fs=1&to=' + encodeURIComponent(addr) + '&su=' + subj;
    g.target = '_blank'; g.rel = 'noopener noreferrer';
    var ma = document.createElement('a'); ma.textContent = 'فتح تطبيق البريد'; ma.href = h;
    var cp = document.createElement('button'); cp.type = 'button'; cp.textContent = 'نسخ العنوان';
    cp.addEventListener('click', function () {
      var done = function () { cp.textContent = 'تم النسخ ✓'; setTimeout(function () { cp.textContent = 'نسخ العنوان'; }, 1800); };
      var fallback = function () {
        try { var t = document.createElement('textarea'); t.value = addr; t.style.position = 'fixed'; t.style.opacity = '0'; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t); done(); }
        catch (e) { cp.textContent = 'تعذّر النسخ'; }
      };
      if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(addr).then(done, fallback); else fallback();
    });
    [g, ma, cp].forEach(function (x) { x.setAttribute('role', 'menuitem'); menu.appendChild(x); });
    wrap.appendChild(menu);
    var close = function () { menu.hidden = true; a.setAttribute('aria-expanded', 'false'); };
    a.addEventListener('click', function (e) { e.preventDefault(); menu.hidden = !menu.hidden; a.setAttribute('aria-expanded', menu.hidden ? 'false' : 'true'); });
    document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  });

  /* ---------- favourites ---------- */
  var fav = new Set();
  try { fav = new Set(JSON.parse(localStorage.getItem('cdx-fav') || '[]')); } catch (e) {}
  function saveFav() { try { localStorage.setItem('cdx-fav', JSON.stringify(Array.from(fav))); } catch (e) {} }
  function paint() {
    $$('[data-fav]').forEach(function (b) {
      var on = fav.has(b.dataset.fav);
      if (b.classList.contains('star')) { b.textContent = on ? '★' : '☆'; b.classList.toggle('on', on); }
      else { b.textContent = on ? '★ في المفضلة' : '☆ أضف للمفضلة'; }
    });
    var fc = $('#favCount'); if (fc) fc.textContent = fav.size;
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-fav]'); if (!b) return;
    var id = b.dataset.fav;
    if (fav.has(id)) fav.delete(id); else fav.add(id);
    saveFav(); paint();
    if (window.__filter) window.__filter();
  });
  paint();

  /* ---------- copy buttons ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]'); if (!b) return;
    var text = b.getAttribute('data-copy');
    var ok = function () { var o = b.getAttribute('data-l') || b.textContent; b.setAttribute('data-l', o); b.textContent = 'تم النسخ ✓'; setTimeout(function () { b.textContent = o; }, 1600); };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(ok, function () { b.textContent = 'حدّد وانسخ يدويًا'; });
    else b.textContent = 'حدّد وانسخ يدويًا';
  });

  /* ---------- command palette: Ctrl/Cmd+K (all pages) ---------- */
  (function () {
    var me = document.currentScript, src = me && me.getAttribute('src') || '';
    var root = src.indexOf('assets/') > -1 ? src.split('assets/')[0] : '';
    var box = null, input, list, items = [], sel = 0, loaded = false, loading = false, last = null;
    var norm = function (s) { return String(s).toLowerCase().replace(/[\u064B-\u0652\u0640]/g, '').replace(/[أإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه'); };
    var esc2 = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); };
    var data = null;
    var load = function (cb) {
      if (window.CDX_IDX && window.CDXS) { prep(); return cb(); }
      if (loading) return; loading = true;
      var left = 0, fail = false, fin = function () { if (--left) return; if (fail) { loading = false; return cb(true); } prep(); cb(); };
      [['search-index.js', window.CDX_IDX], ['smart-search.js', window.CDXS]].forEach(function (x) {
        if (x[1]) return; left++;
        var sc = document.createElement('script'); sc.src = root + 'assets/js/' + x[0]; sc.onload = fin; sc.onerror = function () { fail = true; fin(); }; document.head.appendChild(sc);
      });
      if (!left) { prep(); cb(); }
    };
    var prep = function () {
      if (data) return;
      var I = window.CDX_IDX, S = window.CDXS;
      var rows = I.t.map(function (r) { return { id: r[0], name: r[1], cat: r[2], short: r[3], lv: r[4], cmd: r[5] || '', extra: r[6] || '' }; });
      data = { t: rows, eng: S.create(rows), p: I.p, c: I.c, g: I.g || [], gm: {} };
      data.g.forEach(function (g) { data.gm[g[0]] = g; });
      data.geng = data.g.length ? S.create(data.g.map(function (g) { return { id: g[0], name: g[1] + ' ' + g[2], cat: 'مصطلح', short: g[3], cmd: '', extra: '' }; })) : null;
    };
    var build = function () {
      box = document.createElement('div'); box.className = 'cmdk'; box.hidden = true;
      box.innerHTML = '<div class="cmdk-bg" data-close></div><div class="cmdk-box" role="dialog" aria-modal="true" aria-label="بحث سريع"><input class="cmdk-in" type="search" placeholder="ابحث بالعربي أو الإنجليزي: nmap، كلمات السر، فحص الشبكة…" aria-label="بحث سريع" autocomplete="off"><div class="cmdk-list" role="listbox"></div><div class="cmdk-foot"><span>↑↓ للتنقل</span><span>Enter للفتح</span><span>Esc للإغلاق</span></div></div>';
      document.body.appendChild(box);
      input = $('.cmdk-in', box); list = $('.cmdk-list', box);
      box.addEventListener('click', function (e) { if (e.target.hasAttribute('data-close')) close(); });
      input.addEventListener('input', show);
      input.addEventListener('keydown', function (e) {
        if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
        else if (e.key === 'Enter') { e.preventDefault(); go(); }
        else if (e.key === 'Escape') { e.preventDefault(); close(); }
        else if (e.key === 'Tab') { e.preventDefault(); }
      });
      list.addEventListener('click', function (e) { var a = e.target.closest('a'); if (a && items[+a.dataset.i] && items[+a.dataset.i].did) { e.preventDefault(); input.value = items[+a.dataset.i].did; show(); input.focus(); } });
      list.addEventListener('mousemove', function (e) { var a = e.target.closest('a'); if (a) { sel = +a.dataset.i; mark(); } });
    };
    var mark = function () { $$('a', list).forEach(function (a, i) { a.classList.toggle('on', i === sel); a.setAttribute('aria-selected', i === sel ? 'true' : 'false'); }); var on = $('a.on', list); if (on && on.scrollIntoView) on.scrollIntoView({ block: 'nearest' }); };
    var move = function (d) { if (!items.length) return; sel = (sel + d + items.length) % items.length; mark(); };
    var go = function () { var it = items[sel]; if (!it) return; if (it.did) { input.value = it.did; show(); input.focus(); return; } location.href = it.href; };
    var show = function () {
      if (!data) { list.innerHTML = '<div class="cmdk-empty">تعذّر تحميل الفهرس. <a href="' + root + 'tools.html">افتح فهرس الأدوات</a></div>'; return; }
      var q = norm(input.value.trim()); items = [];
      if (!q) {
        data.p.slice(0, 6).forEach(function (p) { items.push({ k: 'صفحة', t: p[0], s: '', href: root + p[1] }); });
      } else {
        var rs = data.eng.search(input.value.trim(), { limit: 9 }), WHY = { cmd: 'يطابق الأمر', cat: 'يطابق القسم', short: 'يطابق الوصف', extra: 'يطابق الشرح', boost: 'مقترحة لهذه المهمة' };
        if (rs.did) items.push({ k: 'تصحيح', t: 'هل تقصد: ' + rs.did + '؟', s: 'اضغط لتجربة البحث المصحّح', did: rs.did, href: root + 'tools.html?q=' + encodeURIComponent(rs.did) });
        rs.items.forEach(function (x) { var t = x.row; items.push({ k: t.cat + (WHY[x.why] ? ' · ' + WHY[x.why] : '') + (x.full ? '' : ' · قريبة'), t: t.name, s: t.short, href: root + 'tools/' + t.id + '.html' }); });
        if (data.geng) data.geng.search(input.value.trim(), { limit: 3, min: 1 }).items.slice(0, 3).forEach(function (x) { if (!x.full) return; var g = data.gm[x.row.id]; if (g) items.push({ k: 'مصطلح', t: g[1] + (g[2] ? ' · ' + g[2] : ''), s: g[3], href: root + 'glossary.html#' + g[0] }); });
        data.c.forEach(function (c) { if (items.length < 18 && norm(c[0]).indexOf(q) > -1) items.push({ k: 'قسم', t: c[0], s: 'كل أدوات القسم', href: root + c[1] }); });
        data.p.forEach(function (p) { if (items.length < 20 && norm(p[0]).indexOf(q) > -1) items.push({ k: 'صفحة', t: p[0], s: '', href: root + p[1] }); });
        if (!items.length) items.push({ k: 'بحث', t: 'ابحث عن «' + input.value.trim() + '» في الفهرس', s: 'بحث موسّع في الأوصاف والأوامر', href: root + 'tools.html?q=' + encodeURIComponent(input.value.trim()) });
      }
      sel = 0;
      list.innerHTML = items.map(function (it, i) { return '<a href="' + esc2(it.href) + '" role="option" data-i="' + i + '"><b>' + esc2(it.t) + '</b><small>' + esc2(it.k) + '</small>' + (it.s ? '<span>' + esc2(it.s) + '</span>' : '') + '</a>'; }).join('');
      mark();
    };
    var open = function () {
      if (!box) build();
      last = document.activeElement; box.hidden = false; document.documentElement.classList.add('cmdk-open');
      input.value = ''; list.innerHTML = '<div class="cmdk-empty">جارٍ التحميل…</div>'; input.focus();
      load(function () { show(); });
    };
    var close = function () { if (!box) return; box.hidden = true; document.documentElement.classList.remove('cmdk-open'); if (last && last.focus) try { last.focus(); } catch (e) {} };
    document.addEventListener('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) { e.preventDefault(); if (box && !box.hidden) close(); else open(); return; }
      if (e.key === '/' && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName) && !$('#toolsGrid') && !(box && !box.hidden)) { e.preventDefault(); open(); }
    });
    document.addEventListener('click', function (e) { var a = e.target.closest('[data-cmdk]'); if (!a) return; e.preventDefault(); open(); });
  })();

  /* ---------- catalog filtering (tools.html) ---------- */
  var grid = $('#toolsGrid');
  if (grid) {
    var q = $('#search'), lv = $('#levelSelect'), empty = $('#emptyMsg'), count = $('#resultCount');
    var moreWrap = $('#moreWrap'), moreBtn = $('#moreBtn');
    var PAGE = 48, shown = PAGE, matches = [];
    var LVC = { 'مبتدئ': 'lv-b', 'متوسط': 'lv-m', 'متقدم': 'lv-a' };
    var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); };
    var tileOf = function (n) { var m = n.replace(/[^A-Za-z0-9]/g, ''); return m ? (m.slice(0, 2).charAt(0).toUpperCase() + m.slice(1, 2).toLowerCase()) : '#'; };
    var rows = [];
    try { rows = JSON.parse($('#catalog').textContent).map(function (r) {
      return { id: r[0], name: r[1], cat: r[2], level: r[3], short: r[4], cmd: r[5], extra: r[6], deep: r[7], isCmd: r[8],
               text: [r[1], r[0], r[4], r[2], r[6], r[5]].join(' ').toLowerCase() };
    }); } catch (e) {}
    var cardHtml = function (t) {
      var href = 'tools/' + t.id + '.html';
      return '<article class="tool" data-id="' + t.id + '" data-cat="' + esc(t.cat) + '" data-level="' + t.level + '" data-deep="' + t.deep + '">' +
        '<div class="tool-top"><div class="mono-tile">' + esc(tileOf(t.name)) + '</div><div class="tt"><h3><a href="' + href + '">' + esc(t.name) + '</a></h3><span class="cat">' + t.cat + '</span></div>' +
        '<button class="star" data-fav="' + t.id + '" aria-label="أضف إلى المفضلة" title="أضف إلى المفضلة">☆</button></div>' +
        '<p>' + esc(t.short) + '</p><code class="cmdline">' + (t.isCmd ? '<i>$</i>' : '') + esc(t.cmd) + '</code>' +
        '<div class="tool-foot"><span class="tf-l"><span class="lv ' + LVC[t.level] + '">' + t.level + '</span>' + (t.deep ? '<span class="deep-b">خطوة بخطوة</span>' : '') + '</span><a class="btn sm" href="' + href + '">افتح الشرح ←</a></div></article>';
    };
    var cat = 'all', params = new URLSearchParams(location.search);
    if (params.get('q')) q.value = params.get('q');
    if (params.get('cat')) cat = params.get('cat');
    var render = function () {
      var list = matches.slice(0, shown);
      grid.innerHTML = list.map(cardHtml).join('');
      moreWrap.hidden = matches.length <= shown;
      if (moreBtn) moreBtn.textContent = 'عرض المزيد (' + Math.min(PAGE, matches.length - shown) + ' من ' + (matches.length - shown) + ' متبقية)';
      paint();
      document.dispatchEvent(new CustomEvent('cdx-progress'));
    };
    var modeOk = function (id) { return !window.CDX_SKIN || CDX_SKIN.visible(id); };
    var chipCounts = function () {
      var by = {}, all = 0, deep = 0;
      rows.forEach(function (r) { if (!modeOk(r.id)) return; all++; if (r.deep === 1) deep++; by[r.cat] = (by[r.cat] || 0) + 1; });
      $$('#filters .filter').forEach(function (b) {
        var c = b.dataset.cat, em = $('em', b); if (c === 'fav') return;
        var n = c === 'all' ? all : (c === 'deep' ? deep : (by[c] || 0));
        if (em) em.textContent = n;
        b.hidden = n === 0 && c !== 'all';
      });
      if (cat !== 'all' && cat !== 'fav' && cat !== 'deep' && !by[cat]) cat = 'all';
    };
    document.addEventListener('cdx-skin', function () { chipCounts(); f(); });
    var eng = window.CDXS ? window.CDXS.create(rows) : null, hint = null, byId = {};
    rows.forEach(function (r) { byId[r.id] = r; });
    var hintEl = function () { if (hint) return hint; hint = document.createElement('p'); hint.className = 'did-you'; hint.hidden = true; grid.parentNode.insertBefore(hint, grid); hint.addEventListener('click', function (e) { var b = e.target.closest('[data-q]'); if (!b) return; q.value = b.getAttribute('data-q'); f(); }); return hint; };
    var stS = $('#stSelect'), tyS = $('#typeSelect'), soS = $('#sortSelect'), rsB = $('#resetFilters'), sugg = $('#suggList');
    var learnedMap = function () { try { return (window.CDXP && CDXP.state().learned) || {}; } catch (e) { return {}; } };
    var syncUrl = function () {
      var u = new URLSearchParams(), qv = q.value.trim();
      if (qv) u.set('q', qv); if (cat !== 'all') u.set('cat', cat); if (lv.value !== 'all') u.set('lv', lv.value);
      if (stS && stS.value !== 'all') u.set('st', stS.value); if (tyS && tyS.value !== 'all') u.set('ty', tyS.value); if (soS && soS.value !== 'rel') u.set('sort', soS.value);
      var qs = u.toString();
      try { history.replaceState(null, '', location.pathname + (qs ? '?' + qs : '')); } catch (_) {}
      if (rsB) rsB.hidden = !(qv || cat !== 'all' || lv.value !== 'all' || (stS && stS.value !== 'all') || (tyS && tyS.value !== 'all') || (soS && soS.value !== 'rel'));
    };
    [['lv', lv], ['st', stS], ['ty', tyS], ['sort', soS]].forEach(function (x) { var v = params.get(x[0]); if (v && x[1] && Array.prototype.some.call(x[1].options, function (o) { return o.value === v; })) x[1].value = v; });
    var f = function (keep) {
      if (!rows.length) return;
      var t = q.value.trim().toLowerCase(), info = null;
      var passes = function (c) {
        var okCat = cat === 'all' || (cat === 'fav' ? fav.has(c.id) : (cat === 'deep' ? c.deep === 1 : c.cat === cat));
        var okLv = lv.value === 'all' || c.level === lv.value;
        var okSt = true, okTy = true;
        if (stS && stS.value !== 'all') { var L = learnedMap(); okSt = stS.value === 'done' ? !!L[c.id] : !L[c.id]; }
        if (tyS && tyS.value !== 'all') okTy = tyS.value === 'cmd' ? !!c.isCmd : !c.isCmd;
        return okCat && okLv && okSt && okTy && modeOk(c.id);
      };
      if (t && eng) {
        info = eng.search(q.value.trim(), { limit: 500, filter: passes });
        matches = info.items.map(function (x) { return byId[x.row.id]; });
      } else {
        matches = rows.filter(function (c) { return passes(c) && c.text.indexOf(t) !== -1; });
        if (window.CDX_SKIN && CDX_SKIN.active()) {
          var rk = {}; matches.forEach(function (c) { rk[c.id] = CDX_SKIN.rank(c.id); });
          matches = matches.map(function (c, i) { return [c, i]; }).sort(function (x, y) { return (rk[x[0].id] - rk[y[0].id]) || (x[1] - y[1]); }).map(function (x) { return x[0]; });
        }
      }
      if (soS && soS.value !== 'rel') {
        var LVR = { 'مبتدئ': 1, 'متوسط': 2, 'متقدم': 3 }, mode = soS.value;
        matches = matches.map(function (c, i) { return [c, i]; }).sort(function (x, y) {
          if (mode === 'az') return x[0].name.toLowerCase().localeCompare(y[0].name.toLowerCase()) || (x[1] - y[1]);
          var d = (LVR[x[0].level] || 0) - (LVR[y[0].level] || 0); if (mode === 'hard') d = -d;
          return d || (x[1] - y[1]);
        }).map(function (x) { return x[0]; });
      }
      syncUrl();
      var h = hintEl(), msg = '';
      if (info && info.did) msg += 'هل تقصد: <button type="button" class="did-b" data-q="' + esc(info.did) + '">' + esc(info.did) + '</button>؟ ';
      if (info && info.approx && matches.length) msg += '<span>لم نجد تطابقًا كاملًا لكل كلماتك، فهذه أقرب النتائج.</span>';
      h.innerHTML = msg; h.hidden = !msg;
      if (keep !== true) shown = PAGE;
      count.textContent = matches.length + ' أداة';
      empty.hidden = matches.length > 0;
      $$('.filter').forEach(function (b) { b.classList.toggle('active', b.dataset.cat === cat); });
      render();
    };
    chipCounts();
    window.__filter = function () { f(true); };
    $('#filters').addEventListener('click', function (e) {
      var b = e.target.closest('[data-cat]'); if (!b) return;
      cat = b.dataset.cat; f();
    });
    var timer = null;
    q.addEventListener('input', function () { clearTimeout(timer); timer = setTimeout(f, 120); });
    lv.addEventListener('change', f);
    [stS, tyS, soS].forEach(function (x) { if (x) x.addEventListener('change', f); });
    if (rsB) rsB.addEventListener('click', function () { q.value = ''; cat = 'all'; lv.value = 'all'; if (stS) stS.value = 'all'; if (tyS) tyS.value = 'all'; if (soS) soS.value = 'rel'; f(); q.focus(); });
    // ---- autocomplete suggestions (combobox)
    if (sugg && eng) {
      var sItems = [], sAct = -1, sTimer = null;
      var sClose = function () { sugg.hidden = true; sugg.textContent = ''; sItems = []; sAct = -1; q.setAttribute('aria-expanded', 'false'); q.removeAttribute('aria-activedescendant'); };
      var sPaint = function () {
        Array.prototype.forEach.call(sugg.children, function (li, i) { li.classList.toggle('on', i === sAct); li.setAttribute('aria-selected', i === sAct ? 'true' : 'false'); });
        if (sAct >= 0) q.setAttribute('aria-activedescendant', 'sg' + sAct); else q.removeAttribute('aria-activedescendant');
      };
      var sOpen = function () {
        var v = q.value.trim(); if (v.length < 2) return sClose();
        var res = eng.search(v, { limit: 6, filter: function (c) { return modeOk(c.id); } });
        sItems = (res && res.items || []).slice(0, 6).map(function (x) { return byId[x.row.id]; }).filter(Boolean);
        if (!sItems.length) return sClose();
        sugg.textContent = '';
        sItems.forEach(function (t, i) {
          var li = document.createElement('li'); li.id = 'sg' + i; li.setAttribute('role', 'option'); li.setAttribute('aria-selected', 'false');
          var b = document.createElement('b'); b.textContent = t.name; var sm = document.createElement('small'); sm.textContent = t.cat + ' • ' + t.level;
          li.appendChild(b); li.appendChild(sm);
          li.addEventListener('mousedown', function (e) { e.preventDefault(); location.href = 'tools/' + t.id + '.html'; });
          sugg.appendChild(li);
        });
        sAct = -1; sugg.hidden = false; q.setAttribute('aria-expanded', 'true');
      };
      q.addEventListener('input', function () { clearTimeout(sTimer); sTimer = setTimeout(sOpen, 90); });
      q.addEventListener('blur', function () { setTimeout(sClose, 120); });
      q.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { if (!sugg.hidden) { sClose(); e.stopPropagation(); } return; }
        if (sugg.hidden || !sItems.length) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); sAct = (sAct + 1) % sItems.length; sPaint(); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); sAct = (sAct <= 0 ? sItems.length : sAct) - 1; sPaint(); }
        else if (e.key === 'Enter' && sAct >= 0) { e.preventDefault(); location.href = 'tools/' + sItems[sAct].id + '.html'; }
      });
    }
    if (moreBtn) moreBtn.addEventListener('click', function () { shown += PAGE; render(); });
    if ('IntersectionObserver' in window && moreWrap) {
      new IntersectionObserver(function (en) { if (en[0].isIntersecting && !moreWrap.hidden) { shown += PAGE; render(); } }, { rootMargin: '400px' }).observe(moreWrap);
    }
    document.addEventListener('keydown', function (e) {
      if (e.key === '/' && !/INPUT|SELECT|TEXTAREA/.test(document.activeElement.tagName)) { e.preventDefault(); q.focus(); }
    });
    f();
  }


  /* ---------- per-tool mini quiz ---------- */
  document.addEventListener('click', function (e) {
    var b = e.target.closest('.mq-opts button'); if (!b) return;
    var box = b.closest('.mq'); if (!box || box.dataset.done) return;
    box.dataset.done = '1';
    var ans = +box.dataset.answer, k = +b.dataset.k;
    $$('.mq-opts button', box).forEach(function (x) { x.disabled = true; if (+x.dataset.k === ans) x.classList.add('ok'); });
    if (k !== ans) b.classList.add('bad');
    var w = $('.mq-why', box), t = $('.mq-t', box);
    w.innerHTML = (k === ans ? '<b>إجابة صحيحة.</b> ' : '<b>ليست الإجابة الصحيحة.</b> ') + (t ? t.innerHTML : '');
    w.hidden = false;
  });

  /* ---------- glossary search + groups ---------- */
  var gg = $('#glGrid');
  if (gg) {
    var gcards = $$('.gl', gg), gq = $('#glSearch'), gcount = $('#glCount'), gempty = $('#glEmpty'), grp = 'all';
    var gf = function () {
      var t = gq.value.trim().toLowerCase(), n = 0;
      gcards.forEach(function (c) {
        var ok = (grp === 'all' || c.dataset.g === grp) && c.dataset.text.indexOf(t) !== -1;
        c.hidden = !ok; if (ok) n++;
      });
      gcount.textContent = n + ' مصطلح';
      gempty.hidden = n > 0;
      $$('#glFilters .filter').forEach(function (b) { b.classList.toggle('active', b.dataset.g === grp); });
    };
    $('#glFilters').addEventListener('click', function (e) { var b = e.target.closest('[data-g]'); if (!b) return; grp = b.dataset.g; gf(); });
    gq.addEventListener('input', gf);
    gf();
    window.addEventListener('hashchange', function () { var el = document.getElementById(location.hash.slice(1)); if (el && el.hidden) { gq.value = ''; grp = 'all'; gf(); } });
  }

  /* ---------- quiz (learn.html) ---------- */
  var box = $('#quizBox');
  if (box) {
    var Q = [
      ['أي أداة تُستخدم لمشاهدة وتحليل حزم الشبكة بصريًا؟', ['John the Ripper', 'Wireshark', 'Autopsy'], 1, 'Wireshark محلّل بروتوكولات يعرض تفاصيل الحزم.'],
      ['ماذا تعني حالة open لمنفذ في نتائج Nmap؟', ['خدمة قبلت الاتصال على هذا المنفذ', 'المنفذ يحتوي ثغرة مؤكدة', 'الجهاز مخترق'], 0, 'المنفذ المفتوح يعني وجود خدمة تستمع؛ وليس ثغرة تلقائيًا.'],
      ['هل التجزئة (hash) تشفير يمكن عكسه؟', ['نعم، بمفتاح سري', 'لا، هي دالة أحادية الاتجاه', 'نعم، بأداة strings'], 1, 'التجزئة ليست تشفيرًا؛ تُستخدم للتحقق من السلامة وتخزين كلمات المرور.'],
      ['ما أول شرط قبل اختبار أي نظام لا تملكه؟', ['تثبيت Kali', 'تصريح مكتوب ونطاق محدد', 'استخدام VPN'], 1, 'التصريح المكتوب والنطاق هما الأساس القانوني والمهني للاختبار.'],
      ['أي أمر يعرض منافذ TCP/UDP المستمعة على جهازك؟', ['ss -tuln', 'ls -la', 'whoami'], 0, 'الأمر ss يعرض المقابس؛ والخيارات tuln تعرض TCP وUDP المستمعة بأرقام المنافذ.'],
      ['كيف تتعامل مع صورة قرص تُعتبر دليلًا رقميًا؟', ['تحليلها مباشرة وتعديلها', 'العمل على نسخة مع حساب hash للأصل', 'حذف الملفات غير المهمة'], 1, 'تُحفظ سلامة الدليل بالعمل على نسخة وتوثيق بصمة الأصل.']
    ];
    var i = 0, score = 0;
    var esc = function (s) { return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); };
    var show = function () {
      if (i >= Q.length) {
        box.innerHTML = '<h3>انتهى الاختبار</h3><p class="quiz-q">نتيجتك: <b>' + score + ' / ' + Q.length + '</b></p><button class="btn sm" id="qr">أعد المحاولة</button>';
        $('#qr').onclick = function () { i = 0; score = 0; show(); }; return;
      }
      var q = Q[i];
      box.innerHTML = '<h3>اختبر معلومة سريعة</h3><div class="quiz-meta"><span>السؤال ' + (i + 1) + ' من ' + Q.length + '</span><span>النتيجة: ' + score + '</span></div><p class="quiz-q">' + esc(q[0]) + '</p><div class="quiz-options">' + q[1].map(function (o, k) { return '<button data-k="' + k + '">' + esc(o) + '</button>'; }).join('') + '</div><div class="quiz-feedback" aria-live="polite"></div>';
      $$('.quiz-options button', box).forEach(function (b) {
        b.onclick = function () {
          var k = +b.dataset.k;
          $$('.quiz-options button', box).forEach(function (x) { x.disabled = true; if (+x.dataset.k === q[2]) x.classList.add('ok'); });
          if (k === q[2]) score++; else b.classList.add('bad');
          var fb = $('.quiz-feedback', box);
          fb.innerHTML = (k === q[2] ? 'إجابة صحيحة. ' : 'ليست الإجابة الصحيحة. ') + esc(q[3]) + ' <button class="btn sm" id="qn" style="margin-inline-start:8px">' + (i + 1 < Q.length ? 'التالي ←' : 'النتيجة') + '</button>';
          $('#qn').onclick = function () { i++; show(); };
        };
      });
    };
    show();
  }

  /* ---------- back to top + active nav ---------- */
  var tt = $('#toTop');
  if (tt) {
    window.addEventListener('scroll', function () { tt.classList.toggle('show', window.scrollY > 700); }, { passive: true });
    tt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }
})();

/* print buttons (no inline handlers: the site's CSP forbids them) */
document.addEventListener('click', function (e) { if (e.target.closest && e.target.closest('[data-print]')) window.print(); });
