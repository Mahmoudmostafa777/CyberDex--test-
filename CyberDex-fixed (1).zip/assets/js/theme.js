/* CyberDex skins: classic / attack / defense / prime + content mode (attack/defense) */
(function () {
  'use strict';
  var SELF = document.currentScript && document.currentScript.src;
  var KEY = 'cdx-skin', KEY_ALL = 'cdx-skin-all';
  var SKINS = {
    classic: { name: 'كلاسيك', sub: 'أخضر نيون: كل الأدوات', mode: null, color: 'linear-gradient(135deg,#2bf07f,#12b886)', bar: '#040806' },
    attack: { name: 'هجومي', sub: 'أحمر في أسود: أدوات الاختبار المصرّح', mode: 'attack', color: 'linear-gradient(135deg,#ff3b4a,#ff7a32)', bar: '#0a0405' },
    defense: { name: 'دفاعي', sub: 'أزرق وسماوي: الحماية والتحليل', mode: 'defense', color: 'linear-gradient(135deg,#4aa8ff,#22d3ee)', bar: '#040a16' },
    prime: { name: 'Prime', sub: 'ذهبي شامبانيا على أسود: فخامة ووقار', mode: null, color: 'linear-gradient(135deg,#f6e6ba,#a8803a)', bar: '#0a0908' }
  };
  var ORDER = ['classic', 'attack', 'defense', 'prime'];
  var NOTE = {
    prime: 'Prime ✦ التجربة الكاملة: كل الأدوات بأرقى واجهة، ومميزات حصرية قادمة.',
    attack: 'الوضع الهجومي: أدوات الاختبار والاستكشاف. استخدمها داخل مختبر تملكه أو بتصريح كتابي فقط.',
    defense: 'الوضع الدفاعي: أدوات الحماية والمراقبة والتحليل الجنائي وتقوية الأنظمة.'
  };
  // hook for achievements later: return false (or a reason) to lock a skin
  var unlocked = function (k) { return true; };
  var reasonOf = function (k) { return 'يُفتح بالإنجازات'; };

  var store = {
    get: function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  };
  var root = document.documentElement;
  var cur = store.get(KEY);
  if (!SKINS[cur] || !unlocked(cur)) cur = 'classic';
  var showAll = store.get(KEY_ALL) === '1';

  var sideMap = null;
  var sideOf = function (id) {
    if (!sideMap) {
      sideMap = {};
      var S = window.CDX_SIDE || {};
      Object.keys(S).forEach(function (k) { S[k].split(' ').forEach(function (i) { if (i) sideMap[i] = k; }); });
    }
    return sideMap[id] || 'n';
  };
  var mode = function () { return SKINS[cur].mode; };
  var active = function () { return !!mode() && !showAll; };
  // is a tool visible under the current skin?
  var visible = function (id) {
    if (!active()) return true;
    var s = sideOf(id);
    return mode() === 'attack' ? (s === 'a' || s === 'b') : (s === 'd' || s === 'b');
  };
  // rank for sorting: own side first, both next, rest last
  var rank = function (id) {
    var s = sideOf(id), m = mode();
    if (!m) return 0;
    var own = m === 'attack' ? 'a' : 'd';
    return s === own ? 0 : (s === 'b' ? 1 : 2);
  };

  function loadFont(k) {
    if (k !== 'prime' || document.getElementById('cdx-amiri')) return;
    var l = document.createElement('link'); l.id = 'cdx-amiri'; l.rel = 'stylesheet';
    l.href = 'https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&display=swap';
    document.head.appendChild(l);
  }
  function apply(k, silent) {
    cur = k; loadFont(k);
    if (!silent) { root.classList.add('skin-fade'); setTimeout(function () { root.classList.remove('skin-fade'); }, 700); }
    if (k === 'classic') root.removeAttribute('data-skin'); else root.setAttribute('data-skin', k);
    var m = document.querySelector('meta[name="theme-color"]');
    if (m) m.setAttribute('content', SKINS[k].bar);
    if (!silent) document.dispatchEvent(new CustomEvent('cdx-skin', { detail: { skin: k } }));
  }
  apply(cur, true);

  var API = window.CDX_SKIN = {
    get: function () { return cur; },
    list: function () { return ORDER.slice(); },
    mode: mode, active: active, visible: visible, rank: rank, sideOf: sideOf,
    set: function (k) {
      if (!SKINS[k] || !unlocked(k)) return false;
      store.set(KEY, k);
      var go = function () { apply(k); refresh(); if (k === 'prime') unveil(); };
      var rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
      if (document.startViewTransition && !rm && btn) {
        // circular reveal expanding from the theme button
        var r = btn.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2;
        var R = Math.hypot(Math.max(x, innerWidth - x), Math.max(y, innerHeight - y));
        try {
          var vt = document.startViewTransition(function () { go(); root.classList.remove('skin-fade'); });
          vt.ready.then(function () {
            root.animate({ clipPath: ['circle(0px at ' + x + 'px ' + y + 'px)', 'circle(' + R + 'px at ' + x + 'px ' + y + 'px)'] },
              { duration: 750, easing: 'cubic-bezier(.65,0,.2,1)', pseudoElement: '::view-transition-new(root)' });
          });
        } catch (e) { go(); }
      } else go();
      return true;
    },
    setUnlockCheck: function (fn, why) {
      unlocked = fn; if (why) reasonOf = why;
      if (cur !== 'classic' && !unlocked(cur)) { store.set(KEY, 'classic'); apply('classic', true); refresh(); } else buildMenu();
    },
    isUnlocked: function (k) { return !!unlocked(k); },
    // temporary look at a locked skin; reverts by itself
    preview: function (k, ms) {
      if (!SKINS[k] || k === cur) return;
      var back = cur; apply(k, true); refresh();
      var n = document.createElement('div'); n.className = 'pwa-toast'; n.setAttribute('role', 'status');
      n.innerHTML = '<span></span>'; n.firstChild.textContent = 'معاينة «' + SKINS[k].name + '» — ' + reasonOf(k);
      document.body.appendChild(n);
      setTimeout(function () { if (cur === k) { apply(back, true); refresh(); } if (n.parentNode) n.parentNode.removeChild(n); }, ms || 9000);
    }
  };

  function unveil() {
    if (window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches) return;
    var d = document.createElement('div'); d.className = 'prime-unveil';
    d.innerHTML = '<div class="pu"><svg viewBox="0 0 96 80" aria-hidden="true"><defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#fff3cf"/><stop offset=".5" stop-color="#d4af6a"/><stop offset="1" stop-color="#8d6a2b"/></linearGradient></defs><path d="M10 62 18 22l20 20 10-30 10 30 20-20 8 40Z" fill="rgba(212,175,106,.12)" stroke="url(#pg)" stroke-width="3" stroke-linejoin="round"/><rect x="10" y="66" width="76" height="8" rx="2" fill="url(#pg)"/><circle cx="18" cy="20" r="4" fill="url(#pg)"/><circle cx="48" cy="9" r="4.5" fill="url(#pg)"/><circle cx="78" cy="20" r="4" fill="url(#pg)"/></svg><i></i><b>PRIME</b><span>التجربة الكاملة · CyberDex</span></div>';
    document.body.appendChild(d);
    setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); }, 2700);
  }

  /* ---------- UI ---------- */
  var wrap, btn, menu, bar;
  function buildMenu() {
    if (!menu) return;
    menu.innerHTML = '';
    ORDER.forEach(function (k) {
      var s = SKINS[k], ok = unlocked(k);
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'skin-opt'; b.setAttribute('role', 'menuitemradio');
      b.setAttribute('aria-checked', k === cur ? 'true' : 'false');
      if (!ok) b.classList.add('locked');
      b.innerHTML = '<span class="skin-dot" style="background:' + s.color + '"></span><span><b></b><small></small></span>';
      b.querySelector('b').textContent = s.name;
      b.querySelector('small').textContent = ok ? s.sub : '🔒 ' + reasonOf(k) + ' · اضغط للمعاينة';
      b.addEventListener('click', function () { if (ok) API.set(k); else API.preview(k); close(); });
      menu.appendChild(b);
    });
  }
  function close() { if (menu) { menu.hidden = true; btn.setAttribute('aria-expanded', 'false'); } }
  function refresh() {
    if (btn) { btn.querySelector('.skin-dot').style.background = SKINS[cur].color; }
    buildMenu();
    paintBar();
    paintContent();
  }
  function paintBar() {
    var m = mode(), key = m || (cur === 'prime' ? 'prime' : null);
    if (!key) { if (bar) { bar.remove(); bar = null; } return; }
    if (!bar) {
      bar = document.createElement('div'); bar.className = 'mode-bar'; bar.setAttribute('role', 'status');
      bar.innerHTML = '<div class="wrap"><span></span><button type="button"></button></div>';
      var header = document.querySelector('.topbar');
      if (header && header.parentNode) header.parentNode.insertBefore(bar, header.nextSibling);
      bar.querySelector('button').addEventListener('click', function () {
        showAll = !showAll; store.set(KEY_ALL, showAll ? '1' : '0');
        paintBar(); paintContent(); document.dispatchEvent(new CustomEvent('cdx-skin', { detail: { skin: cur } }));
      });
    }
    bar.querySelector('span').innerHTML = (m ? '<b>' + SKINS[cur].name + '</b> · ' : '') + NOTE[key];
    var bt = bar.querySelector('button'); bt.hidden = !m;
    bt.textContent = showAll ? 'التركيز على الوضع' : 'عرض كل الأدوات';
  }

  /* ---------- content filtering for static pages ---------- */
  var PATH_SIDE = { beginner: 'n', web: 'a', packets: 'b', forensics: 'd', defense: 'd', reverse: 'b', 'linux-basics': 'n', automation: 'n', sysadmin: 'd', hardening: 'd', 'net-admin': 'b', 'lab-audit': 'a', databases: 'n' };
  var hideSide = function (s) { // hide opposite-side items only (paths)
    if (!active() || s === 'n' || s === 'b') return false;
    return (mode() === 'attack' ? 'a' : 'd') !== s;
  };
  function paintContent() {
    // learning paths
    Array.prototype.forEach.call(document.querySelectorAll('.path-sec'), function (sec) {
      var hide = hideSide(PATH_SIDE[sec.id] || 'n');
      sec.classList.toggle('mode-hide', hide);
      var chip = document.querySelector('a.chip[href="#' + sec.id + '"]');
      if (chip) chip.classList.toggle('mode-hide', hide);
    });
    // goals
    var goals = document.querySelectorAll('.goal');
    if (goals.length) {
      Array.prototype.forEach.call(goals, function (g) {
        var ids = Array.prototype.map.call(g.querySelectorAll('a[href*="tools/"]'), function (a) {
          var m = a.getAttribute('href').match(/tools\/([^/.#?]+)\.html/); return m ? m[1] : null;
        }).filter(Boolean);
        var hide = false;
        if (active() && ids.length) hide = !ids.some(visible);
        g.classList.toggle('mode-hide', hide);
      });
      document.dispatchEvent(new CustomEvent('cdx-mode'));
    }
    // home category tiles
    Array.prototype.forEach.call(document.querySelectorAll('.cat-tile'), function (t) {
      var m = (t.getAttribute('href') || '').match(/cat=([^&]+)/); if (!m || !window.CDX_CNT) return;
      var cat = decodeURIComponent(m[1]), c = window.CDX_CNT[cat]; if (!c) return;
      var n = active() ? (mode() === 'attack' ? c[0] : c[1]) : c[2];
      t.classList.toggle('mode-hide', n === 0);
      var em = t.querySelector('em'); if (em) em.textContent = n + ' أداة';
    });
  }
  API.refresh = refresh;

  function init() {
    var acts = document.querySelector('.top-actions');
    if (acts) {
      wrap = document.createElement('div'); wrap.className = 'skin-wrap';
      btn = document.createElement('button'); btn.type = 'button'; btn.className = 'skin-btn';
      btn.setAttribute('aria-haspopup', 'true'); btn.setAttribute('aria-expanded', 'false'); btn.setAttribute('aria-label', 'تغيير الثيم');
      btn.innerHTML = '<span class="skin-dot"></span><span class="skin-lbl">الثيم</span>';
      menu = document.createElement('div'); menu.className = 'skin-menu'; menu.hidden = true; menu.setAttribute('role', 'menu');
      wrap.appendChild(btn); wrap.appendChild(menu);
      var mb = acts.querySelector('.menu-btn');
      acts.insertBefore(wrap, mb || null);
      btn.addEventListener('click', function (e) {
        e.stopPropagation(); menu.hidden = !menu.hidden; btn.setAttribute('aria-expanded', menu.hidden ? 'false' : 'true');
      });
      document.addEventListener('click', function (e) { if (!wrap.contains(e.target)) close(); });
      document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
    }
    refresh();
  }
  /* spotlight: cards glow where the pointer is */
  var SPOT = '.tool,.cat-tile,.stat,.panel,.path-item,.res';
  document.addEventListener('pointermove', function (e) {
    var t = e.target.closest && e.target.closest(SPOT); if (!t) return;
    var r = t.getBoundingClientRect();
    t.style.setProperty('--mx', (e.clientX - r.left) + 'px'); t.style.setProperty('--my', (e.clientY - r.top) + 'px');
  }, { passive: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  if (SELF && /theme\.js/.test(SELF)) {
    var loadFx = function () { ['fx.js', 'pwa.js', 'achievements.js'].forEach(function (f) { var s = document.createElement('script'); s.src = SELF.replace(/theme\.js.*$/, f); s.defer = true; document.head.appendChild(s); }); };
    if (document.readyState === 'complete') loadFx(); else addEventListener('load', loadFx);
  }
})();
