// Certificate view + verification page.
(function () {
  var app = document.getElementById('certApp'), ver = document.getElementById('verifyApp');
  if (!app && !ver) return;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function qs(k) { try { return new URLSearchParams(location.search).get(k) || ''; } catch (e) { return ''; } }
  function dateAr(ts) { try { return new Date(ts).toLocaleDateString('ar-EG-u-nu-latn', { year: 'numeric', month: 'long', day: 'numeric' }); } catch (e) { return new Date(ts).toISOString().slice(0, 10); } }
  function verifyUrl(code) { return location.href.replace(/[^\/]*$/, '').replace(/\/$/, '/') + 'verify.html?code=' + encodeURIComponent(code); }
  function sb(cb, tries) { if (window.CDX_SB) return cb(window.CDX_SB); if ((tries || 0) > 40) return cb(null); setTimeout(function () { sb(cb, (tries || 0) + 1); }, 150); }

  var NS = 'http://www.w3.org/2000/svg';
  function u(px) { return (px / 15.36).toFixed(3) + 'cqw'; }
  function box(x, y, w, h, css, inner, cls) { return '<div class="cc-el ' + (cls || '') + '" style="left:' + u(x) + ';top:' + u(y) + ';width:' + u(w) + ';height:' + u(h) + ';' + (css || '') + '">' + (inner == null ? '' : inner) + '</div>'; }
  function fs(px) { return 'font-size:' + u(px) + ';'; }
  function isoDate(ts) { var d = new Date(ts); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function catSize(t) { var n = t.length; return n > 34 ? 38 : n > 26 ? 44 : n > 18 ? 52 : 60; }
  function paper(c, code, light) {
    var v = verifyUrl(code).replace(/^https?:\/\//, '');
    var corners = '<svg class="cc-frame" viewBox="0 0 1536 1024" preserveAspectRatio="none" aria-hidden="true"><g fill="none" stroke="currentColor" stroke-linecap="round">' +
      '<path d="M22 150V52Q22 22 52 22H360" stroke-width="5"/><path d="M40 120V66Q40 40 66 40H250" stroke-width="2" opacity=".6"/><circle cx="150" cy="90" r="5" opacity=".7"/>' +
      '<path d="M1514 150V52Q1514 22 1484 22H1176" stroke-width="5"/><path d="M1496 120V66Q1496 40 1470 40H1286" stroke-width="2" opacity=".6"/><circle cx="1386" cy="90" r="5" opacity=".7"/>' +
      '<path d="M22 874V972Q22 1002 52 1002H360" stroke-width="5"/><path d="M40 904V958Q40 984 66 984H250" stroke-width="2" opacity=".6"/>' +
      '<path d="M1514 874V972Q1514 1002 1484 1002H1176" stroke-width="5"/><path d="M1496 904V958Q1496 984 1470 984H1286" stroke-width="2" opacity=".6"/>' +
      '<path d="M22 420V360M1514 420V360M22 640V700M1514 640V700" stroke-width="3" opacity=".5"/></g></svg>';
    var shield = '<svg class="cc-shield" viewBox="0 0 200 230" aria-hidden="true"><path d="M100 8 L186 40 V112 C186 164 150 200 100 222 C50 200 14 164 14 112 V40 Z" fill="none" stroke="currentColor" stroke-width="7"/><path d="M100 24 L170 50 V112 C170 154 142 184 100 204 C58 184 30 154 30 112 V50 Z" fill="currentColor" opacity=".08"/><rect x="66" y="98" width="68" height="56" rx="8" fill="currentColor"/><path d="M80 98V82a20 20 0 0 1 40 0V98" fill="none" stroke="currentColor" stroke-width="9"/><circle cx="100" cy="122" r="7" fill="var(--cc-bg)"/><rect x="97" y="124" width="6" height="18" rx="3" fill="var(--cc-bg)"/></svg>';
    var h = '<div class="cc' + (light ? ' light' : '') + '" id="certPaper">' + corners;
    h += box(-30, 250, 520, 700, '', '<img src="assets/img/mark.png" alt="">', 'cc-fig');
    h += box(1255, 235, 220, 252, '', shield, 'cc-shieldbox');
    h += box(0, 36, 1536, 150, 'display:flex;align-items:center;justify-content:center;gap:' + u(22) + ';direction:ltr', '<img class="cc-logo" src="assets/img/mark.png" alt="" style="width:' + u(132) + ';height:' + u(132) + '"><div class="cc-wm"><div style="' + fs(104) + '"><span>Cyber</span><b>Dex</b></div><small style="' + fs(23) + '">LEARN · EXPLORE · STAY SECURE</small></div>');
    h += box(0, 196, 1536, 120, 'text-align:center;', '<div class="cc-metal" style="' + fs(92) + 'line-height:1.25">شهادة إتمام</div>');
    h += box(0, 312, 1536, 50, 'text-align:center;', '<div class="cc-en" style="' + fs(30) + '"><i></i><span>CERTIFICATE OF COMPLETION</span><i></i></div>');
    h += box(0, 372, 1536, 50, 'text-align:center;', '<div class="cz-t" style="' + fs(33) + '">تشهد منصة CyberDex بأن</div>');
    h += box(168, 412, 1200, 130, 'text-align:center;', '<div class="cc-name cc-metal" style="' + fs(c.name.length > 26 ? 66 : c.name.length > 18 ? 80 : 94) + '">' + esc(c.name) + '</div>');
    h += box(356, 548, 824, 4, '', '', 'cc-rule');
    h += box(0, 566, 1536, 50, 'text-align:center;', '<div class="cz-t" style="' + fs(31) + '">قد اجتاز اختبار قسم</div>');
    h += box(300, 616, 936, 100, '', '<div class="cc-banner"><div><span style="' + fs(catSize(c.cat)) + '">' + esc(c.cat) + '</span></div></div>');
    h += box(0, 718, 1536, 46, 'text-align:center;', '<div class="cz-t" style="' + fs(28) + '">بنسبة نجاح <b class="cc-acc">' + c.score + '%</b></div>');
    h += box(56, 796, 480, 80, 'text-align:center;white-space:nowrap;', '<div class="cc-sign" style="' + fs(58) + '">CyberDex Team</div>');
    h += box(96, 886, 400, 3, '', '', 'cc-rule');
    h += box(96, 898, 400, 40, 'text-align:center;', '<div class="cz-t" style="' + fs(25) + '">فريق CyberDex</div>');
    h += box(648, 762, 240, 250, '', '<div class="cc-rib"><i></i><i></i></div><div class="cc-seal"><div class="cc-seal-in"><img src="assets/img/mark.png" alt=""><b style="' + fs(30) + '">CyberDex</b><span style="' + fs(20) + '">★ ★ ★</span></div></div>');
    h += box(1040, 788, 420, 50, 'display:flex;align-items:center;gap:' + u(18) + ';justify-content:flex-start;direction:ltr', '<span class="cc-ico" style="' + fs(40) + '">▦</span><span class="cz-t" style="' + fs(30) + '">Date: ' + isoDate(c.ts) + '</span>');
    h += box(1040, 842, 420, 3, '', '', 'cc-rule');
    h += box(1040, 860, 440, 50, 'display:flex;align-items:center;gap:' + u(18) + ';direction:ltr', '<span class="cc-ico" style="' + fs(40) + ';font-weight:800">#</span><span class="cz-t" style="' + fs(28) + '">Cert ID: ' + esc(code) + '</span>');
    h += box(0, 976, 1536, 36, 'text-align:center;', '<div class="cc-foot" style="' + fs(17) + '">شهادة تعليمية صادرة من CyberDex وليست معتمدة رسميًا من أي جهة · للتحقق: <span dir="ltr">' + esc(v) + '</span></div>');
    return h + '</div>';
  }

  function png(c, code, light) {
    var img = new Image(), done = false;
    function go(ok) {
      if (done) return; done = true;
      var W = 1536, H = 1024, S = 2, cv = document.createElement('canvas'); cv.width = W * S; cv.height = H * S; var x = cv.getContext('2d'); x.scale(S, S);
      var K = light ? { bg: '#fffdf8', fg: '#111', t: '#333', acc: '#0f8a43', dex: '#0f8a43', cy: '#0b3d2a', line: '#0f8a43', gold: '#8d6a2b', met: ['#4a3410', '#a07a2c', '#4a3410'] } : { bg: '#030906', fg: '#fff', t: '#e8efe9', acc: '#22e06b', dex: '#22e06b', cy: '#fff', line: '#22e06b', gold: '#e0b34f', met: ['#ffffff', '#c9d2cc', '#ffffff'] };
      var F = '"IBM Plex Sans Arabic","Amiri","Noto Naskh Arabic",Tahoma,sans-serif';
      x.fillStyle = K.bg; x.fillRect(0, 0, W, H);
      if (!light) { var g = x.createRadialGradient(W / 2, 120, 20, W / 2, 300, 760); g.addColorStop(0, 'rgba(34,224,107,.16)'); g.addColorStop(1, 'rgba(34,224,107,0)'); x.fillStyle = g; x.fillRect(0, 0, W, H); }
      x.strokeStyle = K.line; x.lineCap = 'round';
      function path(d, w, a) { x.globalAlpha = a || 1; x.lineWidth = w; x.stroke(new Path2D(d)); x.globalAlpha = 1; }
      path('M22 150V52Q22 22 52 22H360', 5); path('M40 120V66Q40 40 66 40H250', 2, .6); path('M1514 150V52Q1514 22 1484 22H1176', 5); path('M1496 120V66Q1496 40 1470 40H1286', 2, .6);
      path('M22 874V972Q22 1002 52 1002H360', 5); path('M40 904V958Q40 984 66 984H250', 2, .6); path('M1514 874V972Q1514 1002 1484 1002H1176', 5); path('M1496 904V958Q1496 984 1470 984H1286', 2, .6);
      if (ok) { x.globalAlpha = light ? .07 : .5; x.drawImage(img, -30, 250, 520, 520); x.globalAlpha = 1; x.drawImage(img, 470, 46, 132, 132); }
      // shield
      x.save(); x.translate(1265, 245); x.scale(1.05, 1.05); x.strokeStyle = K.line; x.fillStyle = K.line; x.lineWidth = 7;
      x.stroke(new Path2D('M100 8 L186 40 V112 C186 164 150 200 100 222 C50 200 14 164 14 112 V40 Z')); x.fillRect(66, 98, 68, 56); x.lineWidth = 9; x.stroke(new Path2D('M80 98V82a20 20 0 0 1 40 0V98')); x.fillStyle = K.bg; x.beginPath(); x.arc(100, 122, 7, 0, 7); x.fill(); x.fillRect(97, 124, 6, 18); x.restore();
      x.textAlign = 'center'; x.direction = 'rtl'; x.textBaseline = 'alphabetic';
      function T(s, px, y, col, w, cx) { x.font = (w || 500) + ' ' + px + 'px ' + F; x.fillStyle = col; x.fillText(s, cx == null ? W / 2 : cx, y); }
      function metal(s, px, y) { x.font = '800 ' + px + 'px ' + F; var m = x.measureText(s).width, gr = x.createLinearGradient(0, y - px, 0, y); gr.addColorStop(0, K.met[0]); gr.addColorStop(.55, K.met[1]); gr.addColorStop(1, K.met[2]); x.fillStyle = gr; x.fillText(s, W / 2, y); }
      // wordmark
      x.direction = 'ltr'; x.font = '800 104px ' + F; var w1 = x.measureText('Cyber').width, w2 = x.measureText('Dex').width, sx = 640 + 400 - (w1 + w2) / 2 + 40; x.textAlign = 'left'; x.fillStyle = K.cy; x.fillText('Cyber', 625, 140); x.fillStyle = K.dex; x.fillText('Dex', 625 + w1, 140); x.textAlign = 'center';
      x.font = '500 23px ' + F; x.fillStyle = K.t; if ('letterSpacing' in x) x.letterSpacing = '5px'; x.fillText('LEARN · EXPLORE · STAY SECURE', 625 + (w1 + w2) / 2, 176); if ('letterSpacing' in x) x.letterSpacing = '0px';
      x.direction = 'rtl';
      metal('شهادة إتمام', 92, 282);
      x.direction = 'ltr'; if ('letterSpacing' in x) x.letterSpacing = '8px'; T('CERTIFICATE OF COMPLETION', 30, 346, K.acc, 700); if ('letterSpacing' in x) x.letterSpacing = '0px'; x.direction = 'rtl';
      T('تشهد منصة CyberDex بأن', 33, 410, K.t);
      var np = c.name.length > 26 ? 66 : c.name.length > 18 ? 80 : 94; metal(c.name, np, 506);
      x.fillStyle = K.line; x.fillRect(356, 548, 824, 3);
      T('قد اجتاز اختبار قسم', 31, 604, K.t);
      // banner
      x.save(); x.strokeStyle = K.line; x.lineWidth = 4; x.fillStyle = light ? 'rgba(15,138,67,.07)' : 'rgba(34,224,107,.08)'; x.beginPath(); x.moveTo(330, 666); x.lineTo(372, 622); x.lineTo(1164, 622); x.lineTo(1206, 666); x.lineTo(1164, 710); x.lineTo(372, 710); x.closePath(); x.fill(); x.stroke(); x.restore();
      var cp = catSize(c.cat); T(c.cat, cp, 666 + cp * .35, K.acc, 800);
      T('بنسبة نجاح ' + c.score + '%', 28, 752, K.t, 600);
      // signature
      x.direction = 'ltr'; x.font = 'italic 58px "Segoe Script","Brush Script MT","Snell Roundhand",cursive'; x.fillStyle = K.fg; x.fillText('CyberDex Team', 296, 850); x.fillStyle = K.line; x.fillRect(96, 886, 400, 3); x.direction = 'rtl'; T('فريق CyberDex', 25, 925, K.t, 500, 296);
      // seal
      var cx = 768, cy = 876; x.save(); var rg = x.createRadialGradient(cx - 30, cy - 36, 10, cx, cy, 120); rg.addColorStop(0, '#fff2b8'); rg.addColorStop(.45, '#e0b34f'); rg.addColorStop(1, '#8d6a2b');
      x.fillStyle = '#1c8a4a'; x.beginPath(); x.moveTo(cx - 60, cy + 60); x.lineTo(cx - 34, cy + 104); x.lineTo(cx - 12, cy + 88); x.lineTo(cx + 12, cy + 104); x.lineTo(cx + 34, cy + 60); x.closePath(); x.fill();
      x.fillStyle = rg; x.beginPath(); for (var i = 0; i < 40; i++) { var a = i / 40 * Math.PI * 2, r = i % 2 ? 98 : 106; x.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } x.closePath(); x.fill();
      x.strokeStyle = 'rgba(80,50,0,.55)'; x.lineWidth = 3; x.beginPath(); x.arc(cx, cy, 82, 0, 7); x.stroke(); x.restore();
      if (ok) x.drawImage(img, cx - 34, cy - 62, 68, 68); x.direction = 'ltr'; T('CyberDex', 25, cy + 30, '#3a2608', 800, cx); T('★ ★ ★', 18, cy + 56, '#3a2608', 700, cx);
      // date + id
      x.textAlign = 'left'; x.direction = 'ltr'; x.font = '500 30px ' + F; x.fillStyle = K.t; x.fillText('Date: ' + isoDate(c.ts), 1100, 826); x.fillStyle = K.line; x.fillRect(1040, 842, 420, 3); x.font = '800 38px ' + F; x.fillText('#', 1046, 902); x.font = '500 28px ' + F; x.fillStyle = K.t; x.fillText('Cert ID: ' + code, 1100, 900);
      x.font = '800 36px ' + F; x.fillStyle = K.line; x.fillText('▦', 1046, 828);
      x.textAlign = 'center'; x.direction = 'rtl'; T('شهادة تعليمية صادرة من CyberDex وليست معتمدة رسميًا من أي جهة', 17, 1003, light ? '#555' : '#8fa398');
      cv.toBlob(function (b) { var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'CyberDex-' + code + '.png'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500); });
    }
    img.onload = function () { go(true); }; img.onerror = function () { go(false); }; img.src = 'assets/img/mark.png';
    setTimeout(function () { go(false); }, 2500);
  }

  if (app) {
    var light = false, code = qs('code').toUpperCase(), W = function () { if (!window.CDXP) return setTimeout(W, 100); draw(); };
    var draw = function () {
      var S = window.CDXP.state(), c = S.certs[code];
      if (!c) { app.innerHTML = '<div class="cert-empty"><h2>لم نجد هذه الشهادة على هذا الجهاز</h2><p>إن كانت شهادتك صادرة من جهاز آخر وسجّلت الدخول، فستظهر هنا بعد تحميل حسابك. أو تحقق منها عبر <a href="verify.html?code=' + encodeURIComponent(code) + '">صفحة التحقق</a>.</p><p><a class="btn" href="exams.html">الاختبارات</a></p></div>'; return; }
      var status = c.v ? '<span class="cert-st ok">✔ موثّقة في حساب CyberDex ويمكن لأي شخص التحقق منها</span>' : '<span class="cert-st">غير موثّقة بعد: سجّل الدخول من أعلى الصفحة لتوثيقها وتمكين التحقق منها.</span>';
      app.innerHTML = '<div class="cert-bar no-print">' + status + '<div class="cert-btns"><button class="btn primary" id="cPrint" type="button">طباعة / حفظ PDF</button><button class="btn" id="cPng" type="button">حفظ كصورة</button><button class="btn" id="cLight" type="button">نسخة فاتحة</button><button class="btn" id="cCopy" type="button">نسخ رابط التحقق</button></div></div><div class="cc-wrap">' + paper(c, code, light) + '</div>';
      document.getElementById('cPrint').onclick = function () { window.print(); };
      document.getElementById('cPng').onclick = function () { (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(function () { png(c, code, light); }); };
      document.getElementById('cLight').onclick = function () { light = !light; this.textContent = light ? 'نسخة داكنة' : 'نسخة فاتحة'; document.getElementById('certPaper').classList.toggle('light', light); };
      document.getElementById('cCopy').onclick = function () { var b = this; try { navigator.clipboard.writeText(verifyUrl(code)); b.textContent = 'تم النسخ'; setTimeout(function () { b.textContent = 'نسخ رابط التحقق'; }, 1200); } catch (e) { prompt('انسخ الرابط', verifyUrl(code)); } };
    };
    W();
    document.addEventListener('cdx-progress', function () { if (window.CDXP) draw(); });
  }

  if (ver) {
    var inp = ver.querySelector('input'), out = ver.querySelector('.ver-out'), form = ver.querySelector('form');
    function check(code) {
      code = (code || '').trim().toUpperCase(); if (!code) return;
      out.innerHTML = '<p class="ex-rule">جارٍ التحقق…</p>';
      sb(function (s) {
        if (!s) { out.innerHTML = '<p class="ex-rule">تعذّر الاتصال بخدمة التحقق الآن. حاول لاحقًا.</p>'; return; }
        s.rpc('verify_certificate', { p_code: code }).then(function (r) {
          var d = r.data && r.data[0];
          if (r.error) out.innerHTML = '<p class="ex-rule">تعذّر التحقق الآن. حاول لاحقًا.</p>';
          else if (!d) out.innerHTML = '<div class="ver-res no"><h2>لم نجد هذه الشهادة</h2><p>تأكد من كتابة الرقم كما هو على الشهادة. الشهادات غير الموثّقة بحساب لا تظهر هنا.</p></div>';
          else out.innerHTML = '<div class="ver-res ok"><h2>✔ شهادة صحيحة</h2>' + paper({ name: d.name, cat: d.category, score: d.score, ts: d.issued_at }, code) + '</div>';
        });
      });
    }
    form.addEventListener('submit', function (e) { e.preventDefault(); check(inp.value); });
    var c0 = qs('code'); if (c0) { inp.value = c0; check(c0); }
  }
})();
