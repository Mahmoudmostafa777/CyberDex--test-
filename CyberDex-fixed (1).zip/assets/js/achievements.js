// CyberDex achievements: daily challenge, badges, levels and theme unlocks. State lives in the progress blob (CDXP).
(function () {
  var SELF = document.currentScript && document.currentScript.src;
  var base = SELF ? SELF.replace(/achievements\.js.*$/, '') : 'assets/js/';
  var T=[["nmap",0],["wireshark",1],["burp",2],["zap",2],["john",3],["hashcat",3],["metasploit",4],["sqlmap",2],["autopsy",5],["volatility",5],["tcpdump",1],["gpg",6],["searchsploit",4],["nikto",2],["netcat",7],["aircrack",8],["recon-ng",9],["binwalk",5],["foremost",5],["lynis",10],["whatweb",2],["dig",7],["whois",9],["traceroute",7],["arp-scan",0],["theharvester",9],["hashid",3],["exiftool",5],["strings",11],["file",11],["steghide",5],["gobuster",2],["ffuf",2],["enum4linux-ng",0],["curl",12],["openssl",6],["tshark",1],["testssl",6],["yara",11],["clamav",10],["chkrootkit",10],["rkhunter",10],["radare2",13],["ghidra",13],["sleuthkit",5],["hashdeep",5],["nmcli",7],["ss",7],["amass",9],["dnsrecon",9],["dnsenum",9],["fierce",9],["subfinder",9],["spiderfoot",9],["maltego",9],["nbtscan",0],["netdiscover",0],["masscan",0],["hping3",0],["nping",0],["snmpwalk",0],["smbclient",0],["smbmap",0],["ncat",7],["socat",7],["iperf3",14],["mtr",14],["ip",7],["bettercap",4],["ettercap",4],["kismet",8],["grep",15],["find",15],["awk",15],["jq",12],["tmux",12],["ssh",16],["rsync",12],["systemctl",17],["journalctl",17],["lsof",12],["git",12],["tar",18],["ps",19],["wpscan",2],["wafw00f",2],["dirb",2],["dirsearch",2],["nuclei",2],["wfuzz",2],["mitmproxy",2],["sslscan",6],["sslyze",6],["hydra",3],["medusa",3],["crunch",3],["cewl",3],["bulk_extractor",5],["ddrescue",5],["testdisk",5],["photorec",5],["scalpel",5],["dc3dd",5],["gdb",13],["objdump",13],["readelf",13],["strace",13],["ltrace",13],["apktool",13],["jadx",13],["suricata",20],["zeek",20],["snort",20],["fail2ban",20],["auditd",20],["aide",20],["ufw",20],["nftables",20],["tor",21],["proxychains",21],["openvpn",21],["wireguard",21],["cryptsetup",6],["ssh-keygen",16],["sha256sum",6],["cherrytree",22],["pandoc",22],["docker",23],["virtualbox",22],["ping",7],["sed",15],["htop",19],["chmod",24],["cron",19],["iptables",20],["iftop",14],["nslookup",7],["base64",6],["osquery",20],["wazuh",20],["crowdsec",20],["sudo",24],["trivy",25],["semgrep",25],["gitleaks",25],["bandit",25],["openvas",10],["oletools",11],["pdfid",11],["veracrypt",6],["wget",12],["xxd",11],["diff",15],["ssdeep",5],["last",20],["lsblk",5],["uniq",15],["stat",5],["netstat",7],["dmesg",12],["nethogs",14],["ssh-audit",16],["who",20],["ipcalc",7],["ngrep",1],["tcpflow",1],["getfacl",24],["chage",24],["tree",15],["sort",15],["cut",15],["xargs",15],["watch",19],["sqlite3",26],["tail",15],["less",15],["du",27],["df",27],["head",15],["id",24],["lsusb",27],["fping",0],["arping",0],["wc",15],["tee",15],["tr",15],["kill",19],["uname",27],["which",12],["history",12],["env",12],["host",7],["tracepath",7],["ethtool",7],["lastlog",20],["lsmod",27],["free",19],["top",19],["uptime",19],["md5sum",6],["iw",8],["ssh-keyscan",16],["mat2",21],["shred",27],["script",22],["rfkill",8],["pwgen",3],["age",6],["lsattr",24],["lastb",20],["httpie",2],["dd",5],["hexdump",11],["blkid",27],["mount",27],["resolvectl",7],["vnstat",14],["debsums",20],["logger",20],["passwd",24],["aa-status",10],["sysctl",10],["getent",24],["vmstat",19],["lspci",27],["ssh-copy-id",16],["umask",24],["visudo",24],["iotop",19],["lscpu",27],["7z",18],["fdisk",27],["ncdu",27],["rg",15],["timeout",19],["dmidecode",27],["smartctl",27],["iostat",19],["pgrep",19],["ln",12],["chown",24],["zip",18],["logrotate",20],["ausearch",20],["usermod",24],["nload",14],["lynx",2],["macchanger",21],["nm",13],["cmp",15],["ls",12],["cd",12],["pwd",12],["cat",15],["cp",12],["mv",12],["rm",12],["mkdir",12],["touch",12],["echo",12],["man",12],["whoami",24],["hostname",12],["date",12],["alias",12],["column",15],["paste",15],["comm",15],["nl",15],["od",15],["ifconfig",7],["route",7],["arp",7],["scp",16],["sftp",16],["ssh-agent",16],["telnet",16],["hostnamectl",17],["bmon",14],["nohup",19],["screen",19],["nice",19],["renice",19],["crontab",19],["dpkg",12],["apt",12],["lshw",27],["hdparm",27],["parted",27],["gzip",18],["xz",18],["exiv2",5],["pdftotext",11],["sha1sum",6],["lnav",20],["getcap",24],["needrestart",10],["auditctl",20],["aureport",20],["unzip",18],["bzip2",18],["basename",28],["dirname",28],["realpath",28],["seq",28],["sleep",28],["bc",28],["printf",28],["jobs",19],["killall",19],["pkill",19],["pstree",19],["fuser",19],["modinfo",27],["systemd-analyze",17],["loginctl",17],["timedatectl",17],["chronyc",17],["swapon",27],["openssl-s_client",6],["ip6tables",20],["iwlist",8],["iwconfig",8],["wpa_supplicant",8],["dnsmasq",7],["tcptraceroute",7],["ping6",7],["setcap",24],["capsh",24],["unshare",23],["chroot",23],["lsns",23],["oscap",10],["freshclam",10],["clamdscan",10],["trufflehog",25],["shellcheck",28],["hadolint",23],["grype",25],["syft",25],["fls",5],["icat",5],["mmls",5],["istat",5],["mactime",5],["extundelete",5],["pngcheck",11],["mediainfo",11],["floss",13],["mkswap",27],["psql",26],["mysql",26],["redis-cli",26],["mysqldump",26],["pg_dump",26],["mongosh",26],["asciinema",22],["vagrant",22],["umount",27],["groups",24],["sha512sum",6],["useradd",24],["userdel",24],["chgrp",24],["su",24],["split",15],["shuf",15],["tac",15],["patch",15],["w",20],["nsenter",23],["setpriv",23],["ionice",19],["taskset",19],["prlimit",19],["flock",28],["mktemp",28],["chattr",24],["ldd",13],["truncate",27],["groupadd",24],["groupdel",24],["gpasswd",24],["lslogins",24],["lslocks",19],["ipcs",19],["systemd-detect-virt",17],["join",15],["base32",6],["setsid",19],["losetup",27],["dumpe2fs",5],["tune2fs",27],["e2fsck",27],["debugfs",5],["wipefs",27],["findmnt",27],["mountpoint",27],["fallocate",27],["readlink",28],["pwck",24],["grpck",24],["b2sum",6],["cksum",6],["swapoff",27],["lsmem",27],["blockdev",27],["install",12],["mkfifo",12],["whereis",12],["fold",15],["rev",15],["csplit",15],["tsort",15],["numfmt",15],["factor",28],["nproc",28],["pmap",19],["chrt",19],["stdbuf",19],["getconf",27],["iconv",15],["namei",24],["basenc",6],["lsipc",19],["expand",15],["unexpand",15],["sync",27],["ar",18],["mcookie",6],["sdiff",15],["diff3",15],["fmt",15],["pidof",19],["printenv",28],["zcat",18],["zgrep",18],["zipinfo",18],["ldconfig",27],["mknod",27],["pr",15],["yes",28],["pathchk",28],["locale",27],["rmdir",12],["sha384sum",6],["bzcat",18],["xzcat",18],["getopt",28],["unlink",12],["zipdetails",18],["xmllint",15],["shasum",6],["filefrag",27],["e2label",27],["badblocks",27],["getpcaps",24],["pwdx",19],["ffprobe",5],["zdump",17],["ndisasm",13],["nasm",13],["valgrind",13],["setarch",13],["identify",11],["qpdf",11],["tesseract",5],["e2image",5],["keytool",6],["dot",22],["ipcmk",19],["ipcrm",19],["e2freefrag",27],["resize2fs",27],["swaplabel",27],["choom",19],["hardlink",12],["pidwait",19],["zipnote",18],["funzip",18],["dpkg-query",12],["dpkg-deb",5],["apt-cache",12],["update-alternatives",12],["tput",28],["sha224sum",6],["mke2fs",27],["e4defrag",27],["e2undo",27],["prtstat",19],["addr2line",13],["cxxfilt",13],["size",13],["strip",13],["objcopy",13],["pdfinfo",11],["pdfimages",11],["expr",28],["make",28],["savelog",20]],CN=["مسح واكتشاف الشبكة","تحليل الحزم","تحليل الويب","كلمات المرور","الثغرات واختبار الاختراق","التحليل الجنائي","التشفير","الشبكات","الشبكات اللاسلكية","جمع المعلومات","تقوية الأنظمة","تحليل الملفات","أساسيات Linux","الهندسة العكسية","مراقبة الشبكة والأداء","معالجة النصوص والملفات","الوصول عن بعد وSSH","systemd والوقت","الضغط والأرشفة","العمليات والموارد","الدفاع والمراقبة","الخصوصية والاتصال","المختبر والتوثيق","العزل والحاويات","الحسابات والصلاحيات","أمن التطبيقات","قواعد البيانات","النظام والأقراص","السكربتات والأتمتة"],P={"beginner":["asciinema","dig","docker","find","git","grep","ip","mtr","nmap","nmcli","ps","ss","tar","tcpdump","traceroute","vagrant","virtualbox","whois","wireshark"],"web":["burp","curl","dig","dirb","dirsearch","ffuf","gobuster","mitmproxy","nikto","nuclei","openssl","openssl-s_client","sha1sum","sqlmap","sslscan","sslyze","testssl","wafw00f","wfuzz","whatweb","wpscan","zap"],"packets":["arp-scan","iperf3","mtr","netdiscover","nmap","nping","snort","ss","suricata","tcpdump","tshark","wireshark","zeek"],"forensics":["autopsy","base32","bulk_extractor","bzcat","dc3dd","ddrescue","debugfs","dpkg-deb","dumpe2fs","e2fsck","e2image","exiftool","exiv2","extundelete","ffprobe","file","findmnt","fls","foremost","funzip","hashdeep","icat","identify","istat","ldconfig","losetup","mactime","mediainfo","mmls","mountpoint","pdfimages","pdfinfo","pdftotext","photorec","pngcheck","qpdf","scalpel","sha384sum","sha512sum","sleuthkit","ssdeep","steghide","strings","tesseract","testdisk","umount","volatility","xmllint","xzcat","zcat","zdump","zgrep","zipdetails","zipinfo","zipnote"],"defense":["aide","auditctl","auditd","aureport","chkrootkit","clamav","cryptsetup","fail2ban","gpg","ip6tables","journalctl","lnav","lynis","nftables","rkhunter","sha256sum","ssh","ssh-keygen","systemctl","ufw","w"],"reverse":["addr2line","apktool","ar","binwalk","cxxfilt","file","floss","gdb","ghidra","jadx","ldd","lsipc","ltrace","nasm","ndisasm","objcopy","objdump","radare2","readelf","setarch","size","strace","strings","strip","valgrind","yara"],"linux-basics":["alias","apt","apt-cache","bzip2","cat","cd","column","comm","cp","csplit","date","diff3","dpkg","dpkg-query","echo","env","fmt","fold","getconf","gzip","hardlink","history","hostname","install","join","ls","man","mkdir","mkfifo","mv","namei","nl","numfmt","od","paste","patch","pidof","pr","printenv","pwd","rev","rm","rmdir","sdiff","shuf","split","sync","tac","tmux","touch","unlink","unzip","update-alternatives","whereis","which","xz"],"automation":["basename","basenc","bc","crontab","dirname","expand","expr","factor","flock","getopt","iconv","jobs","locale","make","mcookie","mktemp","nohup","nproc","pathchk","printf","readlink","realpath","savelog","screen","seq","sha224sum","shellcheck","sleep","tput","tsort","unexpand","yes"],"sysadmin":["badblocks","blockdev","chgrp","choom","chronyc","chrt","e2freefrag","e2label","e2undo","e4defrag","fallocate","filefrag","fuser","getpcaps","gpasswd","groupadd","groupdel","groups","grpck","hdparm","hostnamectl","ionice","ipcmk","ipcrm","ipcs","killall","loginctl","lshw","lslocks","lslogins","lsmem","mke2fs","mknod","mkswap","modinfo","needrestart","nice","parted","pidwait","pkill","pmap","prlimit","prtstat","pstree","pwck","pwdx","renice","resize2fs","setsid","stdbuf","su","swaplabel","swapoff","swapon","systemd-analyze","systemd-detect-virt","taskset","timedatectl","truncate","tune2fs","useradd","userdel","whoami","wipefs"],"hardening":["capsh","chattr","chroot","clamdscan","freshclam","getcap","grype","hadolint","lsns","nsenter","oscap","setcap","setpriv","syft","trufflehog","unshare"],"net-admin":["arp","bmon","dnsmasq","ifconfig","iwconfig","iwlist","ncat","netcat","ping6","route","scp","sftp","socat","ssh-agent","tcptraceroute","telnet","wpa_supplicant"],"lab-audit":["aircrack","b2sum","bettercap","cewl","cksum","dnsenum","dot","enum4linux-ng","ettercap","fierce","hping3","hydra","keytool","kismet","maltego","masscan","medusa","metasploit","nbtscan","recon-ng","shasum","smbclient","smbmap","snmpwalk","spiderfoot"],"databases":["mongosh","mysql","mysqldump","pg_dump","psql","redis-cli","sqlite3"]};
  var catTotal = {}; T.forEach(function (x) { catTotal[x[1]] = (catTotal[x[1]] || 0) + 1; });
  var DAILY_PTS = 15;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} return null; }
  function fmt(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function today() { return fmt(new Date()); }
  function hash(s) { var h = 2166136261; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  // owner switch: ?unlock=all opens every theme on this device, ?unlock=off closes them again
  try { var q = new URLSearchParams(location.search).get('unlock'); if (q === 'all') ls('cdx-owner', '1'); else if (q === 'off') ls('cdx-owner', null); } catch (e) {}
  var owner = function () { return ls('cdx-owner') === '1'; };

  var NAMES = null; // id -> name, loaded on demand
  function needNames(cb) {
    if (NAMES) return cb();
    var done = function () { NAMES = {}; if (window.CDX_IDX) window.CDX_IDX.t.forEach(function (x) { NAMES[x[0]] = x[1]; }); cb(); };
    if (window.CDX_IDX) return done();
    var s = document.createElement('script'); s.src = base + 'search-index.js'; s.onload = done; s.onerror = function () { NAMES = {}; cb(); }; document.head.appendChild(s);
  }

  function pathPct(S, id) { var l = P[id] || [], n = 0; l.forEach(function (t) { if (S.learned[t]) n++; }); return l.length ? n / l.length : 0; }
  function ctxOf(P_, st) {
    var S = P_.state(), done = {}, c = { st: st, S: S };
    Object.keys(S.learned).forEach(function (id) { }); 
    var byCat = {}; T.forEach(function (x) { if (S.learned[x[0]]) byCat[x[1]] = (byCat[x[1]] || 0) + 1; });
    c.catsDone = Object.keys(byCat).filter(function (k) { return byCat[k] >= catTotal[k]; }).length;
    c.path = {}; Object.keys(P).forEach(function (id) { c.path[id] = pathPct(S, id); });
    c.dailyStreak = dailyStreak(S);
    return c;
  }
  function dailyStreak(S) {
    var d = new Date(), n = 0; if (!S.daily[fmt(d)]) d.setDate(d.getDate() - 1);
    while (S.daily[fmt(d)]) { n++; d.setDate(d.getDate() - 1); }
    return n;
  }

  // rarity: c = common, r = rare, e = legendary
  var BADGES = [
    ['first', 'الخطوة الأولى', 'علّمت أول أداة بأنك تعلّمتها', 'c', function (x) { return x.st.learned >= 1; }],
    ['ten', 'عشر أدوات', 'تعلّمت 10 أدوات', 'c', function (x) { return x.st.learned >= 10; }],
    ['fifty', 'خمسون أداة', 'تعلّمت 50 أداة', 'r', function (x) { return x.st.learned >= 50; }],
    ['hundred', 'المئوية', 'تعلّمت 100 أداة', 'e', function (x) { return x.st.learned >= 100; }],
    ['term', 'ابن الطرفية', 'أنهيت أول محاكاة', 'c', function (x) { return x.st.sims >= 1; }],
    ['term5', 'خمس محاكاة', 'أنهيت 5 محاكاة', 'r', function (x) { return x.st.sims >= 5; }],
    ['ace', 'درجة كاملة', 'أجبت اختبار أداة بلا خطأ', 'c', function (x) { return x.st.aces >= 1; }],
    ['ace5', 'عبقري الاختبارات', '5 اختبارات بدرجة كاملة', 'r', function (x) { return x.st.aces >= 5; }],
    ['ace20', 'صائد الدرجات الكاملة', '20 اختبارًا بدرجة كاملة', 'e', function (x) { return x.st.aces >= 20; }],
    ['s3', 'ملتزم', 'تعلّمت 3 أيام متتالية', 'c', function (x) { return x.st.streak >= 3; }],
    ['s7', 'أسبوع كامل', 'تعلّمت 7 أيام متتالية', 'r', function (x) { return x.st.streak >= 7; }],
    ['s30', 'لا ينقطع', 'تعلّمت 30 يومًا متتاليًا', 'e', function (x) { return x.st.streak >= 30; }],
    ['d1', 'أول تحدٍّ', 'أنجزت تحدّي اليوم لأول مرة', 'c', function (x) { return x.st.daily >= 1; }],
    ['d7', 'سبعة تحدّيات', 'أنجزت 7 تحدّيات يومية', 'r', function (x) { return x.st.daily >= 7; }],
    ['d30', 'متحدٍّ دائم', 'أنجزت 30 تحدّيًا يوميًا', 'e', function (x) { return x.st.daily >= 30; }],
    ['ds3', 'ثلاثة بلا انقطاع', '3 تحدّيات يومية متتالية', 'r', function (x) { return x.dailyStreak >= 3; }],
    ['cat', 'مجال مكتمل', 'أنهيت كل أدوات مجال واحد', 'r', function (x) { return x.catsDone >= 1; }],
    ['p-web', 'قطعت نصف مسار الويب', 'تعلّمت نصف أدوات مسار أمان تطبيقات الويب', 'r', function (x) { return x.path.web >= .5; }],
    ['p-audit', 'قطعت نصف مسار التدقيق', 'تعلّمت نصف أدوات مسار التدقيق المصرّح', 'r', function (x) { return x.path['lab-audit'] >= .5; }],
    ['p-def', 'قطعت نصف مسار الدفاع', 'تعلّمت نصف أدوات مسار تقوية الأنظمة والدفاع', 'r', function (x) { return x.path.defense >= .5; }],
    ['p-for', 'قطعت نصف مسار التحليل الجنائي', 'تعلّمت نصف أدوات مسار التحليل الجنائي الرقمي', 'r', function (x) { return x.path.forensics >= .5; }],
    ['ex1', 'أول اختبار ناجح', 'نجحت في اختبار قسم كامل', 'c', function (x) { return x.st.examsPassed >= 1; }],
    ['ex5', 'خمسة أقسام', 'نجحت في اختبار 5 أقسام', 'r', function (x) { return x.st.examsPassed >= 5; }],
    ['ex15', 'نصف الفهرس', 'نجحت في اختبار 15 قسمًا', 'e', function (x) { return x.st.examsPassed >= 15; }],
    ['cert1', 'أول شهادة', 'أصدرت أول شهادة إتمام', 'r', function (x) { return x.st.certs >= 1; }],
    ['lvl4', 'مستوى «خبير»', 'وصلت إلى مستوى خبير', 'e', function (x) { return x.st.levelIndex >= 4; }]
  ];
  var RAR = { c: 'شائعة', r: 'نادرة', e: 'أسطورية' };

  // theme unlocks: [skin, requirement text, test(badges, stats)]
  var RULES = {
    attack: ['أتمم نصف مسار الويب أو مسار التدقيق المصرّح', function (b) { return b['p-web'] || b['p-audit']; }],
    defense: ['أتمم نصف مسار الدفاع أو التحليل الجنائي', function (b) { return b['p-def'] || b['p-for']; }],
    prime: ['ابلغ مستوى «خبير» (600 نقطة)', function (b) { return b.lvl4; }]
  };
  function isOpen(k) {
    if (k === 'classic' || owner()) return true;
    var r = RULES[k]; if (!r) return true;
    var P_ = window.CDXP; if (!P_) return false;
    return !!r[1](P_.state().badges || {});
  }

  /* ---------- sound (synthesized, no files) ---------- */
  var AC = null;
  function soundOn() { return ls('cdx-sound') !== '0'; }
  function ac() { try { if (!AC) AC = new (window.AudioContext || window.webkitAudioContext)(); if (AC.state === 'suspended') AC.resume(); } catch (e) { AC = null; } return AC; }
  function note(f, t, d, type, vol) {
    var a = ac(); if (!a) return;
    var o = a.createOscillator(), g = a.createGain(), t0 = a.currentTime + t;
    o.type = type || 'sine'; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(vol || .18, t0 + .02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(g); g.connect(a.destination); o.start(t0); o.stop(t0 + d + .05);
  }
  var SEQ = {
    c: [[784, 0, .18], [1047, .1, .28]],
    r: [[523, 0, .2], [659, .09, .2], [784, .18, .2], [1047, .27, .5]],
    e: [[523, 0, .25], [659, .1, .25], [784, .2, .25], [1047, .3, .3], [1319, .42, .35], [1568, .56, .8]],
    lvl: [[392, 0, .18], [523, .1, .18], [659, .2, .18], [784, .3, .18], [1047, .42, .7]],
    daily: [[988, 0, .1], [1319, .09, .45]],
    pop: [[660, 0, .08], [880, .05, .12]]
  };
  function play(k) {
    if (!soundOn() || !SEQ[k]) return;
    SEQ[k].forEach(function (n) { note(n[0], n[1], n[2], k === 'e' ? 'triangle' : 'sine', k === 'e' ? .2 : .16); });
    if (k === 'e') SEQ.e.slice(3).forEach(function (n) { note(n[0] / 2, n[1], n[2] + .2, 'sine', .08); });
    try { if (navigator.vibrate && (!navigator.userActivation || navigator.userActivation.hasBeenActive)) navigator.vibrate(k === 'e' ? [40, 40, 90] : k === 'c' ? 20 : [30, 30, 30]); } catch (e) {}
  }
  document.addEventListener('pointerdown', function () { ac(); }, { once: true });

  /* ---------- toasts ---------- */
  var queue = [], showing = false;
  function toast(icon, title, sub, kind) { queue.push([icon, title, sub, kind]); if (!showing) next(); }
  function big(icon, title, sub, rar, cta, snd) { queue.push(['big', icon, title, sub, rar, cta, snd]); if (!showing) next(); }
  function confetti(cv, gold) {
    var rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches; if (rm || !cv.isConnected) return;
    var W = cv.width = cv.width || innerWidth, H = cv.height = cv.height || innerHeight, cs = getComputedStyle(document.documentElement);
    var cols = gold ? ['#fff3cf', '#e0b34f', '#b08a45', '#ffffff', '#f6e6ba'] : [cs.getPropertyValue('--accent').trim() || '#2bff88', cs.getPropertyValue('--accent2').trim() || '#00d4ff', '#ffffff', '#ffd166'];
    var n = innerWidth < 600 ? 80 : 150, now = performance.now();
    var ps = cv._ps || (cv._ps = []);
    for (var i = 0; i < n; i++) { var a = Math.random() * Math.PI * 2, v = 6 + Math.random() * 9; ps.push({ x: W / 2, y: H * .42, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 5, w: 5 + Math.random() * 6, h: 3 + Math.random() * 5, r: Math.random() * 6, vr: (Math.random() - .5) * .4, c: cols[i % cols.length], t0: now }); }
    // streamers falling from the top
    for (var j = 0; j < 30; j++) ps.push({ x: Math.random() * W, y: -10 - Math.random() * 120, vx: (Math.random() - .5) * 1.5, vy: 2 + Math.random() * 3, w: 3, h: 14 + Math.random() * 10, r: Math.random() * 6, vr: (Math.random() - .5) * .15, c: cols[j % cols.length], t0: now, g: .04 });
    if (cv._run) return; cv._run = true;
    var x = cv.getContext('2d');
    (function f(t) {
      x.clearRect(0, 0, W, H); var alive = 0;
      ps.forEach(function (p) {
        var life = 1 - (t - p.t0) / 3200; if (life <= 0 || p.y > H + 30) return; alive++;
        p.vy += p.g || .22; p.vx *= .985; p.x += p.vx; p.y += p.vy; p.r += p.vr;
        x.save(); x.globalAlpha = Math.min(1, life * 1.6); x.translate(p.x, p.y); x.rotate(p.r); x.fillStyle = p.c; x.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); x.restore();
      });
      if (alive && cv.isConnected) requestAnimationFrame(f); else cv._run = false;
    })(performance.now());
  }
  function showBig(q) {
    var d = document.createElement('div'); d.className = 'ach-big r-' + (q[4] || 'c'); d.setAttribute('role', 'dialog'); d.setAttribute('aria-live', 'polite');
    d.innerHTML = '<canvas></canvas><div class="ab-rays"></div><div class="ab-card"><div class="ab-medal"><span></span></div><small class="ab-k"></small><h2></h2><p></p><button class="btn primary" type="button">رائع!</button></div>';
    d.querySelector('.ab-medal span').textContent = q[1]; d.querySelector('.ab-k').textContent = ({ e: 'إنجاز أسطوري', r: 'إنجاز نادر', c: 'إنجاز جديد' })[q[4] || 'c'];
    d.querySelector('h2').textContent = q[2]; d.querySelector('p').textContent = q[3] || '';
    var btn = d.querySelector('button'); if (q[5]) btn.textContent = q[5];
    var snd = document.createElement('button'); snd.type = 'button'; snd.className = 'ab-snd'; snd.setAttribute('aria-label', 'الصوت');
    var paintSnd = function () { snd.textContent = soundOn() ? '🔊' : '🔇'; }; paintSnd();
    snd.addEventListener('click', function (e) { e.stopPropagation(); ls('cdx-sound', soundOn() ? '0' : '1'); paintSnd(); if (soundOn()) play('pop'); }); d.appendChild(snd);
    var kind = q[6] || (q[4] === 'e' ? 'e' : q[4] === 'r' ? 'r' : 'c'); play(kind);
    document.body.appendChild(d); requestAnimationFrame(function () { d.classList.add('in'); }); setTimeout(function () { confetti(d.querySelector('canvas'), q[4] === 'e'); }, 350); setTimeout(function () { confetti(d.querySelector('canvas'), q[4] === 'e'); }, 900);
    var close = function () { d.classList.remove('in'); setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); next(); }, 350); };
    btn.addEventListener('click', close); d.addEventListener('click', function (e) { if (e.target === d) close(); });
    setTimeout(function () { if (d.parentNode && d.classList.contains('in')) close(); }, 9000);
  }
  function next() {
    var q = queue.shift(); if (!q) { showing = false; return; } showing = true;
    if (q[0] === 'big') return showBig(q);
    var d = document.createElement('div'); d.className = 'ach-toast ' + (q[3] || ''); d.setAttribute('role', 'status');
    d.innerHTML = '<span class="at-i"></span><span><b></b><small></small></span>';
    play(q[3] === 'daily' ? 'daily' : 'c');
    d.firstChild.textContent = q[0]; d.querySelector('b').textContent = q[1]; d.querySelector('small').textContent = q[2] || '';
    document.body.appendChild(d);
    requestAnimationFrame(function () { d.classList.add('in'); });
    setTimeout(function () { d.classList.remove('in'); setTimeout(function () { if (d.parentNode) d.parentNode.removeChild(d); next(); }, 350); }, 3800);
  }

  /* ---------- daily challenge ---------- */
  function dailyTool(date) { return T[hash('cdx|' + (date || today())) % T.length][0]; }
  function dailyDone() { var P_ = window.CDXP; return !!(P_ && P_.state().daily[today()]); }
  function checkDaily(P_, silent) {
    var art = document.querySelector('[data-tool]'); if (!art) return false;
    var id = art.getAttribute('data-tool'); if (id !== dailyTool()) return false;
    var S = P_.state(); if (!(S.quiz[id] || S.learned[id] || S.sims[id])) return false;
    if (!P_.markDaily(today())) return false;
    if (!silent) big('🎯', 'أنجزت تحدّي اليوم', '+' + DAILY_PTS + ' نقطة · ' + dailyStreak(P_.state()) + ' يوم متتالٍ في التحدّي', 'c');
    return true;
  }

  /* ---------- evaluation ---------- */
  var evaluating = false, firstRun = true;
  function evaluate() {
    var P_ = window.CDXP; if (!P_ || evaluating) return; evaluating = true;
    try {
      checkDaily(P_, false);
      var st = P_.stats(), ctx = ctxOf(P_, st), fresh = [];
      BADGES.forEach(function (b) { if (!P_.state().badges[b[0]] && b[4](ctx)) { P_.award(b[0]); fresh.push(b); } });
      // level up
      var lv = ls('cdx-lvl'), li = st.levelIndex;
      if (lv !== null && +lv < li) big('🏆', 'ارتقيت إلى «' + st.level + '»', 'وصلت إلى ' + st.points + ' نقطة. استمر!', li >= 4 ? 'e' : 'r', null, 'lvl');
      if (lv === null || +lv !== li) ls('cdx-lvl', String(li));
      if (fresh.length) {
        if (firstRun && fresh.length > 3) toast('★', 'حصلت على ' + fresh.length + ' شارات', 'من تقدّمك السابق · تجدها في صفحة «تقدّمي»', 'badge');
        else fresh.forEach(function (b) { if (b[3] === 'c') toast('★', 'شارة جديدة: ' + b[1], b[2], 'badge'); else big('★', b[1], b[2], b[3]); });
        // newly opened themes
        var b2 = P_.state().badges; ['attack', 'defense', 'prime'].forEach(function (k) {
          if (RULES[k][1](b2) && !ls('cdx-open-' + k)) { ls('cdx-open-' + k, '1'); if (!firstRun || fresh.length <= 3) big('🎨', 'فتحت ثيم ' + ({ attack: 'الهجومي', defense: 'الدفاعي', prime: 'Prime' })[k], 'فعّله من زر الثيمات في أعلى الصفحة', k === 'prime' ? 'e' : 'r'); }
        });
      }
      ['attack', 'defense', 'prime'].forEach(function (k) { if (RULES[k][1](P_.state().badges)) ls('cdx-open-' + k, '1'); });
      if (window.CDX_SKIN) window.CDX_SKIN.setUnlockCheck(isOpen, function (k) { return RULES[k] ? RULES[k][0] : ''; });
    } finally { evaluating = false; firstRun = false; }
    document.dispatchEvent(new CustomEvent('cdx-ach'));
    renderCard(); publishCerts(); lbSync();
  }

  /* ---------- daily card (home + progress page) ---------- */
  function renderCard() {
    var el = document.getElementById('dailyCard'); if (!el) return;
    var P_ = window.CDXP; if (!P_) return;
    needNames(function () {
      var id = dailyTool(), done = dailyDone(), S = P_.state(), ds = dailyStreak(S), nm = NAMES[id] || id;
      el.innerHTML = '<div class="dc-main"><span class="dc-tag">🎯 تحدّي اليوم</span><h3></h3><p></p></div><div class="dc-side"><div class="dc-streak"><b></b><span>أيام متتالية</span></div><a class="btn primary"></a></div>';
      el.querySelector('h3').textContent = 'أداة اليوم: ' + nm;
      el.querySelector('p').textContent = done ? 'أحسنت! أنجزت تحدّي اليوم وكسبت ' + DAILY_PTS + ' نقطة. عُد غدًا لأداة جديدة.' : 'افتح الأداة، ثم أجب عن اختبارها أو علّمها «تعلّمتها» لتكسب ' + DAILY_PTS + ' نقطة وتحافظ على سلسلتك.';
      el.querySelector('.dc-streak b').textContent = ds;
      var a = el.querySelector('a.btn'); a.href = 'tools/' + id + '.html'; a.textContent = done ? 'راجع الأداة ←' : 'ابدأ التحدّي ←';
      el.classList.toggle('done', done);
    });
  }

  /* ---------- sync certificates + leaderboard (signed-in users) ---------- */
  var lbTimer = null;
  function publishCerts() {
    var P_ = window.CDXP, sb = window.CDX_SB, ses = window.CDX_SESSION; if (!P_ || !sb || !ses) return;
    var S = P_.state(); Object.keys(S.certs).forEach(function (code) {
      var c = S.certs[code]; if (c.v) return;
      sb.rpc('issue_certificate', { p_code: code, p_name: c.name, p_cat: c.cat, p_score: c.score }).then(function (r) { if (!r.error && r.data === true) P_.markCert(code); });
    });
  }
  function lbSync() {
    if (ls('cdx-lb') !== '1' || !window.CDX_SB || !window.CDX_SESSION) return;
    clearTimeout(lbTimer);
    lbTimer = setTimeout(function () { window.CDXP.push().then(function () { return window.CDX_SB.rpc('publish_score'); }); }, 6000);
  }

  window.CDX_ACH = {
    publishCerts: publishCerts, lbSync: lbSync,
    badges: function () {
      var P_ = window.CDXP, S = P_.state(), st = P_.stats(), ctx = ctxOf(P_, st);
      return BADGES.map(function (b) { return { id: b[0], name: b[1], desc: b[2], rar: b[3], rarName: RAR[b[3]], on: !!S.badges[b[0]], ready: b[4](ctx) }; });
    },
    skins: function () {
      return ['attack', 'defense', 'prime'].map(function (k) { return { id: k, name: ({ attack: 'الهجومي', defense: 'الدفاعي', prime: 'Prime' })[k], need: RULES[k][0], open: isOpen(k) }; });
    },
    celebrate: big, dailyTool: dailyTool, dailyDone: dailyDone, evaluate: evaluate, owner: owner
  };

  function boot() {
    if (!window.CDXP) { var s = document.createElement('script'); s.src = base + 'progress.js'; s.onload = function () { setTimeout(start, 0); }; document.head.appendChild(s); } else start();
  }
  function start() {
    // block theme use until we know what is unlocked
    if (window.CDX_SKIN) window.CDX_SKIN.setUnlockCheck(isOpen, function (k) { return RULES[k] ? RULES[k][0] : ''; });
    evaluate();
    document.addEventListener('cdx-progress', evaluate);
    document.addEventListener('cdx-sim-done', function () { setTimeout(evaluate, 50); });
    document.addEventListener('cdx-auth', function () { setTimeout(evaluate, 600); });
  }
  // small feedback when marking a tool as learned: pop sound + floating points
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('[data-learn]'); if (!b) return;
    setTimeout(function () {
      if (b.getAttribute('aria-pressed') !== 'true') return;
      play('pop');
      var r = b.getBoundingClientRect(), f = document.createElement('div'); f.className = 'pts-float'; f.textContent = '+10';
      f.style.left = (r.left + r.width / 2) + 'px'; f.style.top = r.top + 'px'; document.body.appendChild(f);
      setTimeout(function () { if (f.parentNode) f.parentNode.removeChild(f); }, 1200);
    }, 60);
  });
  boot();
})();
