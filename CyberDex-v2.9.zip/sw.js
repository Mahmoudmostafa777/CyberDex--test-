/* CyberDex service worker: offline shell + runtime cache. Bump V to force an update. */
var V = 'cdx-v2.14';
var FONTS = 'cdx-fonts';
var BASE = self.registration.scope;
var CMP = ['cheatsheets/beginner.html','cheatsheets/web.html','cheatsheets/packets.html','cheatsheets/forensics.html','cheatsheets/defense.html','cheatsheets/reverse.html','cheatsheets/linux-basics.html','cheatsheets/automation.html','cheatsheets/sysadmin.html','cheatsheets/hardening.html','cheatsheets/net-admin.html','cheatsheets/lab-audit.html','cheatsheets/databases.html', 'cheatsheets.html', 'compare/nmap-vs-masscan.html', 'compare/burp-vs-zap.html', 'compare/john-vs-hashcat.html', 'compare/wireshark-vs-tcpdump.html', 'compare/netstat-vs-ss.html', 'compare/gobuster-vs-ffuf.html', 'compare/iptables-vs-nftables.html', 'compare/snort-vs-suricata.html', 'compare/netcat-vs-ncat.html', 'compare/ghidra-vs-radare2.html'];
var CORE = ['./', 'index.html', 'tools.html', 'paths.html', 'goals.html', 'learn.html', 'progress.html', 'compare.html', 'exams.html', 'lab.html', 'plan.html', 'profile.html', 'assets/js/plan.js', 'assets/js/plan-data.js', 'assets/js/profile.js', 'assets/js/lab.js', 'assets/js/lab-data.js', 'certificate.html', 'verify.html', 'leaderboard.html', 'assets/js/exams.js', 'assets/js/cert.js', 'assets/js/leaderboard.js', 'assets/exams.json', 'glossary.html', 'resources.html',
  'about.html', 'responsible-use.html', 'privacy.html', 'contact.html', 'changelog.html', 'offline.html', 'site.webmanifest',
  'assets/css/style.css', 'assets/js/app.js', 'assets/js/smart-search.js', 'assets/js/backend.js', 'assets/js/config.js', 'assets/js/fx.js', 'assets/js/goals.js',
  'assets/js/progress.js', 'assets/js/achievements.js', 'assets/js/progress-page.js', 'assets/js/pwa.js', 'assets/js/search-index.js', 'assets/js/names.js', 'assets/js/sides.js',
  'assets/js/terminal.js', 'assets/js/theme.js', 'assets/img/favicon.svg', 'assets/img/icon-192.png', 'assets/img/mark.png', 'assets/img/logo-full.webp', 'assets/img/logo-full-alpha.webp', 'assets/img/favicon-64.png', 'assets/tools.json', 'assets/knowledge.json'];

self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(V).then(function (c) {
    return Promise.all(CORE.map(function (u) { return c.add(u).catch(function () {}); }));
  }).then(function () { return self.skipWaiting(); }));
});

self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (ks) {
    return Promise.all(ks.filter(function (k) { return k !== V && k !== FONTS; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});

function timeout(ms) { return new Promise(function (_, rej) { setTimeout(rej, ms); }); }

function networkFirst(req) {
  return Promise.race([fetch(req), timeout(3500)]).then(function (res) {
    if (res && res.ok) { var cp = res.clone(); caches.open(V).then(function (c) { c.put(req, cp); }); }
    return res;
  }).catch(function () {
    return caches.match(req, { ignoreSearch: true }).then(function (m) { return m || caches.match('offline.html'); });
  });
}

function staleWhileRevalidate(req) {
  return caches.match(req).then(function (hit) {
    var net = fetch(req).then(function (res) {
      if (res && res.ok) { var cp = res.clone(); caches.open(V).then(function (c) { c.put(req, cp); }); }
      return res;
    }).catch(function () { return hit; });
    return hit || net;
  });
}

function fontsCache(req) {
  return caches.open(FONTS).then(function (c) {
    return c.match(req).then(function (hit) {
      return hit || fetch(req).then(function (res) { if (res && (res.ok || res.type === 'opaque')) c.put(req, res.clone()); return res; });
    });
  });
}

self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (/fonts\.(googleapis|gstatic)\.com$/.test(url.hostname)) { e.respondWith(fontsCache(req)); return; }
  if (url.origin !== location.origin) return;           // Supabase and anything else: never touched
  if (req.mode === 'navigate') { e.respondWith(networkFirst(req)); return; }
  e.respondWith(staleWhileRevalidate(req));
});

// "download everything for offline use" requested from the page
self.addEventListener('message', function (e) {
  var d = e.data || {};
  if (d.type !== 'cache-all') return;
  var src = e.source;
  var say = function (m) { self.clients.matchAll().then(function (cs) { cs.forEach(function (c) { c.postMessage(m); }); }); };
  e.waitUntil(fetch(new URL('assets/tools.json', BASE)).then(function (r) { return r.json(); }).then(function (tools) {
    var urls = tools.map(function (t) { return 'tools/' + t.id + '.html'; }).concat(CMP);
    var total = urls.length, done = 0, i = 0;
    return caches.open(V).then(function (c) {
      var worker = function () {
        if (i >= urls.length) return Promise.resolve();
        var u = urls[i++];
        return c.match(u).then(function (hit) { return hit || c.add(u).catch(function () {}); }).then(function () {
          done++; if (done % 10 === 0 || done === total) say({ type: 'cdx-cache-progress', done: done, total: total });
        }).then(worker);
      };
      return Promise.all([worker(), worker(), worker(), worker(), worker(), worker()]);
    }).then(function () { say({ type: 'cdx-cache-done', total: total }); });
  }).catch(function () { say({ type: 'cdx-cache-error' }); }));
});
