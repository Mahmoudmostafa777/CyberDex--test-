/* CyberDex admin panel. Real protection is in the database (RLS + is_admin()); this page is only the UI. */
(function () {
  'use strict';
  var app = document.getElementById('adminApp'); if (!app) return;
  var sb, uid, S = {};
  function el(tag, attrs, kids) { var n = document.createElement(tag); for (var k in (attrs || {})) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); } (kids || []).forEach(function (c) { if (c) n.appendChild(c); }); return n; }
  function clear(n) { n.textContent = ''; return n; }
  function msg(t, bad) { return el('p', { class: 'cdx-note', text: t, style: bad ? '' : 'color:var(--muted)' }); }
  function fmtN(n) { return Number(n || 0).toLocaleString('en-US'); }
  function usd(n) { return '$' + Number(n || 0).toFixed(4); }

  var tabs = [['users', 'المستخدمون'], ['usage', 'الاستخدام والتكلفة'], ['messages', 'الرسائل'], ['settings', 'الإعدادات'], ['security', 'الأمان (MFA)']];
  var nav = el('div', { class: 'cdx-tabs adm-tabs' }), view = el('div', { class: 'adm-view' });
  tabs.forEach(function (t) { var b = el('button', { type: 'button', text: t[1] }); b.onclick = function () { show(t[0]); }; b.dataset.t = t[0]; nav.appendChild(b); });
  function show(t) { Array.prototype.forEach.call(nav.children, function (b) { b.className = b.dataset.t === t ? 'on' : ''; }); clear(view).appendChild(msg('جارٍ التحميل…')); ({ users: users, usage: usage, messages: messages, settings: settings, security: security })[t](); }

  function users() {
    sb.rpc('admin_users').then(function (r) {
      clear(view); if (r.error) { view.appendChild(msg('تعذّر التحميل: ' + r.error.message, 1)); return; }
      var t = el('table', { class: 'adm-t' }), h = el('tr'); ['البريد', 'الدور', 'اليوم', 'الكل', 'حدّ يومي', 'حظر'].forEach(function (x) { h.appendChild(el('th', { text: x })); }); t.appendChild(h);
      r.data.forEach(function (u) {
        var self = u.id === uid, row = el('tr'), lim = el('input', { type: 'number', min: '0', max: '1000', placeholder: 'افتراضي', value: u.daily_limit == null ? '' : String(u.daily_limit), style: 'width:80px' });
        lim.onchange = function () { var v = lim.value === '' ? null : Math.max(0, Math.min(1000, parseInt(lim.value, 10) || 0)); sb.from('profiles').update({ daily_limit: v }).eq('id', u.id).then(function (x) { if (x.error) alert('فشل الحفظ'); }); };
        var ban = el('input', { type: 'checkbox' }); ban.checked = u.banned; if (self) ban.disabled = true;
        ban.onchange = function () { sb.from('profiles').update({ banned: ban.checked }).eq('id', u.id).then(function (x) { if (x.error) { alert('فشل الحفظ'); ban.checked = !ban.checked; } }); };
        row.appendChild(el('td', { text: u.email || '', dir: 'ltr' })); row.appendChild(el('td', { text: u.role === 'admin' ? 'أدمن' : 'مستخدم' }));
        row.appendChild(el('td', { text: fmtN(u.today_requests) })); row.appendChild(el('td', { text: fmtN(u.total_requests) }));
        var c1 = el('td'); c1.appendChild(lim); row.appendChild(c1); var c2 = el('td'); c2.appendChild(ban); row.appendChild(c2); t.appendChild(row);
      });
      view.appendChild(el('p', { class: 'cdx-sub', text: 'عدد الحسابات: ' + r.data.length + ' (آخر 500). ترقية أدمن جديد تتم من SQL فقط، حفاظًا على الأمان.' }));
      view.appendChild(el('div', { class: 'adm-scroll' }, [t]));
    });
  }

  function usage() {
    Promise.all([sb.rpc('admin_usage_summary', { days: 30 }), sb.from('settings').select('key,value').in('key', ['price_in_per_mtok', 'price_out_per_mtok'])]).then(function (rs) {
      clear(view); if (rs[0].error) { view.appendChild(msg('تعذّر التحميل: ' + rs[0].error.message, 1)); return; }
      var p = {}; (rs[1].data || []).forEach(function (x) { p[x.key] = Number(x.value) || 0; });
      if (!p.price_in_per_mtok && !p.price_out_per_mtok) view.appendChild(msg('أدخل أسعار النموذج في تبويب "الإعدادات" ليظهر تقدير التكلفة (الأسعار تأخذها من صفحة تسعير مزوّد النموذج).', 1));
      var tot = { r: 0, i: 0, o: 0 }, t = el('table', { class: 'adm-t' }), h = el('tr'); ['اليوم', 'مستخدمون', 'طلبات', 'Tokens دخل', 'Tokens خرج', 'تكلفة تقديرية'].forEach(function (x) { h.appendChild(el('th', { text: x })); }); t.appendChild(h);
      rs[0].data.forEach(function (d) {
        var c = d.input_tokens / 1e6 * p.price_in_per_mtok + d.output_tokens / 1e6 * p.price_out_per_mtok; tot.r += +d.requests; tot.i += +d.input_tokens; tot.o += +d.output_tokens;
        var row = el('tr'); [d.day, fmtN(d.users), fmtN(d.requests), fmtN(d.input_tokens), fmtN(d.output_tokens), usd(c)].forEach(function (x) { row.appendChild(el('td', { text: String(x) })); }); t.appendChild(row);
      });
      var tc = tot.i / 1e6 * p.price_in_per_mtok + tot.o / 1e6 * p.price_out_per_mtok;
      view.appendChild(el('p', { class: 'adm-sum', text: 'آخر 30 يومًا: ' + fmtN(tot.r) + ' طلب — تكلفة تقديرية ' + usd(tc) }));
      view.appendChild(el('div', { class: 'adm-scroll' }, [t]));
    });
  }

  function messages() {
    sb.from('messages').select('*').order('created_at', { ascending: false }).limit(200).then(function (r) {
      clear(view); if (r.error) { view.appendChild(msg('تعذّر التحميل: ' + r.error.message, 1)); return; }
      if (!r.data.length) { view.appendChild(msg('لا توجد رسائل بعد.')); return; }
      var kinds = { contact: 'تواصل', bug: 'خطأ', suggestion: 'اقتراح' };
      r.data.forEach(function (m) {
        var st = el('select'); [['new', 'جديدة'], ['read', 'مقروءة'], ['done', 'تمت']].forEach(function (o) { var op = el('option', { value: o[0], text: o[1] }); if (m.status === o[0]) op.selected = true; st.appendChild(op); });
        st.onchange = function () { sb.from('messages').update({ status: st.value }).eq('id', m.id); };
        var del = el('button', { class: 'btn sm', type: 'button', text: 'حذف' }); var card;
        del.onclick = function () { if (confirm('حذف هذه الرسالة؟')) sb.from('messages').delete().eq('id', m.id).then(function (x) { if (!x.error) card.remove(); }); };
        card = el('div', { class: 'panel adm-msg' }, [el('div', { class: 'adm-meta', text: (kinds[m.kind] || m.kind) + ' • ' + (m.email || 'مجهول') + ' • ' + new Date(m.created_at).toLocaleString('ar-EG') + (m.page ? ' • ' + m.page : '') }), el('p', { text: m.body }), el('div', { class: 'adm-row' }, [st, del])]);
        view.appendChild(card);
      });
    });
  }

  var FIELDS = [['assistant_enabled', 'تشغيل المساعد', 'bool'], ['default_daily_limit', 'الحدّ اليومي الافتراضي لكل مستخدم', 'num'], ['global_daily_cap', 'السقف اليومي لكل المستخدمين (طلبات)', 'num'], ['price_in_per_mtok', 'سعر مليون Token دخل (دولار)', 'num'], ['price_out_per_mtok', 'سعر مليون Token خرج (دولار)', 'num'], ['require_admin_mfa', 'إلزام الأدمن بالتحقق بخطوتين (فعّله بعد تسجيل MFA)', 'bool']];
  function settings() {
    sb.from('settings').select('key,value').then(function (r) {
      clear(view); if (r.error) { view.appendChild(msg('تعذّر التحميل: ' + r.error.message, 1)); return; }
      var cur = {}; r.data.forEach(function (x) { cur[x.key] = x.value; });
      var form = el('form', { class: 'adm-form' }), ins = {}, note = msg('');
      FIELDS.forEach(function (f) {
        var i = f[2] === 'bool' ? el('input', { type: 'checkbox' }) : el('input', { type: 'number', min: '0', step: 'any' });
        if (f[2] === 'bool') i.checked = cur[f[0]] === true; else i.value = cur[f[0]] == null ? '' : String(cur[f[0]]); ins[f[0]] = i;
        form.appendChild(el('label', {}, [el('span', { text: f[1] }), i]));
      });
      var a = cur.announcement || { active: false, text: '' }, at = el('input', { type: 'text', maxlength: '200', value: a.text || '', placeholder: 'نص الإعلان (يظهر أعلى كل الصفحات)' }), ac = el('input', { type: 'checkbox' }); ac.checked = !!a.active;
      form.appendChild(el('label', {}, [el('span', { text: 'إظهار إعلان' }), ac])); form.appendChild(el('label', {}, [el('span', { text: 'نص الإعلان' }), at]));
      form.appendChild(el('button', { class: 'btn', type: 'submit', text: 'حفظ' })); form.appendChild(note);
      form.onsubmit = function (e) {
        e.preventDefault(); var rows = FIELDS.map(function (f) { return { key: f[0], value: f[2] === 'bool' ? ins[f[0]].checked : Math.max(0, Number(ins[f[0]].value) || 0) }; });
        rows.push({ key: 'announcement', value: { active: ac.checked, text: at.value.trim().slice(0, 200) } });
        sb.from('settings').upsert(rows).then(function (x) { note.textContent = x.error ? 'فشل الحفظ: ' + x.error.message : 'تم الحفظ.'; });
      };
      view.appendChild(form);
    });
  }

  function security() {
    clear(view);
    sb.auth.mfa.listFactors().then(function (r) {
      var f = ((r.data && r.data.totp) || []).filter(function (x) { return x.status === 'verified'; });
      view.appendChild(el('p', { text: f.length ? 'التحقق بخطوتين مفعّل على حسابك ✅' : 'التحقق بخطوتين غير مفعّل. فعّله الآن ثم شغّل خيار "إلزام الأدمن" من الإعدادات، فيصبح الدخول للوحة مستحيلًا بدون هاتفك.' }));
      if (f.length) return;
      var go = el('button', { class: 'btn', type: 'button', text: 'تفعيل MFA' }); view.appendChild(go);
      go.onclick = function () {
        go.disabled = true;
        // remove half-finished attempts first, and use a unique name, so retrying never fails with "already exists"
        sb.auth.mfa.listFactors().then(function (lf) {
          var stale = ((lf.data && lf.data.all) || []).filter(function (x) { return x.status === 'unverified'; });
          return Promise.all(stale.map(function (x) { return sb.auth.mfa.unenroll({ factorId: x.id }); }));
        }).then(function () { return sb.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'CyberDex-' + Date.now() }); }).then(function (e) {
          if (e.error) { go.disabled = false; view.appendChild(msg('تعذّر: ' + e.error.message, 1)); return; }
          var img = el('img', { src: e.data.totp.qr_code, alt: 'QR', width: '180', height: '180', style: 'background:#fff;padding:8px;border-radius:8px' });
          var code = el('input', { type: 'text', inputmode: 'numeric', maxlength: '6', placeholder: 'الكود من التطبيق', dir: 'ltr' }), ok = el('button', { class: 'btn', type: 'button', text: 'تأكيد' }), n = msg('');
          view.appendChild(el('p', { class: 'cdx-sub', text: 'امسح الرمز بتطبيق مصادقة (Google Authenticator أو Authy) ثم اكتب الكود. أو أدخل المفتاح يدويًا: ' + e.data.totp.secret })); view.appendChild(img); view.appendChild(code); view.appendChild(ok); view.appendChild(n);
          ok.onclick = function () { sb.auth.mfa.challengeAndVerify({ factorId: e.data.id, code: code.value.trim() }).then(function (v) { if (v.error) n.textContent = 'الكود غير صحيح.'; else show('security'); }); };
        });
      };
    });
  }

  function start() {
    sb = window.CDX_SB; if (!sb) { var tries = (start.t = (start.t || 0) + 1); if (tries < 50) return setTimeout(start, 200); clear(app).appendChild(msg('لم يتم ضبط الخادم بعد (config.js فارغ).', 1)); return; }
    sb.auth.getSession().then(function (r) {
      var s = r.data.session; if (!s) { clear(app).appendChild(msg('سجّل الدخول بحساب الأدمن من زر "دخول" بالأعلى ثم أعد تحميل الصفحة.', 1)); sb.auth.onAuthStateChange(function (e, x) { if (x) location.reload(); }); return; }
      uid = s.user.id;
      sb.rpc('is_admin').then(function (a) {
        if (a.data === true) { clear(app); app.appendChild(nav); app.appendChild(view); show('users'); return; }
        clear(app); app.appendChild(msg('هذا الحساب ليس أدمن، أو أن MFA مطلوب ولم يتم التحقق به في هذه الجلسة.', 1));
        // allow MFA enrollment/verification even before admin access is granted
        var wrap = el('div'); app.appendChild(wrap); view = wrap; mfaGate();
      });
    });
  }
  // when require_admin_mfa is on, an admin at aal1 must verify a TOTP code to reach aal2
  function mfaGate() {
    sb.auth.mfa.listFactors().then(function (r) {
      var f = ((r.data && r.data.totp) || []).filter(function (x) { return x.status === 'verified'; })[0]; if (!f) return;
      var code = el('input', { type: 'text', inputmode: 'numeric', maxlength: '6', placeholder: 'كود التحقق (6 أرقام)', dir: 'ltr' }), ok = el('button', { class: 'btn', type: 'button', text: 'تحقق' }), n = msg('');
      view.appendChild(code); view.appendChild(ok); view.appendChild(n);
      ok.onclick = function () { sb.auth.mfa.challengeAndVerify({ factorId: f.id, code: code.value.trim() }).then(function (v) { if (v.error) n.textContent = 'الكود غير صحيح.'; else location.reload(); }); };
    });
  }
  start();
})();
