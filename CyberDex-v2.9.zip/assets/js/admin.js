/* CyberDex admin panel v3. Real protection is in the database (RLS + is_admin() inside every RPC); this page is only the UI. */
(function () {
  'use strict';
  var app = document.getElementById('adminApp'); if (!app) return;
  var sb, uid;
  function el(tag, attrs, kids) { var n = document.createElement(tag); for (var k in (attrs || {})) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); } (kids || []).forEach(function (c) { if (c) n.appendChild(c); }); return n; }
  function clear(n) { n.textContent = ''; return n; }
  function msg(t, bad) { return el('p', { class: 'cdx-note', text: t, style: bad ? '' : 'color:var(--muted)' }); }
  function fmtN(n) { return Number(n || 0).toLocaleString('en-US'); }
  function usd(n) { return '$' + Number(n || 0).toFixed(4); }
  function fmtD(d) { return d ? new Date(d).toLocaleString('ar-EG', { dateStyle: 'short', timeStyle: 'short' }) : '—'; }
  function fmtDay(d) { return d ? new Date(d).toLocaleDateString('ar-EG', { dateStyle: 'medium' }) : '—'; }
  var ERR = { self: 'لا يمكنك تنفيذ هذا على حسابك.', is_admin: 'لا يمكن تنفيذ هذا على حساب أدمن.', none: 'العنصر غير موجود.', denied: 'غير مسموح. تأكد أنك أدمن وأن MFA مفعّل في هذه الجلسة.', invalid: 'قيمة غير صالحة.', taken: 'الاسم مستخدم.' };
  var LEVELS = ['مستكشف', 'متدرّب', 'ممارس', 'محترف', 'خبير', 'أسطورة'];
  var ACTIONS = { ban: 'حظر مستخدم', unban: 'رفع حظر', set_limit: 'تعديل الحد اليومي', delete_user: 'حذف مستخدم', revoke_certificate: 'سحب شهادة', lb_remove: 'إزالة من اللوحة', lb_remove_block: 'إزالة ومنع من اللوحة', lb_block: 'منع من اللوحة', lb_unblock: 'السماح باللوحة', lb_rename: 'تغيير اسم مستعار', settings: 'تعديل الإعدادات', profile_remove: 'حذف ملف عام', profile_remove_block: 'حذف ملف عام ومنعه', backup_create: 'إنشاء نسخة احتياطية', backup_download: 'تنزيل نسخة احتياطية', backup_delete: 'حذف نسخة احتياطية' };

  // ---- data helpers
  function rpc(name, args) { return sb.rpc(name, args || {}).then(function (r) { if (r.error) throw new Error(r.error.message); return r.data; }); }
  function res(code) { if (code === 'ok') return true; throw new Error(ERR[code] || String(code)); }
  var toastEl;
  function toast(t, bad) {
    if (toastEl) toastEl.remove(); toastEl = el('div', { class: 'adm-toast' + (bad ? ' bad' : ''), role: 'status', text: t }); document.body.appendChild(toastEl);
    var me = toastEl; setTimeout(function () { if (me.parentNode) me.remove(); }, 3500);
  }
  function fail(e) { toast((e && e.message) || 'حدث خطأ', true); }

  // ---- in-page dialog (replaces prompt/confirm). opts: title,text,input,confirmWord,okText,danger
  function dialog(o) {
    return new Promise(function (resolve) {
      var inp = o.input ? el('input', { type: 'text', maxlength: '200', placeholder: o.input, autocomplete: 'off' }) : null;
      var word = o.confirmWord ? el('input', { type: 'text', placeholder: 'اكتب: ' + o.confirmWord, autocomplete: 'off', dir: 'ltr' }) : null;
      var ok = el('button', { class: 'btn' + (o.danger ? ' adm-danger' : ''), type: 'submit', text: o.okText || 'تأكيد' }); if (word) ok.disabled = true;
      var no = el('button', { class: 'btn sm', type: 'button', text: 'إلغاء' });
      var form = el('form', { class: 'cdx-form' }, [inp, word, el('div', { class: 'adm-row' }, [ok, no])]);
      var box = el('div', { class: 'cdx-box', role: 'dialog', 'aria-modal': 'true' }, [el('h3', { text: o.title }), o.text ? el('p', { class: 'cdx-sub', text: o.text }) : null, form]);
      var ov = el('div', { class: 'cdx-overlay adm-ov2' }, [box]);
      function done(v) { ov.remove(); document.removeEventListener('keydown', esc); resolve(v); }
      function esc(e) { if (e.key === 'Escape') done(null); }
      if (word) word.oninput = function () { ok.disabled = word.value.trim() !== o.confirmWord; };
      form.onsubmit = function (e) { e.preventDefault(); if (word && word.value.trim() !== o.confirmWord) return; done(inp ? inp.value.trim() : true); };
      no.onclick = function () { done(null); };
      ov.addEventListener('click', function (e) { if (e.target === ov) done(null); });
      document.addEventListener('keydown', esc); document.body.appendChild(ov); (inp || word || ok).focus();
    });
  }

  // ---- svg charts (bars), colours from CSS variables
  var NS = 'http://www.w3.org/2000/svg';
  function sv(tag, attrs, parent) { var n = document.createElementNS(NS, tag); for (var k in attrs) n.setAttribute(k, attrs[k]); if (parent) parent.appendChild(n); return n; }
  function barChart(series, title, color) {
    var W = 320, H = 120, P = 6, max = Math.max.apply(null, series.map(function (x) { return x.n; }).concat([1])), n = series.length, bw = (W - P * 2) / n;
    var total = series.reduce(function (a, x) { return a + x.n; }, 0);
    var box = el('div', { class: 'adm-chart panel' }, [el('div', { class: 'adm-ch-h' }, [el('b', { text: title }), el('span', { class: 'cdx-sub', text: 'المجموع: ' + fmtN(total) })])]);
    var svg = sv('svg', { viewBox: '0 0 ' + W + ' ' + (H + 18), role: 'img', 'aria-label': title + ' — آخر 30 يومًا، المجموع ' + total, class: 'adm-svg' });
    sv('line', { x1: P, x2: W - P, y1: H, y2: H, stroke: 'var(--line2)', 'stroke-width': 1 }, svg);
    series.forEach(function (x, i) {
      var h = Math.round((x.n / max) * (H - 14)), r = sv('rect', { x: (P + i * bw + 1).toFixed(1), y: H - h, width: Math.max(1, bw - 2).toFixed(1), height: h, rx: 2, fill: color || 'var(--accent)', opacity: x.n ? 1 : 0.18 }, svg);
      if (!x.n) { r.setAttribute('height', 2); r.setAttribute('y', H - 2); }
      sv('title', {}, r).textContent = String(x.day).slice(5) + ' : ' + x.n;
    });
    var t1 = sv('text', { x: P, y: H + 13, 'font-size': 9, fill: 'var(--muted)' }, svg); t1.textContent = String(series[0].day).slice(5);
    var t2 = sv('text', { x: W - P, y: H + 13, 'font-size': 9, fill: 'var(--muted)', 'text-anchor': 'end' }, svg); t2.textContent = String(series[n - 1].day).slice(5);
    var t3 = sv('text', { x: W / 2, y: H + 13, 'font-size': 9, fill: 'var(--muted)', 'text-anchor': 'middle' }, svg); t3.textContent = 'أعلى: ' + max;
    box.appendChild(svg); return box;
  }
  function hBars(rows, title) {
    var max = Math.max.apply(null, rows.map(function (x) { return x.n; }).concat([1])), box = el('div', { class: 'adm-chart panel' }, [el('b', { text: title })]);
    if (!rows.length) box.appendChild(msg('لا بيانات بعد.'));
    rows.forEach(function (x) { box.appendChild(el('div', { class: 'adm-hb' }, [el('span', { class: 'adm-hb-n', text: x.name }), el('span', { class: 'adm-hb-t' }, [el('i', { style: 'width:' + Math.max(3, Math.round(x.n / max * 100)) + '%' })]), el('b', { text: fmtN(x.n) })])); });
    return box;
  }
  function stat(label, value, sub) { return el('div', { class: 'adm-stat panel' }, [el('div', { class: 'adm-stat-l', text: label }), el('div', { class: 'adm-stat-v', text: value }), sub ? el('div', { class: 'adm-stat-s', text: sub }) : null]); }

  // ---- shell
  var tabs = [['overview', 'نظرة عامة'], ['users', 'المستخدمون'], ['certs', 'الشهادات'], ['board', 'المتصدرون'], ['usage', 'الاستخدام'], ['messages', 'الرسائل'], ['visits', 'الزيارات'], ['audit', 'سجل النشاط'], ['settings', 'الإعدادات'], ['backup', 'نسخ احتياطي'], ['security', 'الأمان (MFA)']];
  var nav = el('div', { class: 'cdx-tabs adm-tabs' }), view = el('div', { class: 'adm-view' }), cur = '';
  var VIEWS = {};
  tabs.forEach(function (t) { var b = el('button', { type: 'button', text: t[1] }); b.onclick = function () { show(t[0]); }; b.dataset.t = t[0]; nav.appendChild(b); });
  function show(t) { cur = t; Array.prototype.forEach.call(nav.children, function (b) { b.className = b.dataset.t === t ? 'on' : ''; }); clear(view).appendChild(msg('جارٍ التحميل…')); try { location.hash = t; } catch (e) {} VIEWS[t](); }
  function bad(e) { clear(view).appendChild(msg('تعذّر التحميل: ' + ((e && e.message) || ''), 1)); }
  function pager(state, total, size, reload) {
    var pg = Math.max(1, Math.ceil(total / size)), page = Math.floor(state.off / size) + 1;
    var prev = el('button', { class: 'btn sm', type: 'button', text: 'السابق' }), next = el('button', { class: 'btn sm', type: 'button', text: 'التالي' });
    prev.disabled = page <= 1; next.disabled = page >= pg;
    prev.onclick = function () { state.off = Math.max(0, state.off - size); reload(); }; next.onclick = function () { state.off += size; reload(); };
    return el('div', { class: 'adm-pager' }, [prev, el('span', { text: 'صفحة ' + page + ' من ' + pg + ' (' + fmtN(total) + ')' }), next]);
  }
  function debounce(fn, ms) { var t; return function () { clearTimeout(t); t = setTimeout(fn, ms); }; }
  function sel(opts, val) { var s = el('select'); opts.forEach(function (o) { var op = el('option', { value: o[0], text: o[1] }); if (o[0] === val) op.selected = true; s.appendChild(op); }); return s; }

  // ---- alerts
  var LV = { crit: 'عاجل', warn: 'تنبيه', info: 'معلومة' };
  function setBadge(al) {
    var b = nav.querySelector('[data-t=overview]'); if (!b) return;
    var old = b.querySelector('.adm-badge'); if (old) old.remove();
    var n = al.filter(function (x) { return x.level !== 'info'; }).length;
    if (n) b.appendChild(el('span', { class: 'adm-badge', text: String(n), 'aria-label': n + ' تنبيهات' }));
  }
  function alertsBox(al) {
    var box = el('div', { class: 'adm-alerts' });
    if (!al.length) { box.appendChild(el('div', { class: 'adm-alert ok', text: 'كل شيء على ما يرام — لا تنبيهات الآن.' })); return box; }
    var order = { crit: 0, warn: 1, info: 2 };
    al.slice().sort(function (a, b) { return (order[a.level] || 3) - (order[b.level] || 3); }).forEach(function (x) {
      var go = el('button', { class: 'btn sm', type: 'button', text: 'افتح' });
      go.onclick = function () { if (VIEWS[x.tab]) show(x.tab); };
      box.appendChild(el('div', { class: 'adm-alert ' + (LV[x.level] ? x.level : 'info') }, [
        el('div', {}, [el('b', { text: (LV[x.level] || '') + ' • ' + x.title }), el('div', { class: 'adm-um', text: x.detail })]), go]));
    });
    return box;
  }

  // ================= overview
  VIEWS.overview = function () {
    Promise.all([rpc('admin_overview'), rpc('admin_alerts').catch(function () { return []; })]).then(function (rs) {
      var o = rs[0], al = rs[1] || [];
      if (!o) throw new Error(ERR.denied);
      clear(view);
      setBadge(al);
      view.appendChild(alertsBox(al));
      var g = el('div', { class: 'adm-grid' }, [
        stat('المستخدمون', fmtN(o.users), 'اليوم +' + o.new_today + ' • 7 أيام +' + o.new_7d + ' • 30 يومًا +' + o.new_30d),
        stat('نشطون آخر 7 أيام', fmtN(o.active_7d), 'سجّلوا دخولًا'),
        stat('الشهادات الصادرة', fmtN(o.certs), 'آخر 7 أيام: ' + o.certs_7d),
        stat('تسجيلات اليوم', fmtN(o.new_today), 'حسابات جديدة'),
        stat('أعضاء لوحة المتصدرين', fmtN(o.leaderboard)),
        stat('رسائل جديدة', fmtN(o.messages_new), 'من ' + o.messages_all),
        stat('طلبات المساعد اليوم', fmtN(o.req_today), '30 يومًا: ' + fmtN(o.req_30d)),
        stat('محظورون / أدمن', o.banned + ' / ' + o.admins)]);
      view.appendChild(g);
      view.appendChild(el('div', { class: 'adm-charts' }, [barChart(o.signups, 'تسجيلات جديدة', 'var(--accent)'), barChart(o.cert_series, 'شهادات صادرة', 'var(--accent2, #f5b84b)'), barChart(o.req_series, 'طلبات المساعد', 'var(--muted)'), hBars(o.cert_cats, 'الشهادات حسب القسم')]));
    }).catch(bad);
  };

  // ================= users
  var US = { q: '', f: 'all', s: 'new', off: 0 }, PAGE = 20;
  VIEWS.users = function () {
    clear(view);
    var q = el('input', { type: 'search', placeholder: 'ابحث بالبريد أو الاسم المستعار', value: US.q, 'aria-label': 'بحث' });
    var f = sel([['all', 'الكل'], ['admin', 'الأدمن'], ['banned', 'المحظورون'], ['active7', 'نشطون 7 أيام'], ['certs', 'لديهم شهادات'], ['board', 'على اللوحة']], US.f);
    var s = sel([['new', 'الأحدث'], ['old', 'الأقدم'], ['points', 'الأعلى نقاطًا'], ['active', 'آخر دخول'], ['requests', 'الأكثر طلبات']], US.s);
    var csv = el('button', { class: 'btn sm', type: 'button', text: 'تصدير CSV' });
    var list = el('div', { class: 'adm-list' });
    view.appendChild(el('div', { class: 'adm-bar' }, [q, f, s, csv])); view.appendChild(list);
    function load() {
      US.q = q.value; US.f = f.value; US.s = s.value; list.textContent = ''; list.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_users_list', { p_q: US.q, p_filter: US.f, p_sort: US.s, p_limit: PAGE, p_offset: US.off }).then(function (d) {
        if (!d) throw new Error(ERR.denied);
        clear(list); if (!d.rows.length) { list.appendChild(msg('لا نتائج.')); return; }
        list.appendChild(el('p', { class: 'cdx-sub', text: 'النتائج: ' + fmtN(d.total) + '. ترقية أدمن جديد تتم من SQL فقط، حفاظًا على الأمان.' }));
        d.rows.forEach(function (u) { list.appendChild(userCard(u)); });
        list.appendChild(pager(US, d.total, PAGE, load));
      }).catch(function (e) { clear(list).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    var reset = function () { US.off = 0; load(); };
    q.oninput = debounce(reset, 350); f.onchange = reset; s.onchange = reset;
    csv.onclick = function () {
      csv.disabled = true;
      rpc('admin_users_list', { p_q: q.value, p_filter: f.value, p_sort: s.value, p_limit: 1000, p_offset: 0 }).then(function (d) {
        var cell = function (v) { v = v == null ? '' : String(v); if (/^[=+\-@\t\r]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
        var head = ['email', 'role', 'banned', 'points', 'level', 'certificates', 'nick', 'daily_limit', 'requests_total', 'created_at', 'last_sign_in_at'];
        var lines = [head.join(',')].concat(d.rows.map(function (u) { return [u.email, u.role, u.banned, u.points, u.level, u.certs, u.nick, u.daily_limit, u.total_requests, u.created_at, u.last_sign_in_at].map(cell).join(','); }));
        var a = el('a', { href: URL.createObjectURL(new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' })), download: 'cyberdex-users-' + new Date().toISOString().slice(0, 10) + '.csv' });
        document.body.appendChild(a); a.click(); a.remove(); toast('تم تجهيز الملف (' + d.rows.length + ' مستخدم).');
      }).catch(fail).then(function () { csv.disabled = false; });
    };
    load();
  };
  function badge(t, c) { return el('span', { class: 'adm-badge ' + (c || ''), text: t }); }
  function userCard(u) {
    var head = el('div', { class: 'adm-uh' }, [el('b', { text: u.email || '(بدون بريد)', dir: 'ltr' })]);
    if (u.role === 'admin') head.appendChild(badge('أدمن', 'ad')); if (u.banned) head.appendChild(badge('محظور', 'bn')); if (u.on_board) head.appendChild(badge('لوحة: ' + u.nick, 'lb'));
    var meta = el('div', { class: 'adm-um', text: fmtN(u.points) + ' نقطة • ' + (LEVELS[u.level] || '') + ' • ' + u.certs + ' شهادة • آخر دخول ' + fmtDay(u.last_sign_in_at) + ' • انضم ' + fmtDay(u.created_at) });
    var c = el('button', { type: 'button', class: 'panel adm-ucard' }, [head, meta]); c.onclick = function () { openUser(u.id); }; return c;
  }
  function openUser(id) {
    var box = el('div', { class: 'cdx-box adm-big', role: 'dialog', 'aria-modal': 'true' }, [msg('جارٍ التحميل…')]);
    var ov = el('div', { class: 'cdx-overlay' }, [box]);
    function close() { ov.remove(); document.removeEventListener('keydown', esc); }
    function esc(e) { if (e.key === 'Escape' && !document.querySelector('.adm-ov2')) close(); }
    ov.addEventListener('click', function (e) { if (e.target === ov) close(); }); document.addEventListener('keydown', esc); document.body.appendChild(ov);
    function reload(refreshList) { if (refreshList && cur === 'users') VIEWS.users(); render(); }
    function render() {
      rpc('admin_user_detail', { p_uid: id }).then(function (d) {
        if (!d) throw new Error(ERR.none);
        var p = d.profile, self = p.id === uid, isAd = p.role === 'admin'; clear(box);
        var x = el('button', { class: 'cdx-x', type: 'button', 'aria-label': 'إغلاق', text: '×' }); x.onclick = close; box.appendChild(x);
        box.appendChild(el('h3', { text: p.email || '(بدون بريد)', dir: 'ltr' }));
        var kv = function (k, v) { return el('div', { class: 'adm-kv' }, [el('span', { text: k }), el('b', { text: String(v) })]); };
        box.appendChild(el('div', { class: 'adm-kvs' }, [kv('الدور', isAd ? 'أدمن' : 'مستخدم'), kv('الحالة', p.banned ? 'محظور' + (p.ban_reason ? ' — ' + p.ban_reason : '') : 'نشط'), kv('انضم', fmtD(p.created_at)), kv('آخر دخول', fmtD(d.auth && d.auth.last_sign_in_at)),
          kv('البريد مؤكَّد', d.auth && d.auth.confirmed_at ? 'نعم' : 'لا'), kv('النقاط', fmtN(d.score && d.score.points) + ' (' + (LEVELS[d.score && d.score.lvl] || '') + ')'),
          kv('تعلَّم أدوات', d.progress.learned), kv('محاكاة/مختبر', d.progress.sims), kv('تحدّي يومي', d.progress.daily), kv('آخر مزامنة', fmtD(d.progress.updated_at)),
          kv('طلبات المساعد', d.usage.total + ' (اليوم ' + d.usage.today + ')'), kv('رسائله', d.messages), kv('اللوحة', d.board ? d.board.nick : (p.lb_blocked ? 'ممنوع' : 'غير منضم'))]));
        box.appendChild(el('h4', { text: 'الشهادات (' + d.certificates.length + ')' }));
        if (!d.certificates.length) box.appendChild(msg('لا شهادات.'));
        d.certificates.forEach(function (c) {
          var rv = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'سحب' });
          rv.onclick = function () { dialog({ title: 'سحب الشهادة ' + c.code, text: 'ستُحذف الشهادة ولن يعمل رابط التحقق منها. يستطيع المستخدم إعادة الاختبار.', input: 'السبب (اختياري)', okText: 'سحب', danger: true }).then(function (r) { if (r === null) return; rpc('admin_revoke_certificate', { p_code: c.code, p_reason: r }).then(res).then(function () { toast('تم سحب الشهادة.'); reload(true); }).catch(fail); }); };
          box.appendChild(el('div', { class: 'adm-line' }, [el('span', { text: c.code, dir: 'ltr' }), el('span', { text: c.category + ' • ' + c.score + '%' }), rv]));
        });
        var lim = el('input', { type: 'number', min: '0', max: '1000', placeholder: 'افتراضي', value: p.daily_limit == null ? '' : String(p.daily_limit), style: 'width:90px' }), sl = el('button', { class: 'btn sm', type: 'button', text: 'حفظ الحد' });
        sl.onclick = function () { var v = lim.value === '' ? null : Math.max(0, Math.min(1000, parseInt(lim.value, 10) || 0)); rpc('admin_set_limit', { p_uid: id, p_limit: v }).then(res).then(function () { toast('تم حفظ الحد.'); reload(false); }).catch(fail); };
        box.appendChild(el('h4', { text: 'الإجراءات' }));
        box.appendChild(el('div', { class: 'adm-line' }, [el('span', { text: 'حد المساعد اليومي' }), lim, sl]));
        var acts = el('div', { class: 'adm-acts' });
        if (!self && !isAd) {
          var ban = el('button', { class: 'btn sm' + (p.banned ? '' : ' adm-danger'), type: 'button', text: p.banned ? 'رفع الحظر' : 'حظر' });
          ban.onclick = function () {
            if (p.banned) { rpc('admin_ban_user', { p_uid: id, p_banned: false }).then(res).then(function () { toast('تم رفع الحظر.'); reload(true); }).catch(fail); return; }
            dialog({ title: 'حظر المستخدم', text: 'لن يستطيع استخدام المساعد أو إرسال رسائل أو الانضمام للوحة.', input: 'سبب الحظر (اختياري)', okText: 'حظر', danger: true }).then(function (r) { if (r === null) return; rpc('admin_ban_user', { p_uid: id, p_banned: true, p_reason: r }).then(res).then(function () { toast('تم الحظر.'); reload(true); }).catch(fail); });
          };
          acts.appendChild(ban);
          var del = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'حذف الحساب نهائيًا' });
          del.onclick = function () { dialog({ title: 'حذف حساب مستخدم', text: 'يُحذف الحساب وكل بياناته نهائيًا (التقدّم والشهادات واللوحة والرسائل). لا تراجع.', confirmWord: 'DELETE', okText: 'احذف نهائيًا', danger: true }).then(function (r) { if (!r) return; rpc('admin_delete_user', { p_uid: id }).then(res).then(function () { toast('تم حذف الحساب.'); close(); if (cur === 'users') VIEWS.users(); }).catch(fail); }); };
          acts.appendChild(del);
        } else acts.appendChild(msg(self ? 'هذا حسابك. للحذف استخدم "حذف حسابي" من قائمة حسابي.' : 'حسابات الأدمن لا تُحظر ولا تُحذف من هنا.'));
        if (p.lb_blocked) { var ub = el('button', { class: 'btn sm', type: 'button', text: 'السماح له بلوحة المتصدرين' }); ub.onclick = function () { rpc('admin_lb_set_block', { p_uid: id, p_blocked: false }).then(res).then(function () { toast('تم.'); reload(true); }).catch(fail); }; acts.appendChild(ub); }
        box.appendChild(acts);
        rpc('admin_public_profile_of', { p_uid: id }).then(function (pp) {
          if (!pp) return;
          var rm = el('button', { class: 'btn sm', type: 'button', text: 'حذف ملفه العام' }), rb = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'حذف ومنع' });
          rm.onclick = function () { dialog({ title: 'حذف الملف العام @' + pp.handle + '؟', okText: 'حذف', danger: true }).then(function (v) { if (v) rpc('admin_profile_remove', { p_uid: id, p_block: false }).then(res).then(function () { toast('تم.'); reload(false); }).catch(fail); }); };
          rb.onclick = function () { dialog({ title: 'حذف @' + pp.handle + ' ومنعه من الملفات العامة؟', okText: 'حذف ومنع', danger: true }).then(function (v) { if (v) rpc('admin_profile_remove', { p_uid: id, p_block: true }).then(res).then(function () { toast('تم.'); reload(false); }).catch(fail); }); };
          acts.appendChild(el('p', { class: 'adm-um', text: 'ملف عام: @' + pp.handle + (pp.show_certs ? ' (يعرض الشهادات)' : '') })); acts.appendChild(rm); acts.appendChild(rb);
        }).catch(function () {});
        if (d.history.length) { box.appendChild(el('h4', { text: 'آخر الإجراءات عليه' })); d.history.forEach(function (h) { box.appendChild(el('div', { class: 'adm-um', text: fmtD(h.at) + ' • ' + (ACTIONS[h.action] || h.action) + ' • ' + (h.by || '') })); }); }
      }).catch(function (e) { clear(box).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    render();
  }

  // ================= certificates
  var CS = { q: '', off: 0 };
  VIEWS.certs = function () {
    clear(view);
    var q = el('input', { type: 'search', placeholder: 'ابحث بالرقم أو الاسم أو البريد أو القسم', value: CS.q, 'aria-label': 'بحث' }), list = el('div', { class: 'adm-list' });
    view.appendChild(el('div', { class: 'adm-bar' }, [q])); view.appendChild(list);
    function load() {
      CS.q = q.value; list.textContent = ''; list.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_certificates', { p_q: CS.q, p_limit: PAGE, p_offset: CS.off }).then(function (d) {
        if (!d) throw new Error(ERR.denied); clear(list); if (!d.rows.length) { list.appendChild(msg('لا شهادات.')); return; }
        d.rows.forEach(function (c) {
          var rv = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'سحب' });
          rv.onclick = function () { dialog({ title: 'سحب الشهادة ' + c.code, text: 'ستُحذف ولن يعمل رابط التحقق منها. يستطيع صاحبها إعادة الاختبار.', input: 'السبب (اختياري)', okText: 'سحب', danger: true }).then(function (r) { if (r === null) return; rpc('admin_revoke_certificate', { p_code: c.code, p_reason: r }).then(res).then(function () { toast('تم سحب الشهادة.'); load(); }).catch(fail); }); };
          list.appendChild(el('div', { class: 'panel adm-ucard' }, [el('div', { class: 'adm-uh' }, [el('b', { text: c.code, dir: 'ltr' }), badge(c.score + '%', 'lb')]), el('div', { class: 'adm-um', text: c.name + ' • ' + c.category + ' • ' + fmtDay(c.issued_at) }), el('div', { class: 'adm-um', text: c.email || '', dir: 'ltr' }), el('div', { class: 'adm-row' }, [rv])]));
        });
        list.appendChild(pager(CS, d.total, PAGE, load));
      }).catch(function (e) { clear(list).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    q.oninput = debounce(function () { CS.off = 0; load(); }, 350); load();
  };

  // ================= leaderboard
  VIEWS.board = function () {
    clear(view);
    var q = el('input', { type: 'search', placeholder: 'ابحث بالاسم المستعار أو البريد', 'aria-label': 'بحث' }), list = el('div', { class: 'adm-list' });
    view.appendChild(el('div', { class: 'adm-bar' }, [q])); view.appendChild(list);
    function load() {
      list.textContent = ''; list.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_leaderboard', { p_q: q.value }).then(function (rows) {
        if (!rows) throw new Error(ERR.denied); clear(list); if (!rows.length) { list.appendChild(msg('لا أعضاء.')); return; }
        rows.forEach(function (r, i) {
          var rn = el('button', { class: 'btn sm', type: 'button', text: 'إعادة تسمية' }), rm = el('button', { class: 'btn sm', type: 'button', text: 'إزالة' }), rb = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'إزالة + منع' });
          rn.onclick = function () { dialog({ title: 'اسم مستعار جديد', text: 'من 3 إلى 20 حرفًا (عربي/إنجليزي/أرقام/_).', input: 'الاسم الجديد', okText: 'حفظ' }).then(function (v) { if (!v) return; rpc('admin_lb_rename', { p_uid: r.user_id, p_nick: v }).then(res).then(function () { toast('تم.'); load(); }).catch(fail); }); };
          rm.onclick = function () { dialog({ title: 'إزالة ' + r.nick + ' من اللوحة؟', text: 'يستطيع الانضمام مرة أخرى باسم جديد.', okText: 'إزالة', danger: true }).then(function (v) { if (!v) return; rpc('admin_lb_remove', { p_uid: r.user_id, p_block: false }).then(res).then(function () { toast('تمت الإزالة.'); load(); }).catch(fail); }); };
          rb.onclick = function () { dialog({ title: 'إزالة ' + r.nick + ' ومنعه؟', text: 'لن يستطيع الانضمام للوحة مجددًا حتى تسمح له من صفحته.', okText: 'إزالة ومنع', danger: true }).then(function (v) { if (!v) return; rpc('admin_lb_remove', { p_uid: r.user_id, p_block: true }).then(res).then(function () { toast('تم.'); load(); }).catch(fail); }); };
          list.appendChild(el('div', { class: 'panel adm-ucard' }, [el('div', { class: 'adm-uh' }, [el('b', { text: (i + 1) + '. ' + r.nick }), badge(fmtN(r.points) + ' نقطة', 'lb')]), el('div', { class: 'adm-um', text: (LEVELS[r.level] || '') + ' • ' + r.certs + ' شهادة • ' + (r.email || ''), dir: 'auto' }), el('div', { class: 'adm-row' }, [rn, rm, rb])]));
        });
      }).catch(function (e) { clear(list).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    q.oninput = debounce(load, 350); load();
  };

  // ================= usage
  VIEWS.usage = function () {
    Promise.all([sb.rpc('admin_usage_summary', { days: 30 }), sb.from('settings').select('key,value').in('key', ['price_in_per_mtok', 'price_out_per_mtok'])]).then(function (rs) {
      clear(view); if (rs[0].error) { view.appendChild(msg('تعذّر التحميل: ' + rs[0].error.message, 1)); return; }
      var p = {}; (rs[1].data || []).forEach(function (x) { p[x.key] = Number(x.value) || 0; });
      if (!p.price_in_per_mtok && !p.price_out_per_mtok) view.appendChild(msg('أدخل أسعار النموذج في تبويب "الإعدادات" ليظهر تقدير التكلفة.', 1));
      var tot = { r: 0, i: 0, o: 0 }, t = el('table', { class: 'adm-t' }), h = el('tr'); ['اليوم', 'مستخدمون', 'طلبات', 'Tokens دخل', 'Tokens خرج', 'تكلفة تقديرية'].forEach(function (x) { h.appendChild(el('th', { text: x })); }); t.appendChild(h);
      rs[0].data.forEach(function (d) {
        var c = d.input_tokens / 1e6 * p.price_in_per_mtok + d.output_tokens / 1e6 * p.price_out_per_mtok; tot.r += +d.requests; tot.i += +d.input_tokens; tot.o += +d.output_tokens;
        var row = el('tr'); [d.day, fmtN(d.users), fmtN(d.requests), fmtN(d.input_tokens), fmtN(d.output_tokens), usd(c)].forEach(function (x) { row.appendChild(el('td', { text: String(x) })); }); t.appendChild(row);
      });
      var tc = tot.i / 1e6 * p.price_in_per_mtok + tot.o / 1e6 * p.price_out_per_mtok;
      view.appendChild(el('p', { class: 'adm-sum', text: 'آخر 30 يومًا: ' + fmtN(tot.r) + ' طلب — تكلفة تقديرية ' + usd(tc) }));
      view.appendChild(el('div', { class: 'adm-scroll' }, [t]));
    });
  };

  // ================= messages
  VIEWS.messages = function () {
    sb.from('messages').select('*').order('created_at', { ascending: false }).limit(200).then(function (r) {
      clear(view); if (r.error) { view.appendChild(msg('تعذّر التحميل: ' + r.error.message, 1)); return; }
      if (!r.data.length) { view.appendChild(msg('لا توجد رسائل بعد.')); return; }
      var kinds = { contact: 'تواصل', bug: 'خطأ', suggestion: 'اقتراح' };
      r.data.forEach(function (m) {
        var st = sel([['new', 'جديدة'], ['read', 'مقروءة'], ['done', 'تمت']], m.status);
        st.onchange = function () { sb.from('messages').update({ status: st.value }).eq('id', m.id); };
        var del = el('button', { class: 'btn sm', type: 'button', text: 'حذف' }), card;
        del.onclick = function () { dialog({ title: 'حذف هذه الرسالة؟', okText: 'حذف', danger: true }).then(function (v) { if (v) sb.from('messages').delete().eq('id', m.id).then(function (x) { if (!x.error) card.remove(); }); }); };
        card = el('div', { class: 'panel adm-msg' }, [el('div', { class: 'adm-meta', text: (kinds[m.kind] || m.kind) + ' • ' + (m.email || 'مجهول') + ' • ' + fmtD(m.created_at) + (m.page ? ' • ' + m.page : '') }), el('p', { text: m.body }), el('div', { class: 'adm-row' }, [st, del])]);
        view.appendChild(card);
      });
    });
  };

  // ================= audit log
  var AS = { a: '', off: 0 };
  function detailText(a) {
    var d = a.detail || {}, o = [];
    if (a.action === 'settings') return Object.keys(d).map(function (k) { return k + ': ' + JSON.stringify(d[k].to); }).join(' ، ');
    if (d.email) o.push(d.email); if (d.nick) o.push(d.nick); if (d.name) o.push(d.name + (d.category ? ' / ' + d.category : '')); if (d.from != null && d.to != null) o.push(d.from + ' ← ' + d.to); if (d.reason) o.push('السبب: ' + d.reason);
    return o.join(' • ');
  }
  VIEWS.audit = function () {
    clear(view);
    var f = sel([['', 'كل الإجراءات']].concat(Object.keys(ACTIONS).map(function (k) { return [k, ACTIONS[k]]; })), AS.a), list = el('div', { class: 'adm-list' });
    view.appendChild(el('div', { class: 'adm-bar' }, [f])); view.appendChild(list);
    function load() {
      AS.a = f.value; list.textContent = ''; list.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_audit_list', { p_action: AS.a || null, p_limit: 30, p_offset: AS.off }).then(function (d) {
        if (!d) throw new Error(ERR.denied); clear(list); if (!d.rows.length) { list.appendChild(msg('لا إجراءات مسجّلة بعد.')); return; }
        d.rows.forEach(function (a) { list.appendChild(el('div', { class: 'panel adm-ucard' }, [el('div', { class: 'adm-uh' }, [el('b', { text: ACTIONS[a.action] || a.action }), el('span', { class: 'adm-um', text: fmtD(a.at) })]), el('div', { class: 'adm-um', text: detailText(a) }), el('div', { class: 'adm-um', text: 'بواسطة: ' + (a.admin_email || '—'), dir: 'auto' })])); });
        list.appendChild(pager(AS, d.total, 30, load));
      }).catch(function (e) { clear(list).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    f.onchange = function () { AS.off = 0; load(); }; load();
  };

  // ================= settings
  var NUMS = [['default_daily_limit', 'الحدّ اليومي الافتراضي لكل مستخدم'], ['global_daily_cap', 'السقف اليومي لكل المستخدمين (طلبات)'], ['price_in_per_mtok', 'سعر مليون Token دخل (دولار)'], ['price_out_per_mtok', 'سعر مليون Token خرج (دولار)']];
  VIEWS.settings = function () {
    sb.from('settings').select('key,value').then(function (r) {
      clear(view); if (r.error) { view.appendChild(msg('تعذّر التحميل: ' + r.error.message, 1)); return; }
      var c = {}; r.data.forEach(function (x) { c[x.key] = x.value; });
      var form = el('form', { class: 'adm-form' }), note = msg(''), I = {};
      function sec(t) { form.appendChild(el('h4', { text: t })); }
      function chk(key, label, val) { var i = el('input', { type: 'checkbox' }); i.checked = !!val; I[key] = i; form.appendChild(el('label', {}, [el('span', { text: label }), i])); return i; }
      function txt(key, label, val, ph) { var i = el('input', { type: 'text', maxlength: '200', value: val || '', placeholder: ph || '' }); I[key] = i; form.appendChild(el('label', { class: 'adm-col' }, [el('span', { text: label }), i])); }
      var F = c.features && typeof c.features === 'object' ? c.features : {}, M = c.maintenance || {}, A = c.announcement || {};
      sec('الميزات (إيقاف/تشغيل للزوّار)');
      chk('f_lab', 'المختبر العملي', F.lab !== false); chk('f_exams', 'الاختبارات والشهادات', F.exams !== false); chk('f_leaderboard', 'لوحة المتصدرين', F.leaderboard !== false);
      chk('assistant_enabled', 'المساعد الذكي', c.assistant_enabled !== false); chk('registration_open', 'فتح التسجيل للحسابات الجديدة', c.registration_open !== false);
      sec('وضع الصيانة'); chk('m_on', 'تفعيل شريط الصيانة', M.active); txt('m_text', 'نص الشريط', M.text, 'مثال: صيانة قصيرة الليلة، قد تتأخر الاستجابة');
      sec('إعلان'); chk('a_on', 'إظهار الإعلان', A.active); txt('a_text', 'نص الإعلان', A.text, 'يظهر أعلى كل الصفحات');
      sec('المساعد والتكلفة');
      NUMS.forEach(function (f) { var i = el('input', { type: 'number', min: '0', step: 'any', value: c[f[0]] == null ? '' : String(c[f[0]]) }); I[f[0]] = i; form.appendChild(el('label', {}, [el('span', { text: f[1] }), i])); });
      sec('الأمان'); chk('require_admin_mfa', 'إلزام الأدمن بالتحقق بخطوتين (فعّله بعد تسجيل MFA)', c.require_admin_mfa === true);
      form.appendChild(el('button', { class: 'btn', type: 'submit', text: 'حفظ' })); form.appendChild(note);
      form.onsubmit = function (e) {
        e.preventDefault();
        var p = { features: { lab: I.f_lab.checked, exams: I.f_exams.checked, leaderboard: I.f_leaderboard.checked }, assistant_enabled: I.assistant_enabled.checked, registration_open: I.registration_open.checked,
          maintenance: { active: I.m_on.checked, text: I.m_text.value.trim().slice(0, 200) }, announcement: { active: I.a_on.checked, text: I.a_text.value.trim().slice(0, 200) }, require_admin_mfa: I.require_admin_mfa.checked };
        NUMS.forEach(function (f) { p[f[0]] = Math.max(0, Number(I[f[0]].value) || 0); });
        note.textContent = 'جارٍ الحفظ…';
        rpc('admin_save_settings', { p: p }).then(function (x) { if (x !== 'ok') throw new Error(ERR[x] || x); note.textContent = 'تم الحفظ.'; toast('تم حفظ الإعدادات.'); }).catch(function (er) { note.textContent = 'فشل الحفظ: ' + er.message; });
      };
      view.appendChild(form);
    });
  };

  // ================= visits (anonymous aggregate)
  var VP = { days: 30 };
  VIEWS.visits = function () {
    clear(view);
    var f = sel([['7', 'آخر 7 أيام'], ['30', 'آخر 30 يومًا'], ['90', 'آخر 90 يومًا']], String(VP.days)), box = el('div');
    view.appendChild(el('div', { class: 'adm-bar' }, [f]));
    view.appendChild(el('p', { class: 'adm-um', text: 'إحصائيات مجمّعة مجهولة: لا نخزّن هوية الزائر ولا IP. تُحتسب الزيارة (جلسة) مرة واحدة لكل تبويب، ولا تُحتسب زياراتك كأدمن إذا فعّلت وضع المالك، ولا من يفعّل Do Not Track. التوقيت: القاهرة.' }));
    view.appendChild(box);
    function load() {
      VP.days = +f.value; box.textContent = ''; box.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_visit_stats', { p_days: VP.days }).then(function (d) {
        if (!d) throw new Error(ERR.denied); clear(box);
        var t = d.totals, per = Math.round((t.views / d.period) * 10) / 10;
        box.appendChild(el('div', { class: 'adm-grid' }, [
          stat('مشاهدات الصفحات', fmtN(t.views), 'متوسط يومي ' + per),
          stat('الزيارات (جلسات)', fmtN(t.visits), 'آخر ' + d.period + ' يومًا'),
          stat('اليوم', fmtN(t.today_views), 'زيارات اليوم ' + fmtN(t.today_visits)),
          stat('بداية التسجيل', d.since ? fmtDay(d.since) : '—', 'الأرقام تبدأ من هنا')]));
        if (!t.views) { box.appendChild(msg('لا بيانات بعد. ستظهر الأرقام بعد رفع النسخة وزيارة الموقع.')); return; }
        box.appendChild(el('div', { class: 'adm-charts' }, [
          barChart(d.days.map(function (x) { return { day: x.day, n: x.views }; }), 'مشاهدات الصفحات', 'var(--accent)'),
          barChart(d.days.map(function (x) { return { day: x.day, n: x.visits }; }), 'الزيارات (جلسات)', 'var(--accent2, #f5b84b)')]));
        box.appendChild(el('div', { class: 'adm-charts' }, [
          hBars(d.sections.map(function (x) { return { name: x.name, n: x.n }; }), 'الأقسام الأكثر قراءة'),
          hBars(d.top.map(function (x) { return { name: x.page.replace(/\.html$/, ''), n: x.n }; }), 'أكثر الصفحات مشاهدة')]));
      }).catch(function (e) { clear(box).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    f.onchange = load; load();
  };

  // ================= backups
  VIEWS.backup = function () {
    clear(view);
    var list = el('div', { class: 'adm-list' }), mk = el('button', { class: 'btn', type: 'button', text: 'إنشاء نسخة الآن' });
    view.appendChild(el('p', { class: 'adm-um', text: 'تُؤخذ نسخة تلقائية يوميًا (تُحفظ آخر 14)، ونسخك اليدوية (آخر 20). تحتوي المستخدمين والتقدّم والشهادات واللوحة والملفات العامة والإعدادات والرسائل. أبقِ الملف المنزَّل خاصًا لأنه يضم بيانات مستخدمين.' }));
    view.appendChild(el('div', { class: 'adm-bar' }, [mk])); view.appendChild(list);
    function kb(n) { return n > 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
    function load() {
      list.textContent = ''; list.appendChild(msg('جارٍ التحميل…'));
      rpc('admin_backups_list').then(function (rows) {
        if (!rows) throw new Error(ERR.denied); clear(list); if (!rows.length) { list.appendChild(msg('لا نسخ بعد.')); return; }
        rows.forEach(function (b) {
          var rc = b.row_counts || {}, dl = el('button', { class: 'btn', type: 'button', text: 'تنزيل' }), del = el('button', { class: 'btn ghost', type: 'button', text: 'حذف' });
          dl.onclick = function () {
            dl.disabled = true;
            rpc('admin_backup_get', { p_id: b.id }).then(function (d) {
              if (!d) throw new Error('غير موجودة');
              var url = URL.createObjectURL(new Blob([JSON.stringify(d, null, 1)], { type: 'application/json' })), a = document.createElement('a');
              a.href = url; a.download = 'cyberdex-backup-' + b.id + '-' + String(b.created_at).slice(0, 10) + '.json'; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
            }).catch(function (e) { toast('تعذّر التنزيل: ' + e.message, 1); }).then(function () { dl.disabled = false; });
          };
          del.onclick = function () {
            dialog({ title: 'حذف النسخة #' + b.id, text: 'سيتم حذفها نهائيًا.', okText: 'حذف', danger: true }).then(function (y) {
              if (!y) return; rpc('admin_backup_delete', { p_id: b.id }).then(function (x) { if (!x || !x.ok) throw new Error(ERR[x && x.code] || 'فشل'); toast('تم الحذف.'); load(); }).catch(function (e) { toast(e.message, 1); });
            });
          };
          list.appendChild(el('div', { class: 'panel adm-ucard' }, [
            el('div', { class: 'adm-uh' }, [el('b', { text: (b.kind === 'auto' ? 'تلقائية' : 'يدوية') + ' #' + b.id }), el('span', { class: 'adm-um', text: fmtD(b.created_at) })]),
            el('div', { class: 'adm-um', text: 'مستخدمون ' + (rc.profiles || 0) + ' • تقدّم ' + (rc.progress || 0) + ' • شهادات ' + (rc.certificates || 0) + ' • رسائل ' + (rc.messages || 0) + ' • الحجم ' + kb(b.size || 0) }),
            el('div', { class: 'adm-bar' }, [dl, del])]));
        });
      }).catch(function (e) { clear(list).appendChild(msg('تعذّر التحميل: ' + e.message, 1)); });
    }
    mk.onclick = function () {
      mk.disabled = true;
      rpc('admin_backup_create').then(function (x) { if (!x || !x.ok) throw new Error(ERR[x && x.code] || 'فشل'); toast('تم إنشاء النسخة.'); load(); }).catch(function (e) { toast(e.message, 1); }).then(function () { mk.disabled = false; });
    };
    load();
  };

  // ================= security (MFA)
  VIEWS.security = function () {
    clear(view);
    sb.auth.mfa.listFactors().then(function (r) {
      var f = ((r.data && r.data.totp) || []).filter(function (x) { return x.status === 'verified'; });
      view.appendChild(el('p', { text: f.length ? 'التحقق بخطوتين مفعّل على حسابك ✅' : 'التحقق بخطوتين غير مفعّل. فعّله الآن ثم شغّل خيار "إلزام الأدمن" من الإعدادات، فيصبح الدخول للوحة مستحيلًا بدون هاتفك.' }));
      if (f.length) return;
      var go = el('button', { class: 'btn', type: 'button', text: 'تفعيل MFA' }); view.appendChild(go);
      go.onclick = function () {
        go.disabled = true;
        sb.auth.mfa.listFactors().then(function (lf) {
          var stale = ((lf.data && lf.data.all) || []).filter(function (x) { return x.status === 'unverified'; });
          return Promise.all(stale.map(function (x) { return sb.auth.mfa.unenroll({ factorId: x.id }); }));
        }).then(function () { return sb.auth.mfa.enroll({ factorType: 'totp', friendlyName: 'CyberDex-' + Date.now() }); }).then(function (e) {
          if (e.error) { go.disabled = false; view.appendChild(msg('تعذّر: ' + e.error.message, 1)); return; }
          var img = el('img', { src: e.data.totp.qr_code, alt: 'QR', width: '180', height: '180', style: 'background:#fff;padding:8px;border-radius:8px' });
          var code = el('input', { type: 'text', inputmode: 'numeric', maxlength: '6', placeholder: 'الكود من التطبيق', dir: 'ltr' }), ok = el('button', { class: 'btn', type: 'button', text: 'تأكيد' }), n = msg('');
          view.appendChild(el('p', { class: 'cdx-sub', text: 'امسح الرمز بتطبيق مصادقة (Google Authenticator أو Authy) ثم اكتب الكود. أو أدخل المفتاح يدويًا: ' + e.data.totp.secret })); view.appendChild(img); view.appendChild(code); view.appendChild(ok); view.appendChild(n);
          ok.onclick = function () { sb.auth.mfa.challengeAndVerify({ factorId: e.data.id, code: code.value.trim() }).then(function (v) { if (v.error) n.textContent = 'الكود غير صحيح.'; else show('security'); }); };
        });
      };
    });
  };

  // ================= start
  function start() {
    sb = window.CDX_SB; if (!sb) { var tries = (start.t = (start.t || 0) + 1); if (tries < 50) return setTimeout(start, 200); clear(app).appendChild(msg('لم يتم ضبط الخادم بعد (config.js فارغ).', 1)); return; }
    sb.auth.getSession().then(function (r) {
      var s = r.data.session; if (!s) { clear(app).appendChild(msg('سجّل الدخول بحساب الأدمن من زر "دخول" بالأعلى ثم أعد تحميل الصفحة.', 1)); sb.auth.onAuthStateChange(function (e, x) { if (x) location.reload(); }); return; }
      uid = s.user.id;
      sb.rpc('is_admin').then(function (a) {
        if (a.data === true) { clear(app); app.appendChild(nav); app.appendChild(view); var h = (location.hash || '').slice(1); show(VIEWS[h] ? h : 'overview'); if (h && h !== 'overview') rpc('admin_alerts').then(function (al) { setBadge(al || []); }).catch(function () {}); return; }
        clear(app); app.appendChild(msg('هذا الحساب ليس أدمن، أو أن MFA مطلوب ولم يتم التحقق به في هذه الجلسة.', 1));
        var wrap = el('div'); app.appendChild(wrap); view = wrap; mfaGate();
      });
    });
  }
  function mfaGate() {
    sb.auth.mfa.listFactors().then(function (r) {
      var f = ((r.data && r.data.totp) || []).filter(function (x) { return x.status === 'verified'; })[0]; if (!f) return;
      var code = el('input', { type: 'text', inputmode: 'numeric', maxlength: '6', placeholder: 'كود التحقق (6 أرقام)', dir: 'ltr' }), ok = el('button', { class: 'btn', type: 'button', text: 'تحقق' }), n = msg('');
      view.appendChild(code); view.appendChild(ok); view.appendChild(n);
      ok.onclick = function () { sb.auth.mfa.challengeAndVerify({ factorId: f.id, code: code.value.trim() }).then(function (v) { if (v.error) n.textContent = 'الكود غير صحيح.'; else location.reload(); }); };
    });
  }
  start();
})();
