/* CyberDex FX: interactive canvas backgrounds per skin (attack embers · defense network · prime gold dust) */
(function () {
  'use strict';
  try {
    var reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var saver = navigator.connection && navigator.connection.saveData;
    if (reduce || saver || !window.CDX_SKIN) return;
    var boot = function () { start(); };
    if (document.body) boot(); else document.addEventListener('DOMContentLoaded', boot);
  } catch (e) {}

  function start() {
    var root = document.documentElement;
    var fine = matchMedia('(hover:hover) and (pointer:fine)').matches;
    var mobile = !fine || innerWidth < 700;
    var cv = document.createElement('canvas');
    cv.id = 'cdx-fx'; cv.setAttribute('aria-hidden', 'true');
    cv.style.cssText = 'position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:0';
    document.body.insertBefore(cv, document.body.firstChild);
    var ctx = cv.getContext('2d'), W = 0, H = 0, DPR = 1;
    function size() {
      W = innerWidth; H = innerHeight;
      DPR = mobile ? 1 : Math.min(devicePixelRatio || 1, 1.25);
      cv.width = Math.round(W * DPR); cv.height = Math.round(H * DPR);
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    }
    size();
    var rt = 0;
    addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(size, 150); });

    var rgb = function (v, d) { return (getComputedStyle(root).getPropertyValue(v) || '').trim() || d; };
    function sprite(c, n) {
      var s = document.createElement('canvas'); s.width = s.height = n;
      var g = s.getContext('2d'), r = n / 2, gr = g.createRadialGradient(r, r, 0, r, r, r);
      gr.addColorStop(0, 'rgba(' + c + ',1)'); gr.addColorStop(.25, 'rgba(' + c + ',.55)'); gr.addColorStop(1, 'rgba(' + c + ',0)');
      g.fillStyle = gr; g.fillRect(0, 0, n, n); return s;
    }
    var rnd = Math.random;

    /* ---------- pointer ---------- */
    var P = { x: -999, y: -999, tx: -999, ty: -999, in: false, touch: false, last: 0 };
    addEventListener('pointermove', function (e) {
      P.tx = e.clientX; P.ty = e.clientY; P.touch = e.pointerType === 'touch'; P.last = performance.now();
      if (!P.in) { P.x = P.tx; P.y = P.ty; } P.in = true;
    }, { passive: true });
    addEventListener('pointerdown', function (e) {
      P.tx = e.clientX; P.ty = e.clientY; P.x = P.tx; P.y = P.ty; P.touch = e.pointerType === 'touch'; P.last = performance.now(); P.in = true;
      var t = e.target; if (t && /INPUT|TEXTAREA|SELECT/.test(t.tagName)) return;
      if (scene && scene.burst) scene.burst(e.clientX, e.clientY);
    }, { passive: true });
    document.addEventListener('mouseleave', function () { P.in = false; });
    var pOn = function (now) { return P.touch ? (now - P.last < 900) : P.in; };

    function aura(sp, now, a, s) {
      if (!pOn(now)) return;
      ctx.globalAlpha = a; ctx.drawImage(sp, P.x - s / 2, P.y - s / 2, s, s);
    }

    /* ---------- scenes ---------- */
    var scenes = {
      /* attack: rising embers that flee from the finger/cursor, sparks on click, slow scan line */
      attack: function () {
        var A = rgb('--accent-rgb', '255,59,74'), B = rgb('--halo-rgb', '255,120,50');
        var sA = sprite(A, 64), sB = sprite(B, 64), n = mobile ? 34 : 78, ps = [], sparks = [];
        var mk = function (init) { return { x: rnd() * W, y: init ? rnd() * H : H + 12, z: .4 + rnd() * .6, r: 2 + rnd() * 5, vy: -(18 + rnd() * 50), ph: rnd() * 6.28, hot: rnd() < .5, a: .35 + rnd() * .5 }; };
        for (var i = 0; i < n; i++) ps.push(mk(true));
        return {
          frame: function (dt, t, now) {
            ctx.globalCompositeOperation = 'lighter';
            var on = pOn(now), k, p, s, d;
            for (k = 0; k < ps.length; k++) {
              p = ps[k]; p.y += p.vy * p.z * dt; p.x += Math.sin(t * .9 + p.ph) * 14 * dt;
              if (on) { var dx = p.x - P.x, dy = p.y - P.y, d2 = dx * dx + dy * dy; if (d2 < 16900 && d2 > 1) { d = Math.sqrt(d2); var f = (1 - d / 130) * 240 * dt; p.x += dx / d * f; p.y += dy / d * f; } }
              if (p.y < -20 || p.x < -30 || p.x > W + 30) ps[k] = mk(false);
              ctx.globalAlpha = p.a * (.7 + .3 * Math.sin(t * 7 + p.ph)) * (.4 + .6 * Math.min(1, p.y / H));
              s = p.r * p.z * 5; ctx.drawImage(p.hot ? sB : sA, p.x - s / 2, p.y - s / 2, s, s);
            }
            for (k = sparks.length - 1; k >= 0; k--) {
              p = sparks[k]; p.life -= dt; if (p.life <= 0) { sparks.splice(k, 1); continue; }
              p.vy += 260 * dt; p.x += p.vx * dt; p.y += p.vy * dt;
              ctx.globalAlpha = Math.min(1, p.life / p.max * 1.4); s = 14 * (p.life / p.max) + 4;
              ctx.drawImage(sB, p.x - s / 2, p.y - s / 2, s, s);
            }
            aura(sA, now, .2, 240);
          },
          burst: function (x, y) {
            for (var i = 0; i < 18; i++) { var a = rnd() * 6.28, v = 80 + rnd() * 240; sparks.push({ x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 90, life: .5 + rnd() * .5, max: 1 }); }
          }
        };
      },

      /* defense: a living network: nodes, links, data packets travelling, the pointer is a probe */
      defense: function () {
        var A = rgb('--accent-rgb', '74,168,255'), B = rgb('--accent2-rgb', '34,211,238');
        var sA = sprite(A, 48), sB = sprite(B, 64), n = mobile ? 32 : 64, L = mobile ? 125 : 165, PR = mobile ? 170 : 200;
        var nodes = [], pk = [], rings = [], i;
        for (i = 0; i < n; i++) nodes.push({ x: rnd() * W, y: rnd() * H, vx: (rnd() - .5) * 26, vy: (rnd() - .5) * 26, r: 1.6 + rnd() * 1.6, srv: i % 6 === 0, ph: rnd() * 6.28 });
        return {
          frame: function (dt, t, now) {
            var on = pOn(now), a, b, dx, dy, d2, d, k;
            for (i = 0; i < n; i++) {
              a = nodes[i]; a.x += a.vx * dt; a.y += a.vy * dt;
              if (a.x < -20) a.x = W + 20; else if (a.x > W + 20) a.x = -20;
              if (a.y < -20) a.y = H + 20; else if (a.y > H + 20) a.y = -20;
              if (on) { dx = P.x - a.x; dy = P.y - a.y; d2 = dx * dx + dy * dy; if (d2 < PR * PR && d2 > 400) { d = Math.sqrt(d2); a.x += dx / d * 22 * dt; a.y += dy / d * 22 * dt; } }
            }
            ctx.globalCompositeOperation = 'lighter'; ctx.lineWidth = 1;
            var L2 = L * L;
            for (i = 0; i < n; i++) {
              a = nodes[i];
              for (k = i + 1; k < n; k++) {
                b = nodes[k]; dx = a.x - b.x; if (dx > L || dx < -L) continue; dy = a.y - b.y; d2 = dx * dx + dy * dy;
                if (d2 < L2) { ctx.strokeStyle = 'rgba(' + A + ',' + ((1 - Math.sqrt(d2) / L) * .34).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
              }
              if (on) { dx = P.x - a.x; dy = P.y - a.y; d2 = dx * dx + dy * dy; if (d2 < PR * PR) { ctx.strokeStyle = 'rgba(' + B + ',' + ((1 - Math.sqrt(d2) / PR) * .7).toFixed(3) + ')'; ctx.beginPath(); ctx.moveTo(P.x, P.y); ctx.lineTo(a.x, a.y); ctx.stroke(); } }
            }
            ctx.globalAlpha = 1;
            for (i = 0; i < n; i++) {
              a = nodes[i]; var s = a.r * (a.srv ? 7 : 5);
              ctx.globalAlpha = a.srv ? .95 : .7; ctx.drawImage(a.srv ? sB : sA, a.x - s / 2, a.y - s / 2, s, s);
              if (a.srv) { var q = ((t * .5 + a.ph) % 1); ctx.globalAlpha = (1 - q) * .45; ctx.strokeStyle = 'rgba(' + B + ',1)'; ctx.beginPath(); ctx.arc(a.x, a.y, 4 + q * 16, 0, 6.283); ctx.stroke(); }
            }
            // packets
            if (pk.length < (mobile ? 4 : 9) && rnd() < dt * 2.2) {
              a = nodes[(rnd() * n) | 0]; var best = null;
              for (k = 0; k < 8; k++) { b = nodes[(rnd() * n) | 0]; dx = a.x - b.x; dy = a.y - b.y; if (b !== a && dx * dx + dy * dy < L2) { best = b; break; } }
              if (best) pk.push({ a: a, b: best, t: 0, sp: .5 + rnd() * .7 });
            }
            for (k = pk.length - 1; k >= 0; k--) {
              var p = pk[k]; p.t += p.sp * dt; if (p.t >= 1) { pk.splice(k, 1); continue; }
              var x = p.a.x + (p.b.x - p.a.x) * p.t, y = p.a.y + (p.b.y - p.a.y) * p.t;
              ctx.globalAlpha = 1; ctx.drawImage(sB, x - 9, y - 9, 18, 18);
              var t2 = Math.max(0, p.t - .08); ctx.globalAlpha = .5; ctx.drawImage(sB, p.a.x + (p.b.x - p.a.x) * t2 - 6, p.a.y + (p.b.y - p.a.y) * t2 - 6, 12, 12);
            }
            for (k = rings.length - 1; k >= 0; k--) {
              var r = rings[k]; r.r += 300 * dt; if (r.r > 300) { rings.splice(k, 1); continue; }
              ctx.globalAlpha = (1 - r.r / 300) * .8; ctx.lineWidth = 2; ctx.strokeStyle = 'rgba(' + B + ',1)';
              ctx.beginPath(); ctx.arc(r.x, r.y, r.r, 0, 6.283); ctx.stroke();
              ctx.globalAlpha *= .5; ctx.beginPath(); ctx.arc(r.x, r.y, r.r * .6, 0, 6.283); ctx.stroke();
            }
            ctx.lineWidth = 1; aura(sB, now, .14, 220);
          },
          burst: function (x, y) { rings.push({ x: x, y: y, r: 0 }); }
        };
      },

      /* prime: slow gold dust, wine & gold bokeh, a rare light sweep, soft golden aura, sparkles on click */
      prime: function () {
        var A = rgb('--accent-rgb', '212,175,106'), B = rgb('--halo-rgb', '150,50,70'), C = '246,230,186';
        var sA = sprite(A, 48), sC = sprite(C, 48), sW = sprite(B, 128), sG = sprite(A, 128);
        var n = mobile ? 46 : 96, dust = [], bok = [], sp = [], i, trail = { x: -99, y: -99 };
        var ribs = [
          { y: .22, a: 46, f: .0042, s: .35, ph: 0, th: 70, c1: A, c2: B, al: .085, edge: .22 },
          { y: .48, a: 62, f: .0031, s: .27, ph: 2.1, th: 96, c1: B, c2: A, al: .07, edge: .16 },
          { y: .74, a: 54, f: .0038, s: .31, ph: 4.2, th: 80, c1: A, c2: C, al: .075, edge: .2 }
        ];
        if (mobile) ribs.pop();
        for (i = 0; i < n; i++) dust.push({ x: rnd() * W, y: rnd() * H, z: .3 + rnd() * .7, r: .7 + rnd() * 1.9, vy: -(4 + rnd() * 12), ph: rnd() * 6.28, tw: 1 + rnd() * 2.5 });
        for (i = 0; i < (mobile ? 4 : 7); i++) bok.push({ x: rnd() * W, y: rnd() * H, r: 70 + rnd() * 130, vx: (rnd() - .5) * 8, vy: -(2 + rnd() * 6), wine: i % 3 === 0, a: .05 + rnd() * .05 });
        return {
          frame: function (dt, t, now) {
            ctx.globalCompositeOperation = 'lighter';
            var on = pOn(now), k, p, s;
            // flowing gold & wine silk ribbons that bend toward the pointer
            var step = mobile ? 28 : 16, R = 0, x, yy, bump;
            for (R = 0; R < ribs.length; R++) {
              var rb = ribs[R], base = H * rb.y, th = rb.th, i2, ys = [];
              ctx.beginPath();
              for (x = -step, i2 = 0; x <= W + step; x += step, i2++) {
                yy = base + Math.sin(x * rb.f + t * rb.s + rb.ph) * rb.a + Math.sin(x * rb.f * 2.3 - t * rb.s * .7) * rb.a * .35;
                if (on) { bump = Math.exp(-Math.pow(x - P.x, 2) / 28800); yy += (P.y - yy) * .28 * bump; }
                ys.push(yy); if (i2) ctx.lineTo(x, yy); else ctx.moveTo(x, yy);
              }
              for (x = W + step, i2 = ys.length - 1; i2 >= 0; i2--, x -= step) ctx.lineTo(x, ys[i2] + th * (.7 + .3 * Math.sin(x * .004 + t * .3 + rb.ph)));
              ctx.closePath();
              var rg = ctx.createLinearGradient(0, 0, W, 0);
              rg.addColorStop(0, 'rgba(' + rb.c1 + ',0)'); rg.addColorStop(.35, 'rgba(' + rb.c1 + ',' + rb.al + ')'); rg.addColorStop(.7, 'rgba(' + rb.c2 + ',' + rb.al + ')'); rg.addColorStop(1, 'rgba(' + rb.c2 + ',0)');
              ctx.globalAlpha = 1; ctx.fillStyle = rg; ctx.fill();
              ctx.beginPath();
              for (x = -step, i2 = 0; x <= W + step; x += step, i2++) { if (i2) ctx.lineTo(x, ys[i2]); else ctx.moveTo(x, ys[i2]); }
              ctx.strokeStyle = 'rgba(' + C + ',' + rb.edge + ')'; ctx.lineWidth = 1; ctx.stroke();
            }
            // golden trail behind the pointer
            if (on && Math.hypot(P.tx - trail.x, P.ty - trail.y) > 18) {
              trail.x = P.tx; trail.y = P.ty;
              sp.push({ x: P.tx + (rnd() - .5) * 10, y: P.ty + (rnd() - .5) * 10, vx: (rnd() - .5) * 30, vy: (rnd() - .5) * 30 + 14, life: .7 + rnd() * .5, max: 1.2 });
              if (sp.length > 70) sp.shift();
            }
            for (k = 0; k < bok.length; k++) {
              p = bok[k]; p.x += p.vx * dt; p.y += p.vy * dt;
              if (p.y < -p.r) { p.y = H + p.r; p.x = rnd() * W; } if (p.x < -p.r) p.x = W + p.r; else if (p.x > W + p.r) p.x = -p.r;
              ctx.globalAlpha = p.a * (.75 + .25 * Math.sin(t * .4 + k)); ctx.drawImage(p.wine ? sW : sG, p.x - p.r, p.y - p.r, p.r * 2, p.r * 2);
            }
            // light sweep every ~18s
            var cyc = (t % 18) / 18;
            if (cyc < .3) {
              var pr = cyc / .3, x0 = -250 + (W + 500) * pr;
              ctx.save(); ctx.translate(x0, H / 2); ctx.rotate(.38);
              var g = ctx.createLinearGradient(-150, 0, 150, 0);
              g.addColorStop(0, 'rgba(' + C + ',0)'); g.addColorStop(.5, 'rgba(' + C + ',.075)'); g.addColorStop(1, 'rgba(' + C + ',0)');
              ctx.globalAlpha = Math.sin(pr * Math.PI); ctx.fillStyle = g; ctx.fillRect(-150, -H, 300, H * 2); ctx.restore();
            }
            for (k = 0; k < dust.length; k++) {
              p = dust[k]; p.y += p.vy * p.z * dt; p.x += Math.sin(t * .35 + p.ph) * 6 * dt;
              if (on) { var dx = p.x - P.x, dy = p.y - P.y, d2 = dx * dx + dy * dy; if (d2 < 14400 && d2 > 1) { var d = Math.sqrt(d2), f = (1 - d / 120) * 70 * dt; p.x += dx / d * f; p.y += dy / d * f; } }
              if (p.y < -10) { p.y = H + 10; p.x = rnd() * W; }
              var tw = .35 + .65 * Math.max(0, Math.sin(t * p.tw + p.ph));
              ctx.globalAlpha = tw * (.35 + .5 * p.z); s = p.r * 7 * p.z + 3;
              ctx.drawImage(p.r > 1.9 ? sC : sA, p.x - s / 2, p.y - s / 2, s, s);
            }
            for (k = sp.length - 1; k >= 0; k--) {
              p = sp[k]; p.life -= dt; if (p.life <= 0) { sp.splice(k, 1); continue; }
              p.vy += 30 * dt; p.x += p.vx * dt; p.y += p.vy * dt; var f2 = p.life / p.max;
              ctx.globalAlpha = f2; s = 18 * f2 + 4; ctx.drawImage(sC, p.x - s / 2, p.y - s / 2, s, s);
              ctx.globalAlpha = f2 * .8; ctx.fillStyle = 'rgba(' + C + ',1)'; ctx.fillRect(p.x - s * .7, p.y - .5, s * 1.4, 1); ctx.fillRect(p.x - .5, p.y - s * .7, 1, s * 1.4);
            }
            aura(sG, now, .22, 300);
          },
          burst: function (x, y) {
            for (var i = 0; i < 14; i++) { var a = rnd() * 6.28, v = 30 + rnd() * 120; sp.push({ x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 30, life: .8 + rnd() * .9, max: 1.7 }); }
          }
        };
      }
    };

    /* ---------- loop ---------- */
    var scene = null, key = null, last = 0, run = false, acc = 0;
    function loop(now) {
      if (!run) return;
      requestAnimationFrame(loop);
      var dt = (now - last) / 1000; last = now; if (dt > .1) dt = .1;
      if (mobile) { acc += dt; if (acc < .032) return; dt = acc; acc = 0; }
      var k = Math.min(1, dt * 12); P.x += (P.tx - P.x) * k; P.y += (P.ty - P.y) * k;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      ctx.globalCompositeOperation = 'source-over'; ctx.globalAlpha = 1;
      ctx.clearRect(0, 0, W, H);
      scene.frame(dt, now / 1000, now);
      ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    }
    function setScene(k) {
      if (k === key) return; key = k;
      run = false; scene = null; ctx.clearRect(0, 0, W, H);
      if (scenes[k]) { scene = scenes[k](); run = true; last = performance.now(); acc = 0; requestAnimationFrame(loop); }
    }
    document.addEventListener('visibilitychange', function () {
      if (document.hidden) run = false; else if (scene && !run) { run = true; last = performance.now(); requestAnimationFrame(loop); }
    });
    document.addEventListener('cdx-skin', function () { key = null; setScene(CDX_SKIN.get()); });
    setScene(CDX_SKIN.get());

    /* ---------- 3D tilt on cards (mouse only) ---------- */
    if (fine) {
      var TILT = '.tool,.cat-tile,.stat,.res';
      document.addEventListener('pointermove', function (e) {
        var t = e.target.closest && e.target.closest(TILT); if (!t) return;
        var r = t.getBoundingClientRect(), x = (e.clientX - r.left) / r.width - .5, y = (e.clientY - r.top) / r.height - .5;
        t.style.setProperty('--ry', (x * 9).toFixed(2) + 'deg'); t.style.setProperty('--rx', (-y * 7).toFixed(2) + 'deg');
      }, { passive: true });
      document.addEventListener('pointerout', function (e) {
        var t = e.target.closest && e.target.closest(TILT); if (!t || t.contains(e.relatedTarget)) return;
        t.style.setProperty('--ry', '0deg'); t.style.setProperty('--rx', '0deg');
      });
    }
  }
})();
