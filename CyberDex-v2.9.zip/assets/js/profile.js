/* CyberDex public profile: optional, opt-in page (?u=handle) + owner manager. The server computes points; email is never shown. */
(function () {
  'use strict';
  var root = document.getElementById('profApp'); if (!root) return;
  var LV = ['مستكشف', 'متدرّب', 'ممارس', 'محترف', 'خبير', 'أسطورة CyberDex'];
  var MSG = { auth: 'سجّل الدخول أولًا.', banned: 'لا يمكن لهذا الحساب إنشاء ملف عام.', blocked: 'تم إيقاف الملف العام لهذا الحساب.', invalid: 'الاسم من 3 إلى 20 حرفًا: إنجليزي صغير وأرقام و _ فقط.', reserved: 'هذا الاسم محجوز، اختر اسمًا آخر.', taken: 'هذا الاسم مستخدم، اختر اسمًا آخر.' };
  function el(tag, attrs, kids) { var n = document.createElement(tag); for (var k in (attrs || {})) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); } (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); }); return n; }
  function sb(cb, n) { if (window.CDX_SB) return cb(window.CDX_SB); if ((n || 0) > 40) return cb(null); setTimeout(function () { sb(cb, (n || 0) + 1); }, 150); }
  function sess(cb, n) { if (window.CDX_SESSION !== undefined || (n || 0) > 25) return cb(window.CDX_SESSION); setTimeout(function () { sess(cb, (n || 0) + 1); }, 150); }
  function fmtD(d) { try { return new Date(d).toLocaleDateString('ar-EG', { dateStyle: 'medium' }); } catch (e) { return ''; } }
  var handle = (new URLSearchParams(location.search).get('u') || '').toLowerCase().replace(/[^a-z0-9_]/g, '').slice(0, 20);
  function link(h) { return location.origin + location.pathname + '?u=' + h; }
  function note(t) { root.textContent = ''; root.appendChild(el('p', { class: 'cdx-sub', text: t })); }

  // ------------ public view
  function badgeNames() { var m = {}; try { (window.CDX_ACH && window.CDX_ACH.badges() || []).forEach(function (b) { m[b.id] = b; }); } catch (e) {} return m; }
  function ach(cb, n) { if (window.CDX_ACH || (n || 0) > 20) return cb(); setTimeout(function () { ach(cb, (n || 0) + 1); }, 100); }
  function view() {
    note('جارٍ التحميل…');
    sb(function (s) {
      if (!s) return note('تعذّر الاتصال الآن.');
      s.rpc('get_public_profile', { p_handle: handle }).then(function (r) {
        ach(function () { render(r); });
      });
    });
  }
  function render(r) {
        var d = r.data; root.textContent = '';
        if (r.error || !d) { root.appendChild(el('div', { class: 'panel' }, [el('h2', { text: 'لا يوجد ملف بهذا الاسم' }), el('p', { class: 'cdx-sub', text: 'قد يكون الاسم غير صحيح أو أن صاحبه حذف ملفه.' }), el('a', { class: 'btn', href: 'profile.html', text: 'ملفي العام' })])); return; }
        var names = badgeNames();
        var card = el('div', { class: 'panel prof-card' }, [
          el('div', { class: 'prof-h' }, [el('div', { class: 'prof-av', text: d.handle.charAt(0).toUpperCase() }), el('div', {}, [el('h2', { text: '@' + d.handle, dir: 'ltr' }), el('div', { class: 'cdx-sub', text: LV[d.level] + ' • انضم ' + d.joined })])]),
          el('div', { class: 'prof-stats' }, [st('النقاط', d.points), st('أدوات تعلّمها', d.learned), st('مهام المختبر', d.sims), st('أقسام بشهادة', d.certs)])]);
        if (d.badges) {
          var bw = el('div', { class: 'prof-badges' }); var shown = 0;
          d.badges.forEach(function (id) { var b = names[id]; if (b) { shown++; bw.appendChild(el('span', { class: 'prof-badge r-' + b.rar, title: b.desc, text: b.name })); } });
          card.appendChild(el('h3', { text: 'الشارات (' + shown + ')' })); card.appendChild(shown ? bw : el('p', { class: 'cdx-sub', text: 'لا شارات بعد.' }));
        }
        if (d.certificates) {
          card.appendChild(el('h3', { text: 'الشهادات التعليمية (' + d.certificates.length + ')' }));
          if (!d.certificates.length) card.appendChild(el('p', { class: 'cdx-sub', text: 'لا شهادات بعد.' }));
          d.certificates.forEach(function (c) { card.appendChild(el('div', { class: 'prof-cert' }, [el('span', { text: c.category + ' • ' + c.score + '%' }), el('span', { class: 'cdx-sub', text: fmtD(c.issued_at) }), el('a', { href: 'verify.html?code=' + encodeURIComponent(c.code), text: 'تحقّق' })])); });
          card.appendChild(el('p', { class: 'cdx-sub', text: 'الشهادات تعليمية وليست اعتمادًا رسميًا.' }));
        }
        var share = el('button', { class: 'btn sm', type: 'button', text: 'نسخ الرابط' });
        share.onclick = function () { var u = link(d.handle); if (navigator.clipboard) navigator.clipboard.writeText(u).then(function () { share.textContent = 'تم النسخ ✓'; }, function () { prompt('انسخ الرابط', u); }); else prompt('انسخ الرابط', u); };
        card.appendChild(el('div', { class: 'adm-row' }, [share, el('a', { class: 'btn sm', href: 'profile.html', text: 'ملفي أنا' })]));
        root.appendChild(card); document.title = '@' + d.handle + ' | CyberDex';
  }
  function st(l, v) { return el('div', { class: 'prof-st' }, [el('b', { text: String(v) }), el('span', { text: l })]); }

  // ------------ owner manager
  var lastSes = null;
  function manage() {
    note('جارٍ التحميل…');
    sb(function (s) {
      if (!s) return note('تعذّر الاتصال الآن.');
      sess(function (ses) {
        root.textContent = ''; lastSes = !!ses;
        if (!ses) { root.appendChild(el('div', { class: 'panel' }, [el('h2', { text: 'ملفك العام' }), el('p', { class: 'cdx-sub', text: 'سجّل الدخول من زر "دخول" بالأعلى لإنشاء ملفك العام ومشاركته. الملف اختياري ولا يظهر بريدك أبدًا.' })])); return; }
        s.rpc('my_public_profile').then(function (r) {
          var cur = r.data, f = el('form', { class: 'panel plan-form' });
          var h = el('input', { type: 'text', maxlength: '20', placeholder: 'مثال: sara_dev', dir: 'ltr', autocomplete: 'off', value: cur ? cur.handle : '', 'aria-label': 'اسم الملف' });
          var cb = el('input', { type: 'checkbox' }), cc = el('input', { type: 'checkbox' }); cb.checked = cur ? cur.show_badges : true; cc.checked = cur ? cur.show_certs : false;
          var out = el('p', { class: 'cdx-note', text: '' });
          f.appendChild(el('h2', { text: cur ? 'ملفك العام' : 'أنشئ ملفك العام' }));
          f.appendChild(el('p', { class: 'cdx-sub', text: 'صفحة برابط تعرض نقاطك ومستواك وعدد ما تعلّمته، ويمكنك إضافة الشارات والشهادات. لا يظهر بريدك، ويمكنك حذف الملف في أي وقت.' }));
          f.appendChild(el('label', { class: 'adm-col' }, [el('span', { text: 'اسم الملف (إنجليزي صغير وأرقام و _)' }), h]));
          f.appendChild(el('label', { class: 'cdx-chk' }, [cb, el('span', { text: 'اعرض الشارات' })]));
          f.appendChild(el('label', { class: 'cdx-chk' }, [cc, el('span', { text: 'اعرض شهاداتي. تنبيه: كل شهادة لها رابط تحقّق يُظهر الاسم المكتوب عليها لمن يضغطه.' })]));
          f.appendChild(el('button', { class: 'btn primary', type: 'submit', text: cur ? 'حفظ التعديلات' : 'إنشاء الملف' })); f.appendChild(out);
          f.onsubmit = function (e) {
            e.preventDefault(); out.textContent = 'جارٍ الحفظ…';
            Promise.resolve().then(function () { return window.CDXP && window.CDXP.push ? window.CDXP.push() : null; }).catch(function () {}).then(function () { return s.rpc('set_public_profile', { p_handle: h.value, p_show_certs: cc.checked, p_show_badges: cb.checked }); }).then(function (x) {
              if (x.error) { out.textContent = 'تعذّر الحفظ، حاول لاحقًا.'; return; }
              if (x.data !== 'ok') { out.textContent = MSG[x.data] || 'تعذّر الحفظ.'; return; }
              manage();
            });
          };
          root.appendChild(f);
          if (cur) {
            var u = link(cur.handle), copy = el('button', { class: 'btn sm', type: 'button', text: 'نسخ الرابط' }), del = el('button', { class: 'btn sm adm-danger', type: 'button', text: 'حذف ملفي العام' });
            copy.onclick = function () { if (navigator.clipboard) navigator.clipboard.writeText(u).then(function () { copy.textContent = 'تم النسخ ✓'; }); };
            del.onclick = function () { if (confirm('حذف ملفك العام؟ سيتوقف الرابط عن العمل فورًا.')) s.rpc('delete_public_profile').then(function () { manage(); }); };
            root.appendChild(el('div', { class: 'panel' }, [el('h3', { text: 'رابطك' }), el('p', { dir: 'ltr', class: 'prof-url', text: u }), el('div', { class: 'adm-row' }, [copy, el('a', { class: 'btn sm', href: 'profile.html?u=' + cur.handle, text: 'معاينة' }), del])]));
          }
        });
      });
    });
  }
  document.addEventListener('cdx-auth', function () { if (!handle && lastSes !== null && lastSes !== !!window.CDX_SESSION) manage(); });
  if (handle) view(); else manage();
})();
