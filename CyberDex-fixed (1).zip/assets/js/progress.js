// CyberDex learning progress: stored locally; synced to the account (table "progress") when signed in.
(function () {
  var KEY = 'cdx-prog', S = { learned: {}, quiz: {}, sims: {}, days: [], daily: {}, badges: {}, exams: {}, certs: {} }, session = null, timer = null;
  var LEVELS = [[0, 'مستكشف'], [50, 'متدرّب'], [150, 'ممارس'], [300, 'محترف'], [600, 'خبير'], [1000, 'أسطورة CyberDex']];
  function today() { var d = new Date(); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function load() { try { var j = JSON.parse(localStorage.getItem(KEY) || 'null'); if (j && typeof j === 'object') { S.learned = j.learned || {}; S.quiz = j.quiz || {}; S.sims = j.sims || {}; S.days = j.days || []; S.daily = j.daily || {}; S.badges = j.badges || {}; S.exams = j.exams || {}; S.certs = j.certs || {}; } } catch (e) {} }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {} schedule(); }
  function touch() { var t = today(); if (S.days.indexOf(t) < 0) S.days.push(t); if (S.days.length > 400) S.days = S.days.slice(-400); }
  function merge(a, b) {
    var o = { learned: {}, quiz: {}, sims: {}, days: [], daily: {}, badges: {}, exams: {}, certs: {} };
    [a.exams || {}, b.exams || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { var c = o.exams[k], v = m[k]; if (!c) o.exams[k] = v; else o.exams[k] = { best: Math.max(c.best || 0, v.best || 0), tries: Math.max(c.tries || 0, v.tries || 0), passed: c.passed || v.passed || 0 }; }); });
    [a.certs || {}, b.certs || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { var c = o.certs[k], v = m[k]; o.certs[k] = c ? (c.v ? c : (v.v ? v : c)) : v; }); });
    [a.daily || {}, b.daily || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { o.daily[k] = 1; }); });
    [a.badges || {}, b.badges || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { o.badges[k] = o.badges[k] ? Math.min(o.badges[k], m[k]) : m[k]; }); });
    [a.learned || {}, b.learned || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { o.learned[k] = o.learned[k] ? Math.min(o.learned[k], m[k]) : m[k]; }); });
    [a.quiz || {}, b.quiz || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { var c = o.quiz[k], v = m[k]; if (!c || v.right > c.right) o.quiz[k] = v; }); });
    [a.sims || {}, b.sims || {}].forEach(function (m) { Object.keys(m).forEach(function (k) { o.sims[k] = 1; }); });
    var d = {}; (a.days || []).concat(b.days || []).forEach(function (x) { d[x] = 1; }); o.days = Object.keys(d).sort().slice(-400);
    return o;
  }
  function pull() {
    var sb = window.CDX_SB; if (!sb || !session) return;
    sb.from('progress').select('data').eq('user_id', session.user.id).maybeSingle().then(function (r) {
      if (r.error) return;
      var m = merge(S, (r.data && r.data.data) || {}); S = m; try { localStorage.setItem(KEY, JSON.stringify(S)); } catch (e) {}
      push(); paint(); document.dispatchEvent(new CustomEvent('cdx-progress'));
    });
  }
  function push() { var sb = window.CDX_SB; if (!sb || !session) return Promise.resolve(); return sb.from('progress').upsert({ user_id: session.user.id, data: S, updated_at: new Date().toISOString() }); }
  function schedule() { if (!session) return; clearTimeout(timer); timer = setTimeout(push, 1500); }
  function stats() {
    var learned = Object.keys(S.learned).length, aces = 0, sims = Object.keys(S.sims).length;
    Object.keys(S.quiz).forEach(function (k) { if (S.quiz[k].right === S.quiz[k].total && S.quiz[k].total > 0) aces++; });
    var dailyN = Object.keys(S.daily).length, pts = learned * 10 + aces * 5 + sims * 5 + dailyN * 15 + Object.keys(S.certs).length * 50, li = 0;
    LEVELS.forEach(function (l, i) { if (pts >= l[0]) li = i; });
    var next = LEVELS[li + 1] || null;
    var ds = S.days.slice().sort(), streak = 0, cur = new Date();
    var set = {}; ds.forEach(function (x) { set[x] = 1; });
    function fmt(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
    if (!set[fmt(cur)]) cur.setDate(cur.getDate() - 1);
    while (set[fmt(cur)]) { streak++; cur.setDate(cur.getDate() - 1); }
    return { certs: Object.keys(S.certs).length, examsPassed: Object.keys(S.exams).filter(function (k) { return S.exams[k].passed; }).length, daily: dailyN, badges: Object.keys(S.badges).length, learned: learned, aces: aces, sims: sims, points: pts, level: LEVELS[li][1], levelIndex: li, levelMin: LEVELS[li][0], nextMin: next ? next[0] : null, nextName: next ? next[1] : null, streak: streak, days: ds.length };
  }
  function paint() {
    [].forEach.call(document.querySelectorAll('[data-learn]'), function (b) { var on = !!S.learned[b.getAttribute('data-learn')]; b.classList.toggle('on', on); b.textContent = on ? '✓ تعلّمتها' : '☐ علّمها كمتعلَّمة'; b.setAttribute('aria-pressed', on); });
    [].forEach.call(document.querySelectorAll('.tool[data-id]'), function (c) { c.classList.toggle('learned', !!S.learned[c.getAttribute('data-id')]); });
  }
  window.CDXP = { state: function () { return S; }, stats: stats, levels: LEVELS,
    toggleLearned: function (id) { if (S.learned[id]) delete S.learned[id]; else { S.learned[id] = Date.now(); touch(); } save(); paint(); },
    quiz: function (id, right, total) { S.quiz[id] = { right: right, total: total }; touch(); save(); },
    sim: function (id) { S.sims[id] = 1; touch(); save(); },
    markDaily: function (d) { if (S.daily[d]) return false; S.daily[d] = 1; touch(); save(); return true; },
    award: function (id) { if (S.badges[id]) return false; S.badges[id] = Date.now(); save(); return true; },
    examResult: function (cat, pct, passed) { var e = S.exams[cat] || { best: 0, tries: 0, passed: 0 }; e.tries++; e.best = Math.max(e.best, pct); if (passed && !e.passed) e.passed = Date.now(); S.exams[cat] = e; touch(); save(); },
    addCert: function (code, c) { S.certs[code] = c; save(); },
    markCert: function (code) { if (S.certs[code]) { S.certs[code].v = 1; save(); } },
    push: push,
    save: save,
    reset: function () { S = { learned: {}, quiz: {}, sims: {}, days: [], daily: {}, badges: {}, exams: {}, certs: {} }; save(); paint(); } };
  load(); paint();
  document.addEventListener('click', function (e) { var b = e.target.closest('[data-learn]'); if (b) { window.CDXP.toggleLearned(b.getAttribute('data-learn')); document.dispatchEvent(new CustomEvent('cdx-progress')); } });
  document.addEventListener('cdx-sim-done', function (e) { window.CDXP.sim(e.detail.tool); document.dispatchEvent(new CustomEvent('cdx-progress')); });
  // per-tool quiz: record the score once every question has an answer
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.mq-opts button')) return;
    setTimeout(function () {
      var art = document.querySelector('[data-tool]'); if (!art) return;
      var qs = document.querySelectorAll('.mq'), done = 0, right = 0;
      [].forEach.call(qs, function (q) { if (q.dataset.done) { done++; if (!q.querySelector('.mq-opts .bad')) right++; } });
      if (qs.length && done === qs.length) { window.CDXP.quiz(art.getAttribute('data-tool'), right, qs.length); document.dispatchEvent(new CustomEvent('cdx-progress')); }
    }, 30);
  });
  document.addEventListener('cdx-auth', function (e) { session = e.detail; if (session) pull(); });
  if (window.CDX_SESSION) { session = window.CDX_SESSION; pull(); }
})();
