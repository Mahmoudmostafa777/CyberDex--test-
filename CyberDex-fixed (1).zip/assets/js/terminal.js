// CyberDex practice terminal: a pure simulator. It NEVER runs anything; it only replays the sample output written in the guide.
(function () {
  var root = document.getElementById('simTerm'); if (!root) return;
  var data; try { data = JSON.parse(document.getElementById('simData').textContent); } catch (e) { return; }
  var log = root.querySelector('.sim-log'), form = root.querySelector('form'), input = root.querySelector('input');
  var chipsBox = root.querySelector('.sim-chips'), meter = root.querySelector('.sim-meter'), hintBtn = root.querySelector('[data-hint]');
  function norm(s) { return String(s).replace(/\s+/g, ' ').trim(); }
  var cmds = {}, order = [];
  data.steps.forEach(function (st, si) {
    var lines = st.cmd.split('\n').filter(function (l) { return l.trim(); });
    lines.forEach(function (l, i) {
      var k = norm(l); if (!cmds[k]) { cmds[k] = { out: i === lines.length - 1 ? st.out : null, note: i === lines.length - 1 ? st.note : null, step: si, done: false }; order.push(k); }
    });
  });
  var total = order.length, done = 0, finished = false;
  function line(cls, text) { var d = document.createElement('div'); d.className = cls; d.textContent = text; log.appendChild(d); log.scrollTop = log.scrollHeight; return d; }
  function updateMeter() { meter.textContent = done + ' / ' + total + ' أوامر'; }
  function nextCmd() { for (var i = 0; i < order.length; i++) if (!cmds[order[i]].done) return order[i]; return null; }
  function renderChips() {
    chipsBox.innerHTML = '';
    order.forEach(function (k) {
      var b = document.createElement('button'); b.type = 'button'; b.className = 'sim-chip' + (cmds[k].done ? ' done' : ''); b.textContent = k; b.title = 'اضغط لتعبئة الأمر';
      b.onclick = function () { input.value = k; input.focus(); }; chipsBox.appendChild(b);
    });
  }
  function run(raw) {
    var c = norm(raw); if (!c) return;
    var p = document.createElement('div'); p.className = 'sim-l'; p.innerHTML = '<i>cyberdex@lab:~$</i> '; p.appendChild(document.createTextNode(c)); log.appendChild(p);
    if (c === 'clear') { log.innerHTML = ''; return; }
    if (c === 'help') { line('sim-n', 'هذه محاكاة آمنة: لا يُنفَّذ أي أمر حقيقي. اكتب أمرًا من القائمة أسفل الشاشة، أو اكتب hint لتعرف الأمر التالي، أو clear لمسح الشاشة.'); return; }
    if (c === 'hint') { var n = nextCmd(); line('sim-n', n ? 'جرّب: ' + n : 'أنهيت كل الأوامر. أحسنت!'); return; }
    var e = cmds[c];
    if (!e) { line('sim-e', 'المحاكي لا يعرف هذا الأمر. هو يدعم أوامر هذا الدرس فقط (اكتب hint للمساعدة).'); return; }
    if (e.out) line('sim-o', e.out); else if (e.note) line('sim-n', '# ' + e.note);
    if (!e.done) { e.done = true; done++; renderChips(); updateMeter();
      if (done === total && !finished) { finished = true; line('sim-ok', '✔ أنهيت كل أوامر هذا الدرس. نفّذها الآن بنفسك في مختبرك.');
        try { document.dispatchEvent(new CustomEvent('cdx-sim-done', { detail: { tool: data.tool } })); } catch (x) {} }
    }
  }
  form.addEventListener('submit', function (ev) { ev.preventDefault(); run(input.value); input.value = ''; });
  if (hintBtn) hintBtn.onclick = function () { run('hint'); };
  line('sim-n', 'محاكاة تعليمية: اكتب الأوامر كما في الشرح وشاهد مثال المخرج. لا يُنفَّذ شيء على جهازك.');
  renderChips(); updateMeter();
})();
