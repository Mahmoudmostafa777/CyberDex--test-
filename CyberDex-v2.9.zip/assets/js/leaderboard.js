// Leaderboard: opt-in, nickname only. Points are computed on the server from the saved progress.
(function () {
  var app = document.getElementById('lbApp'); if (!app) return;
  var LV = ['مستكشف', 'متدرّب', 'ممارس', 'محترف', 'خبير', 'أسطورة CyberDex'];
  var period = 'all', rows = [], mine = null, joined = false;
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} return null; }
  var MSG = { taken: 'هذا الاسم مستخدم، اختر اسمًا آخر.', invalid: 'الاسم من 3 إلى 20 حرفًا: عربي أو إنجليزي أو أرقام أو _ (ومسافة واحدة بين الكلمات).', reserved: 'هذا الاسم محجوز، اختر اسمًا آخر.', banned: 'لا يمكن لهذا الحساب الانضمام.', blocked: 'تم إيقاف انضمام هذا الحساب إلى اللوحة.', off: 'اللوحة متوقفة مؤقتًا.', auth: 'سجّل الدخول أولًا.' };
  var NAMES = { all: 'كل الأوقات', month: 'هذا الشهر', week: 'هذا الأسبوع' };

  function sb(cb, n) { if (window.CDX_SB) return cb(window.CDX_SB); if ((n || 0) > 40) return cb(null); setTimeout(function () { sb(cb, (n || 0) + 1); }, 150); }

  function load() {
    sb(function (s) {
      if (!s) { app.innerHTML = '<p class="ex-rule">اللوحة غير متاحة الآن. تحقق من الاتصال وأعد المحاولة.</p>'; return; }
      var ses = window.CDX_SESSION;
      var p1 = s.rpc('get_leaderboard', { p_period: period, p_limit: 50 });
      var p2 = ses ? s.rpc('my_leaderboard_row', { p_period: period }) : Promise.resolve({ data: [] });
      Promise.all([p1, p2]).then(function (r) {
        if (r[0].error) { app.innerHTML = '<p class="ex-rule">تعذّر تحميل اللوحة الآن. حاول لاحقًا.</p>'; return; }
        rows = r[0].data || []; mine = (r[1].data && r[1].data[0]) || null; joined = !!mine; ls('cdx-lb', joined ? '1' : null);
        draw();
      });
    });
  }

  function medal(i) { return i === 1 ? '🥇' : i === 2 ? '🥈' : i === 3 ? '🥉' : i; }

  function draw() {
    var ses = window.CDX_SESSION, h = '';
    h += '<div class="lb-tabs" role="tablist">' + ['all', 'month', 'week'].map(function (k) { return '<button type="button" role="tab" aria-selected="' + (k === period) + '" data-p="' + k + '">' + NAMES[k] + '</button>'; }).join('') + '</div>';
    // join / status box
    if (!ses) h += '<div class="lb-box"><b>انضم إلى اللوحة</b><p>سجّل الدخول من أعلى الصفحة لتنضم باسم مستعار وتظهر نقاطك. الانضمام اختياري ويمكنك الخروج في أي وقت.</p></div>';
    else if (!joined) h += '<form class="lb-box" id="lbJoin"><b>انضم إلى اللوحة</b><p>سيظهر للجميع اسمك المستعار ونقاطك ومستواك فقط. لا يظهر بريدك ولا اسمك الحقيقي.</p><div class="lb-row"><input id="lbNick" maxlength="20" required placeholder="اسم مستعار (3 إلى 20 حرفًا)"><button class="btn primary" type="submit">انضم</button></div><small class="lb-err" id="lbErr" role="alert"></small></form>';
    else h += '<div class="lb-box me"><b>أنت في اللوحة باسم «' + esc(mine.nick) + '»</b><p>' + (mine.rank ? 'ترتيبك في «' + NAMES[period] + '»: <b>#' + mine.rank + '</b> · ' + mine.points + ' نقطة' : 'لا نقاط لك في «' + NAMES[period] + '» بعد. تعلّم أداة لتظهر.') + '</p><div class="lb-row"><button class="btn sm" id="lbRefresh" type="button">حدّث نقاطي الآن</button><button class="btn sm" id="lbLeave" type="button">غادر اللوحة</button></div></div>';
    if (!rows.length) h += '<p class="ex-rule">لا أحد في هذه القائمة بعد. كن الأول!</p>';
    else h += '<div class="lb-list">' + rows.map(function (r) { return '<div class="lb-r' + (r.me ? ' me' : '') + (r.rank <= 3 ? ' top' : '') + '"><span class="lb-k">' + medal(+r.rank) + '</span><span class="lb-n"><b>' + esc(r.nick) + '</b><small>' + LV[r.level] + (r.certs ? ' · ' + r.certs + ' شهادة' : '') + '</small></span><span class="lb-p">' + r.points + '<small>نقطة</small></span></div>'; }).join('') + '</div>';
    h += '<p class="lb-note">النقاط تُحسب من تقدّمك المحفوظ في حسابك: الأدوات المتعلَّمة والاختبارات والمحاكاة والتحدّي اليومي والشهادات. اللوحة مجتمعية للتحفيز والمتعة. أي اسم غير لائق يُحذف.</p>';
    app.innerHTML = h;
  }

  app.addEventListener('click', function (e) {
    var t = e.target.closest('[data-p]'); if (t) { period = t.getAttribute('data-p'); load(); return; }
    if (e.target.closest('#lbRefresh')) { var b = e.target; b.disabled = true; window.CDXP.push().then(function () { return window.CDX_SB.rpc('publish_score'); }).then(function () { b.disabled = false; load(); }); return; }
    if (e.target.closest('#lbLeave') && confirm('الخروج من اللوحة؟ سيُحذف اسمك ونقاطك من القائمة العامة.')) { window.CDX_SB.rpc('leave_leaderboard').then(function () { ls('cdx-lb', null); load(); }); }
  });
  app.addEventListener('submit', function (e) {
    if (e.target.id !== 'lbJoin') return; e.preventDefault();
    var n = document.getElementById('lbNick').value, err = document.getElementById('lbErr'), btn = e.target.querySelector('button'); btn.disabled = true; err.textContent = '';
    window.CDXP.push().then(function () { return window.CDX_SB.rpc('join_leaderboard', { p_nick: n }); }).then(function (r) {
      btn.disabled = false;
      if (r.error) { err.textContent = 'تعذّر الانضمام الآن. حاول لاحقًا.'; return; }
      if (r.data !== 'ok') { err.textContent = MSG[r.data] || 'تعذّر الانضمام.'; return; }
      ls('cdx-lb', '1'); load();
    });
  });
  document.addEventListener('cdx-auth', function () { setTimeout(load, 300); });
  function go() { if (!window.CDXP) return setTimeout(go, 100); load(); }
  if (document.readyState === 'complete') go(); else addEventListener('load', go);
})();
