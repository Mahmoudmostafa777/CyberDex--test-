/* CyberDex personal plan: 5 questions -> weekly plan built only from existing paths, lab missions and exams. Answers stay in this browser. */
(function () {
  'use strict';
  var root = document.getElementById('planApp'), D = window.CDX_PLAN; if (!root || !D) return;
  var KEY = 'cdx-plan';
  function el(tag, attrs, kids) { var n = document.createElement(tag); for (var k in (attrs || {})) { if (k === 'class') n.className = attrs[k]; else if (k === 'text') n.textContent = attrs[k]; else n.setAttribute(k, attrs[k]); } (kids || []).forEach(function (c) { if (c) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); }); return n; }
  function ls(v) { try { if (v === undefined) return JSON.parse(localStorage.getItem(KEY) || 'null'); if (v === null) localStorage.removeItem(KEY); else localStorage.setItem(KEY, JSON.stringify(v)); } catch (e) {} return null; }
  var Q = [
    ['level', 'مستواك الحالي', [['beginner', 'مبتدئ: أبدأ من الصفر'], ['mid', 'عندي أساس في لينكس والشبكات'], ['adv', 'متقدم: أريد التعمّق']]],
    ['interest', 'أكثر مجال يهمّك', [['linux', 'لينكس والطرفية'], ['net', 'أدوات الشبكة'], ['packets', 'تحليل الحزم والمراقبة'], ['web', 'أمان تطبيقات الويب'], ['defense', 'الدفاع وتقوية الأنظمة'], ['forensics', 'التحليل الجنائي الرقمي'], ['reverse', 'تحليل الملفات والهندسة العكسية'], ['auto', 'الأتمتة والسكربتات'], ['sysadmin', 'إدارة النظام والعمليات'], ['db', 'قواعد البيانات والنسخ الاحتياطي'], ['audit', 'التدقيق المصرّح داخل المختبر']]],
    ['hours', 'وقتك في الأسبوع', [['2', 'ساعتان تقريبًا'], ['5', 'حوالي 5 ساعات'], ['10', '10 ساعات أو أكثر']]],
    ['way', 'أسلوبك المفضّل', [['read', 'أقرأ أولًا ثم أطبّق'], ['practice', 'أطبّق أولًا ثم أقرأ']]],
    ['goal', 'هدفك', [['hobby', 'تعلّم للمتعة والفهم'], ['cert', 'شهادات الموقع التعليمية'], ['compete', 'النقاط ولوحة المتصدرين']]]
  ];
  var PM = { linux: ['linux-basics', 'automation'], net: ['net-admin', 'packets'], packets: ['packets', 'net-admin'], web: ['web', 'packets'], defense: ['defense', 'hardening'], forensics: ['forensics', 'reverse'], reverse: ['reverse', 'forensics'], auto: ['automation', 'sysadmin'], sysadmin: ['sysadmin', 'hardening'], db: ['databases', 'sysadmin'], audit: ['lab-audit', 'web'] };
  var TIP = { hobby: 'خُذ وقتك: افهم لماذا يعمل كل أمر قبل أن تنتقل.', cert: 'بعد أسبوعين من القراءة جرّب اختبار القسم المرتبط، فهو يفتح عند تعلّم نصف أدوات القسم.', compete: 'كل أداة تتعلّمها تمنحك 10 نقاط وكل مهمة مختبر 5، والتحدّي اليومي 15.' };

  function S() { return (window.CDXP && window.CDXP.state()) || { learned: {}, sims: {} }; }
  function build(a) {
    var P = D.paths, pm = PM[a.interest] || PM.linux, ids = [];
    if (a.level === 'beginner' && P[pm[0]].lv !== 'مبتدئ') ids.push('beginner');
    ids.push(pm[0]); if (a.level === 'adv' && pm[1]) ids.push(pm[1]);
    var used = {}, steps = [];
    ids.forEach(function (pid) {
      var p = P[pid]; p.s.forEach(function (s, i) {
        var lab = null; D.lab.some(function (m) { if (!used[m.n] && m.tools.some(function (t) { return s.tools.indexOf(t) >= 0; })) { lab = m; used[m.n] = 1; return true; } return false; });
        steps.push({ pid: pid, ptitle: p.t, t: s.t, d: s.d, tools: s.tools, lab: lab, exam: (i === p.s.length - 1 && p.exam) ? p.exam : '' });
      });
    });
    var per = { '2': 1, '5': 2, '10': 3 }[a.hours] || 2, weeks = [];
    for (var i = 0; i < steps.length; i += per) weeks.push(steps.slice(i, i + per));
    return { ids: ids, weeks: weeks, steps: steps, a: a };
  }
  function stepDone(s) { var L = S().learned; return s.tools.every(function (t) { return L[t]; }); }
  var openSet = null;

  function render() {
    var a = ls(); root.textContent = '';
    if (!a) return form();
    var pl = build(a), L = S().learned, all = {}, done = 0;
    pl.steps.forEach(function (s) { s.tools.forEach(function (t) { all[t] = 1; }); });
    var tot = Object.keys(all).length; Object.keys(all).forEach(function (t) { if (L[t]) done++; });
    var pct = tot ? Math.round(done / tot * 100) : 0, cur = -1;
    pl.weeks.forEach(function (w, i) { if (cur < 0 && !w.every(stepDone)) cur = i; });
    var hrs = { '2': 2, '5': 5, '10': 10 }[a.hours] || 2;
    var sum = el('div', { class: 'panel plan-sum' }, [
      el('h2', { text: 'خطتك: ' + pl.weeks.length + ' أسبوعًا' }),
      el('p', { class: 'cdx-sub', text: pl.ids.map(function (id) { return D.paths[id].t; }).join('  ←  ') }),
      el('div', { class: 'plan-bar', role: 'progressbar', 'aria-valuenow': String(pct), 'aria-valuemin': '0', 'aria-valuemax': '100' }, [el('i', { style: 'width:' + pct + '%' })]),
      el('p', { text: 'تعلّمت ' + done + ' من ' + tot + ' أداة في خطتك (' + pct + '%) • ' + (cur < 0 ? 'أنهيت الخطة 🎉' : 'أنت الآن في الأسبوع ' + (cur + 1)) + ' • الوقت المتوقع ≈ ' + hrs + ' ساعات أسبوعيًا' }),
      el('p', { class: 'plan-tip', text: '💡 ' + TIP[a.goal] })]);
    var edit = el('button', { class: 'btn sm', type: 'button', text: 'عدّل إجاباتي' }), rst = el('button', { class: 'btn sm', type: 'button', text: 'امسح الخطة' });
    edit.onclick = function () { form(a); }; rst.onclick = function () { ls(null); render(); };
    sum.appendChild(el('div', { class: 'adm-row' }, [edit, rst])); root.appendChild(sum);
    pl.weeks.forEach(function (w, i) {
      var wd = w.every(stepDone), key = 'w' + i;
      var d = el('details', { class: 'panel plan-week' + (i === cur ? ' now' : '') + (wd ? ' done' : '') });
      if (openSet ? openSet[key] : i === cur) d.setAttribute('open', '');
      d.dataset.k = key;
      d.appendChild(el('summary', {}, [el('b', { text: 'الأسبوع ' + (i + 1) }), el('span', { class: 'plan-st', text: wd ? '✓ مكتمل' : (i === cur ? '◀ ابدأ من هنا' : '') }), el('small', { text: w.map(function (s) { return s.t; }).join(' • ') })]));
      w.forEach(function (s) {
        var sd = stepDone(s), blk = el('div', { class: 'plan-step' + (sd ? ' done' : '') }, [el('h3', { text: s.t }), el('p', { class: 'cdx-sub', text: s.d })]);
        var tools = el('div', { class: 'plan-tools' });
        s.tools.forEach(function (t) {
          var on = !!L[t], b = el('button', { type: 'button', class: 'plan-chk' + (on ? ' on' : ''), 'data-pl': t, 'aria-pressed': String(on), text: on ? '✓' : '☐', 'aria-label': 'علّم ' + D.names[t] });
          tools.appendChild(el('span', { class: 'plan-tool' }, [b, el('a', { href: 'tools/' + t + '.html', text: D.names[t] })]));
        });
        var lab = s.lab ? el('p', { class: 'plan-x' }, [(S().sims && S().sims['lab-' + s.lab.n]) ? '✅ ' : '🧪 ', 'تدريب في المختبر: ', el('a', { href: 'lab.html', text: s.lab.t })]) : null;
        var ex = s.exam ? el('p', { class: 'plan-x' }, ['🎓 اختبار القسم: ', el('a', { href: 'exams.html', text: s.exam }), ' (تعليمي، وليس اعتمادًا رسميًا)']) : null;
        var seq = a.way === 'practice' ? [lab, tools, ex] : [tools, lab, ex];
        seq.forEach(function (x) { if (x) blk.appendChild(x); }); d.appendChild(blk);
      });
      root.appendChild(d);
    });
    root.appendChild(el('p', { class: 'cdx-sub', text: 'الخطة مبنية من مسارات التعلّم والمختبر الموجودة في الموقع. إجاباتك محفوظة في متصفحك فقط.' }));
  }
  function form(prev) {
    root.textContent = ''; var ans = prev || {};
    var f = el('form', { class: 'panel plan-form' }, [el('h2', { text: 'خمسة أسئلة وتجهز خطتك' })]);
    Q.forEach(function (q) {
      var fs = el('fieldset', {}, [el('legend', { text: q[1] })]);
      q[2].forEach(function (o, i) { var r = el('input', { type: 'radio', name: q[0], value: o[0] }); if (ans[q[0]] === o[0] || (!ans[q[0]] && i === 0 && q[0] !== 'interest')) r.checked = true; fs.appendChild(el('label', { class: 'plan-opt' }, [r, el('span', { text: o[1] })])); });
      f.appendChild(fs);
    });
    f.appendChild(el('button', { class: 'btn primary', type: 'submit', text: 'ابنِ خطتي' }));
    var note = el('p', { class: 'cdx-note', text: '' }); f.appendChild(note);
    f.onsubmit = function (e) { e.preventDefault(); var a = {}; Q.forEach(function (q) { var c = f.querySelector('input[name=' + q[0] + ']:checked'); if (c) a[q[0]] = c.value; }); if (!a.interest) { note.textContent = 'اختر المجال الذي يهمّك.'; return; } ls(a); openSet = null; render(); window.scrollTo(0, 0); };
    root.appendChild(f);
  }
  root.addEventListener('click', function (e) {
    var b = e.target.closest('[data-pl]'); if (!b || !window.CDXP) return;
    openSet = {}; [].forEach.call(root.querySelectorAll('details'), function (d) { openSet[d.dataset.k] = d.open; });
    window.CDXP.toggleLearned(b.getAttribute('data-pl')); document.dispatchEvent(new CustomEvent('cdx-progress')); render();
  });
  function go() { if (!window.CDXP) return setTimeout(go, 100); render(); }
  go();
})();
