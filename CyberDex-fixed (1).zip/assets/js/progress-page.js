(function () {
  function init() {
  var P = window.CDXP; var $ = function (i) { return document.getElementById(i); };
  if (!$('pgLevel')) return;
  var tools = []; try { tools = JSON.parse($('pgTools').textContent); } catch (e) {}
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function render() {
    var st = P.stats(), S = P.state();
    $('pgLevel').textContent = st.level; $('pgLearned').textContent = st.learned; $('pgAces').textContent = st.aces; $('pgSims').textContent = st.sims; $('pgStreak').textContent = st.streak;
    var pct = st.nextMin ? Math.round((st.points - st.levelMin) * 100 / (st.nextMin - st.levelMin)) : 100;
    $('pgBar').style.width = pct + '%';
    var C = 2 * Math.PI * 52, rg = $('pgRing'); rg.style.strokeDasharray = C; rg.style.strokeDashoffset = C * (1 - pct / 100);
    var pe = $('pgPts'), to = st.points, from = +pe.getAttribute('data-v') || 0; pe.setAttribute('data-v', to);
    if (from === to) pe.textContent = to; else { var t0 = performance.now(); (function f(t) { var k = Math.min(1, (t - t0) / 1100), e = 1 - Math.pow(1 - k, 3); pe.textContent = Math.round(from + (to - from) * e); if (k < 1) requestAnimationFrame(f); })(t0); }
    $('pgNext').textContent = st.nextMin ? st.points + ' نقطة — تحتاج ' + (st.nextMin - st.points) + ' للوصول إلى «' + st.nextName + '»' : st.points + ' نقطة — وصلت لأعلى مستوى';
    var cats = {}; tools.forEach(function (t) { var c = cats[t.c] || (cats[t.c] = { name: t.c, total: 0, done: 0 }); c.total++; if (S.learned[t.id]) c.done++; });
    var cl = Object.keys(cats).map(function (k) { return cats[k]; }).sort(function (a, b) { return b.total - a.total; });
    $('pgCats').innerHTML = cl.map(function (c) { return '<div class="pg-cat"><div><b>' + esc(c.name) + '</b><span>' + c.done + ' / ' + c.total + '</span></div><div class="pg-bar"><i style="width:' + Math.round(c.done * 100 / c.total) + '%"></i></div></div>'; }).join('');
    if (window.CDX_ACH) {
      var bl = window.CDX_ACH.badges(), on = bl.filter(function (x) { return x.on; }).length;
      $('pgBadgeCount').textContent = on + ' من ' + bl.length;
      var first = !$('pgBadges').children.length;
      $('pgBadges').innerHTML = bl.map(function (x, i) { return '<div class="badge r-' + x.rar + (x.on ? ' on' : '') + (first ? ' pop' : '') + '" style="animation-delay:' + (i * 40) + 'ms"><span class="bi">' + (x.on ? '★' : '🔒') + '</span><b>' + esc(x.name) + '</b><small>' + esc(x.desc) + '</small><em>' + x.rarName + '</em></div>'; }).join('');
      $('pgSkins').innerHTML = window.CDX_ACH.skins().map(function (k) { return '<div class="sg' + (k.open ? ' on' : '') + '"><b>' + (k.open ? '✓ ' : '🔒 ') + esc(k.name) + '</b><small>' + (k.open ? 'مفتوح — فعّله من زر الثيمات' : esc(k.need)) + '</small></div>'; }).join('');
    }
    var names = {}; tools.forEach(function (t) { names[t.id] = t.n; });
    var ids = Object.keys(S.learned).filter(function (i) { return names[i]; });
    $('pgList').innerHTML = ids.map(function (i) { return '<a class="chip" href="tools/' + i + '.html">' + esc(names[i]) + '</a>'; }).join('');
    $('pgEmpty').hidden = ids.length > 0;
    $('pgSync').textContent = window.CDX_SESSION ? '✔ مسجّل الدخول: تقدّمك يُحفظ بحسابك على كل أجهزتك.' : 'تقدّمك محفوظ على هذا الجهاز فقط. سجّل الدخول من أعلى الصفحة لحفظه بحسابك.';
  }
  document.addEventListener('cdx-progress', render); document.addEventListener('cdx-ach', render); document.addEventListener('cdx-auth', function () { setTimeout(render, 300); });
  $('pgReset').onclick = function () { if (confirm('سيُمسح تقدّمك من هذا الجهاز. متأكد؟')) { P.reset(); render(); } };
  render();
  }
  if (document.readyState === 'complete') init(); else window.addEventListener('load', init);
})();
