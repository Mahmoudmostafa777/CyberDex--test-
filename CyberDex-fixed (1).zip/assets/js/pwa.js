/* CyberDex PWA: registers the service worker, install button, offline download, update notice */
(function () {
  'use strict';
  var SRC = document.currentScript && document.currentScript.src || '';
  var ROOT = SRC.replace(/assets\/js\/pwa\.js.*$/, '');
  var isStandalone = (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true;
  var okCtx = location.protocol === 'https:' || /^(localhost|127\.0\.0\.1)$/.test(location.hostname);
  var KEY = 'cdx-offline';
  var get = function (k) { try { return localStorage.getItem(k); } catch (e) { return null; } };
  var put = function (k, v) { try { localStorage.setItem(k, v); } catch (e) {} };

  // apple touch icon for iOS "Add to Home Screen"
  if (!document.querySelector('link[rel="apple-touch-icon"]')) {
    var ai = document.createElement('link'); ai.rel = 'apple-touch-icon'; ai.href = ROOT + 'assets/img/apple-touch-icon.png'; document.head.appendChild(ai);
  }

  var toast = function (msg, actionText, action) {
    var t = document.createElement('div'); t.className = 'pwa-toast'; t.setAttribute('role', 'status');
    var s = document.createElement('span'); s.textContent = msg; t.appendChild(s);
    if (actionText) { var b = document.createElement('button'); b.type = 'button'; b.textContent = actionText; b.addEventListener('click', function () { action(); t.remove(); }); t.appendChild(b); }
    var x = document.createElement('button'); x.type = 'button'; x.className = 'x'; x.setAttribute('aria-label', 'إغلاق'); x.textContent = '×'; x.addEventListener('click', function () { t.remove(); }); t.appendChild(x);
    document.body.appendChild(t); setTimeout(function () { if (t.parentNode) t.remove(); }, 9000);
  };

  /* ---- service worker ---- */
  var reg = null;
  if ('serviceWorker' in navigator && okCtx) {
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (hadController) toast('تم تحديث الموقع إلى أحدث نسخة.', 'حدّث الصفحة', function () { location.reload(); });
      hadController = true;
    });
    navigator.serviceWorker.register(ROOT + 'sw.js').then(function (r) { reg = r; paintDl(); }).catch(function () {});
    navigator.serviceWorker.addEventListener('message', function (e) {
      var d = e.data || {};
      if (d.type === 'cdx-cache-progress') setDl('جارٍ التحميل… ' + d.done + ' من ' + d.total, true);
      else if (d.type === 'cdx-cache-done') { put(KEY, '1'); setDl('✓ الموقع محفوظ ويعمل بدون إنترنت', false); }
      else if (d.type === 'cdx-cache-error') setDl('تعذّر التحميل، حاول مرة أخرى', false);
    });
  }

  /* ---- install button ---- */
  var prompt = null, ib = null;
  addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault(); prompt = e;
    if (isStandalone) return;
    mountInstall();
  });
  addEventListener('appinstalled', function () { prompt = null; if (ib) ib.remove(); toast('تم تثبيت CyberDex على جهازك.'); });
  function mountInstall() {
    var acts = document.querySelector('.top-actions'); if (!acts || ib) return;
    ib = document.createElement('button'); ib.type = 'button'; ib.className = 'btn sm pwa-install'; ib.textContent = 'تثبيت التطبيق';
    ib.addEventListener('click', function () { if (!prompt) return; prompt.prompt(); prompt.userChoice.finally(function () { prompt = null; if (ib) ib.remove(); }); });
    acts.insertBefore(ib, acts.firstChild);
  }

  /* ---- offline download box (footer) ---- */
  var dlBtn = null, dlMsg = null;
  function setDl(msg, busy) { if (dlMsg) dlMsg.textContent = msg; if (dlBtn) dlBtn.disabled = !!busy; }
  function paintDl() { if (dlMsg && get(KEY) === '1') dlMsg.textContent = '✓ الموقع محفوظ ويعمل بدون إنترنت'; }
  function mountFooter() {
    var base = document.querySelector('.fbase'); if (!base || !('serviceWorker' in navigator) || !okCtx) return;
    var box = document.createElement('div'); box.className = 'pwa-box';
    dlBtn = document.createElement('button'); dlBtn.type = 'button'; dlBtn.className = 'btn sm'; dlBtn.textContent = 'حمّل الموقع للاستخدام بدون إنترنت';
    dlMsg = document.createElement('span'); dlMsg.className = 'pwa-msg';
    dlBtn.addEventListener('click', function () {
      navigator.serviceWorker.ready.then(function (r) {
        setDl('جارٍ التحميل…', true);
        (r.active || navigator.serviceWorker.controller).postMessage({ type: 'cache-all' });
      });
    });
    box.appendChild(dlBtn); box.appendChild(dlMsg);
    var ios = /iphone|ipad|ipod/i.test(navigator.userAgent) && !isStandalone;
    if (ios) { var h = document.createElement('span'); h.className = 'pwa-msg'; h.textContent = 'للتثبيت على آيفون: زر المشاركة ثم «إضافة إلى الشاشة الرئيسية».'; box.appendChild(h); }
    base.parentNode.insertBefore(box, base);
    paintDl();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mountFooter); else mountFooter();

  /* ---- connection notice ---- */
  addEventListener('offline', function () { toast('أنت بدون إنترنت: تُعرض النسخة المحفوظة على جهازك.'); });
  addEventListener('online', function () { toast('عاد الاتصال بالإنترنت.'); });
})();
