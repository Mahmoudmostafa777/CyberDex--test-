(function () {
  var box = document.getElementById('goalSearch'); if (!box) return;
  var cards = [].slice.call(document.querySelectorAll('.goal'));
  var chips = [].slice.call(document.querySelectorAll('[data-theme]'));
  var count = document.getElementById('goalCount'), empty = document.getElementById('goalEmpty');
  var theme = 'all';
  var STOP = {'اريد':1,'ان':1,'أن':1,'عن':1,'من':1,'في':1,'على':1,'هل':1,'كيف':1,'ازاي':1,'عايز':1,'عاوز':1,'اعرف':0,'و':1,'ما':1,'هو':1};
  function norm(s) {
    return String(s || '').toLowerCase().replace(/[ً-ٰٟـ]/g, '')
      .replace(/[إأآٱ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/[^a-z0-9؀-ۿ\s\-\.]/g, ' ');
  }
  function toks(q) {
    return norm(q).split(/\s+/).filter(Boolean).map(function (w) { return w.length > 3 && w.indexOf('ال') === 0 ? w.slice(2) : w; })
      .filter(function (w) { return !STOP[w]; });
  }
  cards.forEach(function (c) { c._t = norm(c.getAttribute('data-text')); });
  function run() {
    var q = toks(box.value), shown = 0, list = [];
    cards.forEach(function (c) {
      var ok = theme === 'all' || c.getAttribute('data-theme') === theme, score = 0;
      if (ok && q.length) { q.forEach(function (w) { if (c._t.indexOf(w) > -1) score++; }); ok = score > 0; }
      c._s = score; c.hidden = !ok; if (ok) { shown++; list.push(c); }
    });
    if (q.length) {
      var parent = cards[0].parentNode;
      list.sort(function (a, b) { return b._s - a._s; }).forEach(function (c) { parent.appendChild(c); });
      if (list[0] && list.length === 1) list[0].open = true;
    }
    count.textContent = shown + ' هدف'; empty.hidden = shown > 0;
  }
  box.addEventListener('input', run);
  chips.forEach(function (b) {
    b.addEventListener('click', function () {
      theme = b.getAttribute('data-theme');
      chips.forEach(function (x) { x.classList.toggle('active', x === b); });
      run();
    });
  });
  [].forEach.call(document.querySelectorAll('[data-q]'), function (b) {
    b.addEventListener('click', function () { box.value = b.getAttribute('data-q'); run(); box.focus(); });
  });
  try { var p = new URLSearchParams(location.search).get('q'); if (p) box.value = p; } catch (e) {}
  run();
})();
