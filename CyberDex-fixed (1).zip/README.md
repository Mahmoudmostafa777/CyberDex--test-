# CyberDex

موقع ثابت (Static) بلا اعتماديات: ارفع محتوى هذا المجلد كما هو.

## الهيكل
- `index.html` الرئيسية، `tools.html` الفهرس، `paths.html` المسارات، `learn.html` الأساسيات، `resources.html` المراجع
- `tools/*.html` صفحة لكل أداة (500 صفحة)
- `about.html` `responsible-use.html` `privacy.html` `contact.html` `changelog.html` `404.html`
- `assets/` التصميم والسكربت والأيقونة، و`assets/tools.json` بيانات الأدوات
- `_headers` ترويسات أمان (Netlify وCloudflare Pages)، `robots.txt`، `site.webmanifest`

## النشر
1. **Cloudflare Pages / Netlify:** اسحب المجلد كاملًا إلى لوحة التحكم (Direct Upload) أو اربطه بمستودع Git.
2. اربط دومينك وفعّل HTTPS (تلقائي على المنصتين).
3. عند معرفة الدومين يُعاد توليد الموقع بروابط canonical وsitemap.xml.

## قبل النشر
- أضف وسيلة التواصل في `contact.html`.
- راجع `privacy.html` إذا أضفت تحليلات أو أي خدمة خارجية.
