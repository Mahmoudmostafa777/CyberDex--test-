// CyberDex practice lab: a pure browser simulator. It never runs or contacts anything real.
// The network (10.0.0.0/24), the files and every output below are fictional and written in advance.
(function () {
  var root = document.getElementById('labApp'); if (!root) return;
  var FS = window.CDX_LAB_FS || {}, HASH = window.CDX_LAB_HASH || {}, MD5 = window.CDX_LAB_MD5 || {};
  var HOME = '/home/student', cwd = HOME, hist = [], hi = 0;
  var P = function () { return window.CDXP; };
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function pad(s, n) { s = String(s); while (s.length < n) s += ' '; return s; }

  // ------------------------------------------------------------ fictional file system
  function norm(p) { var o = []; p.split('/').forEach(function (s) { if (!s || s === '.') return; if (s === '..') o.pop(); else o.push(s); }); return '/' + o.join('/'); }
  function resolve(p, base) { base = base || cwd; if (p === '~' || p === '') return HOME; if (p.indexOf('~/') === 0) p = HOME + p.slice(1); if (p.charAt(0) !== '/') p = base + '/' + p; return norm(p); }
  function isFile(p) { return Object.prototype.hasOwnProperty.call(FS, p); }
  function isDir(p) { if (p === '/' || p === '/home') return true; return Object.keys(FS).some(function (k) { return k.indexOf(p + '/') === 0; }); }
  function listDir(p) {
    if (p === '/') return ['home']; if (p === '/home') return ['student'];
    var s = {}; Object.keys(FS).forEach(function (k) { if (k.indexOf(p + '/') === 0) s[k.slice(p.length + 1).split('/')[0]] = 1; });
    return Object.keys(s).sort(function (a, b) { return a.toLowerCase() < b.toLowerCase() ? -1 : 1; });
  }
  function shortCwd() { return cwd === HOME ? '~' : cwd.indexOf(HOME + '/') === 0 ? '~' + cwd.slice(HOME.length) : cwd; }

  // ------------------------------------------------------------ fictional network
  var DNS = { 'lab.cyberdex.test': '10.0.0.5', 'gateway.cyberdex.test': '10.0.0.1', 'files.cyberdex.test': '10.0.0.12', 'db.cyberdex.test': '10.0.0.20' };
  var NET = {
    '10.0.0.1': { mac: '02:42:0A:00:00:01', ports: { 53: ['domain', 'dnsmasq 2.89'], 80: ['http', 'lighttpd 1.4.59'] } },
    '10.0.0.2': { self: true, ports: {} },
    '10.0.0.5': { mac: '02:42:0A:00:00:05', ports: { 22: ['ssh', 'OpenSSH 8.2p1 Ubuntu 4ubuntu0.5 (Ubuntu Linux; protocol 2.0)'], 80: ['http', 'Apache httpd 2.4.41 ((Ubuntu))'] } },
    '10.0.0.12': { mac: '02:42:0A:00:00:0C', ports: { 22: ['ssh', 'OpenSSH 8.9p1 Ubuntu 3ubuntu0.1 (Ubuntu Linux; protocol 2.0)'], 445: ['microsoft-ds', 'Samba smbd 4.6.2'] } },
    '10.0.0.20': { mac: '02:42:0A:00:00:14', ports: { 3306: ['mysql', 'MySQL 5.7.33-0ubuntu0.18.04.1'] } }
  };
  var SVC = { 21: 'ftp', 22: 'ssh', 23: 'telnet', 25: 'smtp', 53: 'domain', 80: 'http', 110: 'pop3', 139: 'netbios-ssn', 443: 'https', 445: 'microsoft-ds', 3306: 'mysql', 3389: 'ms-wbt-server', 8080: 'http-proxy' };
  var OUT_NOTE = 'المحاكاة تتعامل مع شبكة المختبر الوهمية (10.0.0.0/24) فقط. فحص أو الاتصال بأجهزة لا تملكها أو بدون تصريح قد يكون جريمة.';
  function isIP(s) { return /^\d{1,3}(\.\d{1,3}){3}$/.test(s); }
  function inLab(ip) { return /^10\.0\.0\.\d{1,3}$/.test(ip) && ip.split('.').every(function (x) { return +x <= 255; }); }
  function resolveHost(h) { if (isIP(h)) return h; return DNS[String(h).toLowerCase()] || null; }

  // ------------------------------------------------------------ commands: each returns {o: stdout, e: error text, n: Arabic note}
  function fl(a) { var f = {}, rest = []; a.forEach(function (x) { if (/^-[A-Za-z]+$/.test(x)) x.slice(1).split('').forEach(function (c) { f[c] = 1; }); else rest.push(x); }); return { f: f, rest: rest }; }
  function readSrc(files, inp, cmd) {
    if (files.length) {
      var rp = resolve(files[0]);
      if (isDir(rp)) return { e: cmd + ': ' + files[0] + ': Is a directory' };
      if (!isFile(rp)) return { e: cmd + ': ' + files[0] + ': No such file or directory' };
      return { text: FS[rp], name: files[0] };
    }
    if (inp != null) return { text: inp + '\n', name: '' };
    return { e: cmd + ': missing file operand', n: 'اكتب اسم ملف بعد الأمر (أو مرّر له ناتج أمر آخر بعلامة |).' };
  }
  function lines(t) { return (t === '' || t === '\n') ? [] : t.replace(/\n$/, '').split('\n'); }
  function longLine(path, label) {
    var d = label === '.' || label === '..' || isDir(path);
    return (d ? 'drwxr-xr-x 2' : '-rw-r--r-- 1') + ' student student ' + (d ? '4096' : String(FS[path].length)) + ' Nov 25 09:40 ' + label;
  }
  var C = {};
  C.pwd = function () { return { o: cwd }; };
  C.whoami = function () { return { o: 'student' }; };
  C.id = function () { return { o: 'uid=1000(student) gid=1000(student) groups=1000(student)' }; };
  C.hostname = function () { return { o: 'kali-lab' }; };
  C.uname = function (a) { return { o: a.indexOf('-a') >= 0 ? 'Linux kali-lab 6.5.0-kali3-amd64 #1 SMP PREEMPT_DYNAMIC Debian 6.5.6-1kali1 x86_64 GNU/Linux' : 'Linux' }; };
  C.echo = function (a) { return { o: a.join(' ') }; };
  C.clear = function () { return { clear: true }; };
  C.exit = function () { return { n: 'هذه محاكاة داخل صفحة، فلا حاجة للخروج. انتقل لمهمة أخرى من الأسفل.' }; };
  C.ls = function (a) {
    var r = fl(a), paths = r.rest.length ? r.rest : ['.'], out = [], err = [];
    paths.forEach(function (p) {
      var rp = resolve(p);
      if (isFile(rp)) { out.push(r.f.l ? longLine(rp, p) : p); return; }
      if (!isDir(rp)) { err.push("ls: cannot access '" + p + "': No such file or directory"); return; }
      var names = listDir(rp); if (r.f.a) names = ['.', '..'].concat(names);
      if (paths.length > 1) out.push(p + ':');
      if (r.f.l) { out.push('total ' + names.length * 4); names.forEach(function (n) { out.push(longLine(resolve(n, rp), n)); }); } else out.push(names.join('  '));
    });
    return { o: out.join('\n'), e: err.join('\n') };
  };
  C.cd = function (a) {
    var t = a[0] || '~', rp = resolve(t);
    if (isFile(rp)) return { e: 'bash: cd: ' + t + ': Not a directory' };
    if (!isDir(rp)) return { e: 'bash: cd: ' + t + ': No such file or directory' };
    cwd = rp; return { o: '' };
  };
  C.cat = function (a, inp) {
    var r = fl(a); if (!r.rest.length) { if (inp != null) return { o: inp }; return { e: 'cat: missing file operand', n: 'اكتب اسم ملف، مثل: cat notes.txt' }; }
    var o = [], e = [];
    r.rest.forEach(function (f) { var rp = resolve(f); if (isDir(rp)) e.push('cat: ' + f + ': Is a directory'); else if (!isFile(rp)) e.push('cat: ' + f + ': No such file or directory'); else o.push(FS[rp].replace(/\n$/, '')); });
    return { o: o.join('\n'), e: e.join('\n') };
  };
  function nOpt(a) { var n = 10, rest = []; for (var i = 0; i < a.length; i++) { if (a[i] === '-n' && a[i + 1]) n = +a[++i] || 10; else if (/^-\d+$/.test(a[i])) n = +a[i].slice(1); else rest.push(a[i]); } return { n: n, rest: rest }; }
  C.head = function (a, inp) { var r = nOpt(a), s = readSrc(r.rest, inp, 'head'); if (s.e) return s; return { o: lines(s.text).slice(0, r.n).join('\n') }; };
  C.tail = function (a, inp) { var r = nOpt(a), s = readSrc(r.rest, inp, 'tail'); if (s.e) return s; var l = lines(s.text); return { o: l.slice(Math.max(0, l.length - r.n)).join('\n') }; };
  C.wc = function (a, inp) {
    var r = fl(a), s = readSrc(r.rest, inp, 'wc'); if (s.e) return s;
    var n = lines(s.text).length, w = s.text.split(/\s+/).filter(Boolean).length;
    return { o: (r.f.l ? String(n) : n + ' ' + w + ' ' + s.text.length) + (s.name ? ' ' + s.name : '') };
  };
  C.grep = function (a, inp) {
    var r = fl(a.filter(function (x) { return x.indexOf('--color') !== 0; })), pat = r.rest[0];
    if (pat === undefined) return { e: 'Usage: grep [OPTION]... PATTERNS [FILE]...', n: 'مثال: grep Failed logs/auth.log' };
    var s = readSrc(r.rest.slice(1), inp, 'grep'); if (s.e) return s;
    var re; try { re = new RegExp(pat, r.f.i ? 'i' : ''); } catch (x) { re = new RegExp(pat.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), r.f.i ? 'i' : ''); }
    var m = []; lines(s.text).forEach(function (l, i) { var hit = re.test(l); if (r.f.v) hit = !hit; if (hit) m.push(r.f.n ? (i + 1) + ':' + l : l); });
    return { o: r.f.c ? String(m.length) : m.join('\n') };
  };
  function ifc() {
    return { o: 'eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500\n        inet 10.0.0.2  netmask 255.255.255.0  broadcast 10.0.0.255\n        ether 02:42:0a:00:00:02  txqueuelen 0  (Ethernet)\nlo: flags=73<UP,LOOPBACK,RUNNING>  mtu 65536\n        inet 127.0.0.1  netmask 255.0.0.0' };
  }
  C.ifconfig = ifc;
  C.ip = function (a) {
    if (a[0] === 'a' || a[0] === 'addr' || a[0] === 'address') return { o: '1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536\n    inet 127.0.0.1/8 scope host lo\n2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500\n    link/ether 02:42:0a:00:00:02 brd ff:ff:ff:ff:ff:ff\n    inet 10.0.0.2/24 brd 10.0.0.255 scope global eth0' };
    return { e: 'ip: unsupported in this lab', n: 'جرّب: ip a' };
  };
  C.ping = function (a) {
    var n = 4, host = null;
    for (var i = 0; i < a.length; i++) { if (a[i] === '-c' && a[i + 1]) n = Math.max(1, Math.min(10, +a[++i] || 4)); else if (a[i].charAt(0) !== '-') host = a[i]; }
    if (!host) return { e: 'ping: usage error: Destination address required', n: 'مثال: ping -c 4 10.0.0.1' };
    var ip = resolveHost(host);
    if (!ip) return { e: 'ping: ' + host + ': Name or service not known' };
    if (!inLab(ip)) return { e: 'ping: ' + host + ': Network is unreachable', n: OUT_NOTE };
    var up = !!NET[ip], t = [0.41, 0.38, 0.52, 0.36, 0.44, 0.39, 0.47, 0.35, 0.50, 0.42], o = ['PING ' + host + ' (' + ip + ') 56(84) bytes of data.'], k;
    if (up) { for (k = 0; k < n; k++) o.push('64 bytes from ' + ip + ': icmp_seq=' + (k + 1) + ' ttl=64 time=' + t[k] + ' ms'); o.push('', '--- ' + host + ' ping statistics ---', n + ' packets transmitted, ' + n + ' received, 0% packet loss, time ' + (n - 1) * 1001 + 'ms', 'rtt min/avg/max/mdev = 0.350/0.420/0.520/0.052 ms'); }
    else { for (k = 0; k < n; k++) o.push('From 10.0.0.2 icmp_seq=' + (k + 1) + ' Destination Host Unreachable'); o.push('', '--- ' + host + ' ping statistics ---', n + ' packets transmitted, 0 received, +' + n + ' errors, 100% packet loss, time ' + (n - 1) * 1002 + 'ms'); }
    return { o: o.join('\n') };
  };
  C.dig = function (a) {
    var short = a.indexOf('+short') >= 0, name = a.filter(function (x) { return x.charAt(0) !== '+' && x.charAt(0) !== '-'; })[0];
    if (!name) return { e: 'dig: usage: dig [+short] name', n: 'مثال: dig lab.cyberdex.test' };
    var ip = DNS[name.toLowerCase()];
    if (short) return { o: ip || '' };
    var st = ip ? 'NOERROR' : 'NXDOMAIN';
    return { o: '; <<>> DiG 9.19.17-2-Debian <<>> ' + name + '\n;; global options: +cmd\n;; Got answer:\n;; ->>HEADER<<- opcode: QUERY, status: ' + st + ', id: 41873\n;; flags: qr aa rd ra; QUERY: 1, ANSWER: ' + (ip ? 1 : 0) + ', AUTHORITY: 0, ADDITIONAL: 1\n\n;; QUESTION SECTION:\n;' + name + '.\t\tIN\tA\n' + (ip ? '\n;; ANSWER SECTION:\n' + name + '.\t300\tIN\tA\t' + ip + '\n' : '') + '\n;; Query time: 3 msec\n;; SERVER: 10.0.0.1#53(10.0.0.1) (UDP)\n;; WHEN: Wed Nov 25 10:04:11 UTC 2026\n;; MSG SIZE  rcvd: 62' };
  };
  C.nslookup = function (a) {
    var name = a[0]; if (!name) return { e: 'nslookup: usage: nslookup name', n: 'مثال: nslookup lab.cyberdex.test' };
    var ip = DNS[name.toLowerCase()];
    if (!ip) return { o: 'Server:\t\t10.0.0.1\nAddress:\t10.0.0.1#53\n\n** server can\'t find ' + name + ': NXDOMAIN', e: '' };
    return { o: 'Server:\t\t10.0.0.1\nAddress:\t10.0.0.1#53\n\nName:\t' + name + '\nAddress: ' + ip };
  };
  function table(rows, head) {
    var w = head.map(function (h) { return h.length; });
    rows.forEach(function (r) { r.forEach(function (c, i) { if (String(c).length > w[i]) w[i] = String(c).length; }); });
    var out = [head.map(function (h, i) { return i === head.length - 1 ? h : pad(h, w[i]); }).join(' ')];
    rows.forEach(function (r) { out.push(r.map(function (c, i) { return i === r.length - 1 ? c : pad(c, w[i]); }).join(' ')); });
    return out.join('\n');
  }
  function parsePorts(s) {
    if (s === '-') return 'all'; var o = [];
    String(s).split(',').forEach(function (x) { var m = x.match(/^(\d+)-(\d+)$/); if (m) { for (var i = +m[1]; i <= Math.min(+m[2], +m[1] + 200); i++) o.push(i); } else if (/^\d+$/.test(x)) o.push(+x); });
    return o;
  }
  C.nmap = function (a) {
    var sn = 0, sV = 0, pp = null, target = null, un = null;
    for (var i = 0; i < a.length; i++) {
      var x = a[i];
      if (x === '-sn') sn = 1; else if (x === '-sV') sV = 1;
      else if (x === '-p' && a[i + 1]) pp = a[++i]; else if (/^-p./.test(x)) pp = x.slice(2);
      else if (x === '-Pn' || x === '-n' || x === '-v' || x === '-T4') { }
      else if (x.charAt(0) === '-') un = un || x; else target = x;
    }
    if (un) return { e: 'nmap: option ' + un + ' is not supported in this lab', n: 'المختبر يدعم: -sn و-sV و-p. جرّب أحدها.' };
    if (!target) return { e: 'Nmap 7.94 ( https://nmap.org )\nUsage: nmap [Scan Type(s)] [Options] {target specification}', n: 'مثال: nmap 10.0.0.5' };
    var head = 'Starting Nmap 7.94 ( https://nmap.org ) at 2026-11-25 10:05 UTC\n';
    if (/^10\.0\.0\.0\/24$/.test(target)) {
      if (!sn) return { e: 'nmap: scanning a whole network for ports is not supported in this lab', n: 'لاكتشاف الأجهزة استخدم -sn، ثم افحص كل جهاز على حدة.' };
      var o = [head.replace(/\n$/, '')];
      Object.keys(NET).forEach(function (ip) { var h = NET[ip]; o.push('Nmap scan report for ' + ip, 'Host is up (0.00' + (40 + ip.length) + 's latency).'); if (h.mac) o.push('MAC Address: ' + h.mac + ' (Unknown)'); });
      o.push('Nmap done: 256 IP addresses (5 hosts up) scanned in 2.41 seconds');
      return { o: o.join('\n') };
    }
    var ip = resolveHost(target);
    if (!ip) return { e: 'Failed to resolve "' + target + '".' };
    if (!inLab(ip)) return { e: 'nmap: refused', n: OUT_NOTE };
    var h = NET[ip], label = isIP(target) ? ip : target + ' (' + ip + ')';
    if (!h) return { o: head + 'Note: Host seems down. If it is really up, but blocking our ping probes, try -Pn\nNmap done: 1 IP address (0 hosts up) scanned in 3.04 seconds' };
    var out = [head.replace(/\n$/, ''), 'Nmap scan report for ' + label, 'Host is up (0.0021s latency).'];
    if (sn) { if (h.mac) out.push('MAC Address: ' + h.mac + ' (Unknown)'); out.push('Nmap done: 1 IP address (1 host up) scanned in 0.03 seconds'); return { o: out.join('\n') }; }
    var want = pp ? parsePorts(pp) : null, rows = [], openN = Object.keys(h.ports).length, total = 1000;
    if (want === 'all') { want = null; total = 65535; }
    var show = want ? want : Object.keys(h.ports).map(Number).sort(function (p, q) { return p - q; });
    show.forEach(function (p) {
      var op = h.ports[p], row = [p + '/tcp', op ? 'open' : 'closed', op ? op[0] : (SVC[p] || 'unknown')];
      if (sV) row.push(op ? op[1] : ''); rows.push(row);
    });
    if (!want) out.push('Not shown: ' + (total - openN) + ' closed tcp ports (reset)');
    if (rows.length) out.push(table(rows, sV ? ['PORT', 'STATE', 'SERVICE', 'VERSION'] : ['PORT', 'STATE', 'SERVICE']).replace(/ +$/gm, ''));
    else out.push('All scanned ports are closed');
    if (sV) out.push('Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .');
    out.push('', 'Nmap done: 1 IP address (1 host up) scanned in ' + (sV ? '6.52' : '0.12') + ' seconds');
    return { o: out.join('\n') };
  };
  function webPage(ip, path) {
    path = path.replace(/\/+$/, '') || '/'; var q = path.indexOf('?'); if (q >= 0) path = path.slice(0, q);
    if (ip === '10.0.0.1') return path === '/' ? [200, '<html><head><title>Router login</title></head><body><h1>Gateway admin</h1><form>...</form></body></html>'] : [404, '<html><head><title>404 Not Found</title></head><body>Not Found</body></html>'];
    if (path === '/' || path === '/index.html') return [200, '<html>\n<head><title>CyberDex Lab - Intranet</title></head>\n<body><h1>Welcome to the lab intranet</h1><p>Under construction.</p></body>\n</html>'];
    if (path === '/backup') return [200, '<html><head><title>Index of /backup</title></head><body><h1>Index of /backup</h1><pre>\n<a href="db_backup.sql">db_backup.sql</a>   25-Nov-2026 08:30   48K\n<a href="site_old.zip">site_old.zip</a>    20-Nov-2026 17:10   1.2M\n</pre></body></html>'];
    if (path === '/admin') return [401, '<html><head><title>401 Unauthorized</title></head><body><h1>Authorization Required</h1></body></html>'];
    if (['/css', '/images', '/uploads'].indexOf(path) >= 0) return [403, '<html><head><title>403 Forbidden</title></head><body><h1>Forbidden</h1></body></html>'];
    return [404, '<html><head><title>404 Not Found</title></head><body><h1>Not Found</h1></body></html>'];
  }
  var REASON = { 200: 'OK', 401: 'Unauthorized', 403: 'Forbidden', 404: 'Not Found' };
  C.curl = function (a) {
    var I = 0, url = null;
    a.forEach(function (x) { if (x === '-I' || x === '--head') I = 1; else if (x.charAt(0) !== '-') url = x; });
    if (!url) return { e: "curl: try 'curl --help' for more information", n: 'مثال: curl -I http://10.0.0.5' };
    var m = url.match(/^(?:https?:\/\/)?([^\/:]+)(?::(\d+))?(\/.*)?$/i); if (!m) return { e: 'curl: (3) URL using bad/illegal format' };
    var host = m[1], ip = resolveHost(host);
    if (!ip) return { e: 'curl: (6) Could not resolve host: ' + host };
    if (!inLab(ip)) return { e: 'curl: refused', n: OUT_NOTE };
    if (ip !== '10.0.0.5' && ip !== '10.0.0.1') return { e: 'curl: (7) Failed to connect to ' + host + ' port 80 after 3012 ms: Couldn\'t connect to server' };
    var pg = webPage(ip, m[3] || '/'), apache = ip === '10.0.0.5';
    if (!I) return { o: pg[1] };
    return { o: 'HTTP/1.1 ' + pg[0] + ' ' + REASON[pg[0]] + '\nDate: Wed, 25 Nov 2026 10:10:00 GMT\nServer: ' + (apache ? 'Apache/2.4.41 (Ubuntu)\nX-Powered-By: PHP/7.2.24' : 'lighttpd/1.4.59') + '\nContent-Type: text/html; charset=UTF-8\nContent-Length: ' + pg[1].length };
  };
  C.gobuster = function (a) {
    var u = null, w = null, mode = a[0];
    for (var i = 1; i < a.length; i++) { if (a[i] === '-u' && a[i + 1]) u = a[++i]; else if (a[i] === '-w' && a[i + 1]) w = a[++i]; else if (a[i] === '-t' && a[i + 1]) i++; }
    if (mode !== 'dir' || !u || !w) return { e: 'gobuster: usage: gobuster dir -u URL -w WORDLIST', n: 'مثال: gobuster dir -u http://10.0.0.5 -w dirs.txt' };
    var rp = resolve(w); if (!isFile(rp)) return { e: '[!] error on parsing arguments: wordlist file "' + w + '" does not exist' };
    var m = u.match(/^(?:https?:\/\/)?([^\/:]+)/i), ip = m && resolveHost(m[1]);
    if (!ip) return { e: 'gobuster: unable to resolve ' + u };
    if (!inLab(ip)) return { e: 'gobuster: refused', n: OUT_NOTE };
    if (ip !== '10.0.0.5') return { e: 'Error: error on running gobuster: unable to connect to ' + u };
    var known = { admin: [401, 381], backup: [301, 313], css: [301, 310], images: [301, 313], uploads: [301, 314] }, o = [];
    var sep = '===============================================================';
    o.push(sep, 'Gobuster v3.6', 'by OJ Reeves (@TheColonial) & Christian Mehlmauer', sep, '[+] Url:                     ' + u, '[+] Method:                  GET', '[+] Threads:                 10', '[+] Wordlist:                ' + w, '[+] Status codes:            200,204,301,302,307,401,403', sep, 'Starting gobuster in directory enumeration mode', sep);
    lines(FS[rp]).forEach(function (wd) { var k = known[wd]; if (k) o.push(pad('/' + wd, 21) + ' (Status: ' + k[0] + ') [Size: ' + k[1] + ']' + (k[0] === 301 ? ' [--> http://' + m[1] + '/' + wd + '/]' : '')); });
    o.push(sep, 'Finished', sep);
    return { o: o.join('\n') };
  };
  C.base64 = function (a, inp) {
    var dec = a.indexOf('-d') >= 0 || a.indexOf('--decode') >= 0 || a.indexOf('-D') >= 0, files = a.filter(function (x) { return x.charAt(0) !== '-'; });
    var s = readSrc(files, inp, 'base64'); if (s.e) return s;
    try {
      if (dec) return { o: decodeURIComponent(escape(atob(s.text.replace(/\s+/g, '')))).replace(/\n$/, '') };
      return { o: btoa(unescape(encodeURIComponent(s.text))) };
    } catch (x) { return { e: 'base64: invalid input' }; }
  };
  function sum(kind) {
    return function (a) {
      var files = a.filter(function (x) { return x.charAt(0) !== '-'; }); if (!files.length) return { e: kind + 'sum: missing file operand', n: 'مثال: ' + kind + 'sum report.txt' };
      var o = [], e = [];
      files.forEach(function (f) { var rp = resolve(f); if (isDir(rp)) e.push(kind + 'sum: ' + f + ': Is a directory'); else if (!isFile(rp)) e.push(kind + 'sum: ' + f + ': No such file or directory'); else o.push(HASH[rp][kind === 'md5' ? 'md5' : 'sha256'] + '  ' + f); });
      return { o: o.join('\n'), e: e.join('\n') };
    };
  }
  C.md5sum = sum('md5'); C.sha256sum = sum('sha256');
  C.john = function (a) {
    var wl = null, file = null, show = 0;
    a.forEach(function (x) { if (x.indexOf('--wordlist=') === 0) wl = x.slice(11); else if (x === '--show') show = 1; else if (x.charAt(0) !== '-') file = x; });
    if (!file) return { e: 'Usage: john [OPTIONS] [PASSWORD-FILES]', n: 'مثال: john --wordlist=wordlist.txt hashes.txt' };
    var rp = resolve(file); if (!isFile(rp)) return { e: 'Press Ctrl-C to abort. ' + file + ': No such file or directory' };
    var found = [];
    lines(FS[rp]).forEach(function (l) { var p = l.split(':'); if (MD5[p[1]]) found.push([MD5[p[1]], p[0]]); });
    if (!show) {
      if (!wl) return { e: 'john: a wordlist is required in this lab', n: 'استخدم: john --wordlist=wordlist.txt ' + file };
      if (!isFile(resolve(wl))) return { e: 'fopen: ' + wl + ': No such file or directory' };
    }
    var o = [];
    if (show) { found.forEach(function (f) { o.push(f[1] + ':' + f[0]); }); o.push('', found.length + ' password hashes cracked, 0 left'); return { o: o.join('\n') }; }
    o.push('Using default input encoding: UTF-8', 'Loaded ' + lines(FS[rp]).length + ' password hashes with no different salts (Raw-MD5 [MD5 256/256 AVX2 8x3])', 'Press \'q\' or Ctrl-C to abort, almost any other key for status');
    found.forEach(function (f) { o.push(pad(f[0], 16) + ' (' + f[1] + ')'); });
    o.push(found.length + 'g 0:00:00:00 DONE (2026-11-25 10:30) 100.0g/s 600.0p/s 1200c/s 1200C/s 123456..admin', 'Use the "--show --format=Raw-MD5" options to display all of the cracked passwords reliably', 'Session completed.');
    return { o: o.join('\n') };
  };
  C.help = function () {
    return { o: 'Available commands in this lab:\n  pwd  ls  cd  cat  head  tail  grep  wc  echo      files and text\n  whoami  id  hostname  uname                       system info\n  ifconfig  ip a  ping  dig  nslookup  nmap         network\n  curl  gobuster                                    web\n  base64  md5sum  sha256sum  john                   encoding and hashes\n  clear  hint  mission  help\n\nTip: you can chain with a pipe, e.g.  grep Failed logs/auth.log | wc -l', n: 'اضغط Tab لإكمال الأوامر وأسماء الملفات. زر «تلميح» يقترح الخطوة التالية.' };
  };
  C.mission = function () { return { mission: true }; };
  C.hint = function () { return { hint: true }; };
  C.man = function (a) { return { e: 'No manual entry for ' + (a[0] || ''), n: 'لا توجد صفحات دليل داخل المحاكاة. افتح صفحة الأداة في الموقع لشرح مفصّل.' }; };

  // ------------------------------------------------------------ missions
  var LV = ['المستوى 1 · أوامر لينكس الأساسية', 'المستوى 2 · الشبكات والفحص', 'المستوى 3 · الويب', 'المستوى 4 · الملفات والتشفير'];
  var F = HOME + '/';
  function np(e, name) { return e.paths.indexOf(F + name) >= 0; }
  function arg(e, v) { return e.args.indexOf(v) >= 0; }
  var M = [
    { lv: 0, t: 'أين أنا؟', g: 'اعرف مجلدك الحالي، ثم اعرض الملفات الموجودة فيه.', tools: ['pwd', 'ls'],
      steps: [['اعرض مسارك الحالي', 'pwd', function (e) { return e.name === 'pwd'; }], ['اعرض الملفات الموجودة في المجلد', 'ls', function (e) { return e.name === 'ls' && e.ok; }]],
      why: 'pwd يخبرك أين أنت داخل نظام الملفات، وls يعرض ما حولك. هما أول أمرين تكتبهما في أي جلسة. جرّب أيضًا ls -la لترى الملفات المخفية والصلاحيات.' },
    { lv: 0, t: 'اقرأ مذكرات المختبر', g: 'اعرف المستخدم الحالي، ثم اقرأ ملف المذكرات notes.txt لتعرف قواعد المختبر.', tools: ['cat'],
      steps: [['اعرف اسم المستخدم الحالي', 'whoami', function (e) { return e.name === 'whoami'; }], ['اعرض محتوى notes.txt', 'cat notes.txt', function (e) { return e.name === 'cat' && np(e, 'notes.txt'); }]],
      why: 'whoami يخبرك بالمستخدم الحالي، وcat يعرض محتوى الملف. المذكرات تقول: افحص شبكة المختبر فقط. هذه قاعدة أساسية في الأمن: لا تفحص إلا ما تملكه أو لديك تصريح مكتوب به.' },
    { lv: 0, t: 'حلّل سجل دخول SSH', g: 'ادخل مجلد logs، وابحث في auth.log عن محاولات الدخول الفاشلة، ثم عُدّها.', tools: ['grep', 'cd'],
      steps: [['ادخل مجلد logs', 'cd logs', function (e) { return e.name === 'cd' && e.cwd === HOME + '/logs'; }],
        ['اعرض الأسطر التي فيها كلمة Failed', 'grep Failed auth.log', function (e) { return e.name === 'grep' && e.ok && np2(e, 'logs/auth.log') && /failed/i.test(e.args.join(' ')) && !e.flags.c; }],
        ['احسب عدد المحاولات الفاشلة', 'grep -c Failed auth.log', function (e) { return e.name === 'grep' && e.ok && e.flags.c && np2(e, 'logs/auth.log'); }]],
      why: 'كل سطر Failed password هو محاولة دخول فاشلة. 9 محاولات كلها من 10.0.0.99 تدل على تخمين كلمات سر على SSH. دفاعيًا: فعّل الدخول بالمفاتيح، وحدّد عدد المحاولات (مثل fail2ban)، واحظر عنوان المصدر.' },
    { lv: 1, t: 'هل الشبكة تعمل؟', g: 'اعرف عنوان جهازك في الشبكة، ثم تأكد أن البوابة 10.0.0.1 ترد.', tools: ['ping', 'ifconfig'],
      steps: [['اعرض إعدادات شبكتك', 'ifconfig', function (e) { return (e.name === 'ifconfig' || e.name === 'ip') && e.ok; }], ['جرّب الوصول للبوابة 4 مرات', 'ping -c 4 10.0.0.1', function (e) { return e.name === 'ping' && e.ok && (arg(e, '10.0.0.1') || arg(e, 'gateway.cyberdex.test')); }]],
      why: 'ifconfig أو ip a يعرضان عنوانك (10.0.0.2). ping يتأكد أن الجهاز يرد. رد الـ ping يعني أن الاتصال يعمل، لكن عدم الرد لا يعني أن الجهاز غير موجود، فقد يحجبه جدار حماية.' },
    { lv: 1, t: 'من هو lab.cyberdex.test؟', g: 'اعرف عنوان IP الخاص بالنطاق lab.cyberdex.test، ثم تأكد أن الخادم يرد.', tools: ['dig', 'nslookup'],
      steps: [['اعرف عنوان النطاق', 'dig lab.cyberdex.test', function (e) { return (e.name === 'dig' || e.name === 'nslookup') && e.ok && arg(e, 'lab.cyberdex.test'); }], ['تأكد أن الخادم يرد', 'ping -c 2 10.0.0.5', function (e) { return e.name === 'ping' && e.ok && (arg(e, '10.0.0.5') || arg(e, 'lab.cyberdex.test')); }]],
      why: 'DNS يحوّل الاسم إلى عنوان IP: النطاق lab.cyberdex.test يشير إلى 10.0.0.5. dig يعطيك تفاصيل أكثر، وnslookup أبسط. بعد معرفة العنوان تأكد بـ ping أن الجهاز شغّال.' },
    { lv: 1, t: 'اكتشف أجهزة الشبكة', g: 'اكتشف الأجهزة الشغالة في 10.0.0.0/24 بدون فحص منافذها، ثم جرّب الوصول للعنوان المشبوه 10.0.0.99.', tools: ['nmap', 'ping'],
      steps: [['اكتشف الأجهزة الشغالة', 'nmap -sn 10.0.0.0/24', function (e) { return e.name === 'nmap' && e.ok && arg(e, '-sn') && arg(e, '10.0.0.0/24'); }], ['جرّب الوصول للعنوان المشبوه', 'ping -c 2 10.0.0.99', function (e) { return e.name === 'ping' && arg(e, '10.0.0.99'); }]],
      why: 'nmap -sn يكتشف الأجهزة الشغالة بدون فحص منافذها، فوجدت 5 أجهزة. لاحظ أن 10.0.0.99 (مصدر محاولات الدخول) لا يرد على ping. هذا لا يعني أنه غير موجود، فقد يكون مخفيًا أو متوقفًا الآن.' },
    { lv: 1, t: 'افحص منافذ الخادم', g: 'اعرف المنافذ المفتوحة على الخادم 10.0.0.5، ثم اعرف إصدارات الخدمات عليه.', tools: ['nmap'],
      steps: [['افحص منافذ الخادم', 'nmap 10.0.0.5', function (e) { return e.name === 'nmap' && e.ok && !arg(e, '-sV') && !arg(e, '-sn') && (arg(e, '10.0.0.5') || arg(e, 'lab.cyberdex.test')); }], ['اكشف إصدارات الخدمات', 'nmap -sV -p 22,80 10.0.0.5', function (e) { return e.name === 'nmap' && e.ok && arg(e, '-sV') && (arg(e, '10.0.0.5') || arg(e, 'lab.cyberdex.test')); }]],
      why: 'الفحص الأول يعرض المنفذين المفتوحين 22 (SSH) و80 (HTTP). الخيار -sV يكشف الإصدارات: Apache 2.4.41 وOpenSSH 8.2. معرفة الإصدار مهمة لأن الإصدارات القديمة قد تحتوي ثغرات معروفة، فراجع التحديثات الأمنية دائمًا.' },
    { lv: 2, t: 'اقرأ ترويسة الموقع', g: 'اطلب ترويسة الموقع (HTTP headers) من الخادم، ثم اطلب صفحته الرئيسية.', tools: ['curl'],
      steps: [['اطلب الترويسة فقط', 'curl -I http://10.0.0.5', function (e) { return e.name === 'curl' && e.ok && (e.flags.I || arg(e, '--head')) && /10\.0\.0\.(5|1)|lab\.cyberdex\.test/.test(e.args.join(' ')); }], ['اطلب الصفحة الرئيسية', 'curl http://10.0.0.5', function (e) { return e.name === 'curl' && e.ok && !e.flags.I && !arg(e, '--head') && /10\.0\.0\.(5|1)|lab\.cyberdex\.test/.test(e.args.join(' ')); }]],
      why: 'ترويسة Server كشفت اسم البرنامج وإصداره (Apache/2.4.41)، وترويسة X-Powered-By كشفت إصدار PHP. هذه معلومات يستفيد منها المهاجم. دفاعيًا: قلّل هذه الترويسات (ServerTokens Prod وexpose_php=Off).' },
    { lv: 2, t: 'ابحث عن مجلدات مكشوفة', g: 'استخدم قائمة dirs.txt لتجد مجلدات الموقع، ثم افتح المجلد الذي يبدو خطيرًا.', tools: ['gobuster', 'curl'],
      steps: [['خمّن أسماء المجلدات', 'gobuster dir -u http://10.0.0.5 -w dirs.txt', function (e) { return e.name === 'gobuster' && e.ok; }], ['افتح مجلد backup', 'curl http://10.0.0.5/backup', function (e) { return e.name === 'curl' && e.ok && /\/backup/.test(e.args.join(' ')); }]],
      why: 'gobuster جرّب أسماء من القائمة ووجد /admin و/backup وغيرهما. مجلد backup مكشوف وفيه نسخة قاعدة بيانات db_backup.sql! النسخ الاحتياطية يجب ألا تكون على مسار عام. دفاعيًا: انقلها خارج مجلد الويب أو احمها بصلاحيات.' },
    { lv: 3, t: 'فك الترميز', g: 'اقرأ الملف secret.b64 ثم فك ترميزه.', tools: ['base64'],
      steps: [['اعرض الملف كما هو', 'cat secret.b64', function (e) { return e.name === 'cat' && np(e, 'secret.b64'); }], ['فك الترميز', 'base64 -d secret.b64', function (e) { return e.name === 'base64' && e.ok && (e.flags.d || arg(e, '--decode')); }]],
      why: 'Base64 ترميز وليس تشفيرًا: أي شخص يفكّه بأمر واحد. لا تستخدمه لإخفاء كلمات السر. استخدم التشفير الحقيقي، وخزّن كلمات السر بدوال Hash مخصصة.' },
    { lv: 3, t: 'تحقق من سلامة ملف', g: 'احسب بصمة SHA-256 للملفين report.txt وreport_copy.txt، وقارنها بالبصمة المسجلة في notes.txt.', tools: ['sha256sum'],
      steps: [['احسب بصمة report.txt', 'sha256sum report.txt', function (e) { return e.name === 'sha256sum' && e.ok && np(e, 'report.txt'); }], ['احسب بصمة report_copy.txt', 'sha256sum report_copy.txt', function (e) { return e.name === 'sha256sum' && e.ok && np(e, 'report_copy.txt'); }]],
      why: 'دالة Hash تعطي بصمة للملف، ولو تغيّر حرف واحد تتغير البصمة كلها. بصمة report.txt تطابق المسجلة في notes.txt، أما report_copy.txt فبصمته مختلفة، أي أنه عُدّل. هكذا تتأكد من سلامة أي ملف تنزّله.' },
    { lv: 3, t: 'كلمات السر الضعيفة', g: 'اقرأ ملف البصمات hashes.txt، ثم اختبر ضعف كلمات السر باستخدام قائمة wordlist.txt (داخل المختبر فقط).', tools: ['john', 'hashcat'],
      steps: [['اعرض الملف', 'cat hashes.txt', function (e) { return e.name === 'cat' && np(e, 'hashes.txt'); }], ['اختبر الكلمات الشائعة', 'john --wordlist=wordlist.txt hashes.txt', function (e) { return e.name === 'john' && e.ok && !arg(e, '--show'); }]],
      why: 'كلمات السر الضعيفة (password وletmein) كُشفت في أقل من ثانية لأنها في قوائم الكلمات الشائعة، ولأن MD5 سريعة وغير مناسبة لتخزين كلمات السر. دفاعيًا: استخدم كلمات سر طويلة وفريدة، وخزّنها بـ bcrypt أو Argon2 مع salt.' }
  ];
  function np2(e, rel) { return e.paths.indexOf(F + rel) >= 0 || (e.cwd === HOME + '/logs' && e.paths.indexOf(F + rel) >= 0); }

  // ------------------------------------------------------------ state + UI
  var cur = 0, got = [];
  function doneSet() { var S = P() ? P().state() : { sims: {} }; return S.sims || {}; }
  function isDone(i) { return !!doneSet()['lab-' + (i + 1)]; }
  function nDone() { var n = 0; M.forEach(function (m, i) { if (isDone(i)) n++; }); return n; }
  function pick() { for (var i = 0; i < M.length; i++) if (!isDone(i)) return i; return 0; }

  // keep commands / options readable inside right-to-left Arabic text
  function rich(t) { return esc(t).replace(/(-{1,2}[A-Za-z][\w-]*|[A-Za-z0-9][\w.\-\/:]*(?: [A-Za-z0-9][\w.\-\/:]*)*)/g, '<bdi dir="ltr" class="lab-ltr">$1</bdi>'); }
  var el = {};
  function build() {
    root.innerHTML = '<div class="lab-sum" id="labSum"></div>' +
      '<div class="lab-stage"><div class="lab-brief" id="labBrief"></div>' +
      '<div class="lab-term sim"><div class="sim-bar"><span>student@kali-lab (محاكاة)</span><em id="labMeter"></em></div>' +
      '<div class="sim-log" id="labLog" role="log" aria-live="polite" tabindex="0"></div>' +
      '<form class="sim-form" id="labForm" autocomplete="off"><i id="labPs">~$</i><input id="labIn" type="text" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false" dir="ltr" aria-label="اكتب الأمر هنا" placeholder="type a command… (help)"><button class="btn sm primary" type="submit">تشغيل</button></form>' +
      '<div class="lab-keys" id="labKeys"></div></div></div>' +
      '<h2 class="lab-h">كل المهام</h2><div id="labGrid"></div>' +
      '<p class="lab-safe"><b>كل ما في هذه الصفحة محاكاة.</b> الشبكة والملفات والمخرجات وهمية ومكتوبة مسبقًا، ولا يُنفَّذ أو يُتصل بأي شيء حقيقي. تعلّم الأوامر هنا، ثم طبّقها فقط على أجهزتك أو على بيئة مصرّح بها.</p>';
    ['sum', 'brief', 'log', 'form', 'in', 'ps', 'keys', 'grid', 'meter'].forEach(function (k) { el[k] = document.getElementById('lab' + k.charAt(0).toUpperCase() + k.slice(1)); });
    var keys = [['Tab', 'TAB'], ['↑', 'UP'], ['↓', 'DOWN'], ['|', '|'], ['-', '-'], ['/', '/'], ['.', '.'], ['~', '~']];
    el.keys.innerHTML = keys.map(function (k) { return '<button type="button" data-k="' + esc(k[1]) + '" aria-label="' + esc(k[0]) + '">' + esc(k[0]) + '</button>'; }).join('');
  }
  function line(cls, text) { var d = document.createElement('div'); d.className = cls; d.textContent = text; el.log.appendChild(d); el.log.scrollTop = el.log.scrollHeight; return d; }
  function setPs() { el.ps.textContent = shortCwd() + '$'; }

  function drawSum() {
    var n = nDone(), pct = Math.round(n * 100 / M.length);
    el.sum.innerHTML = '<div><b>' + n + '</b> من ' + M.length + ' مهمة منجزة<small>كل مهمة منجزة +5 نقاط</small></div><div class="lab-bar"><i style="width:' + pct + '%"></i></div>';
  }
  function drawBrief(result) {
    var m = M[cur], h = '<span class="lab-lv">' + LV[m.lv] + '</span><h2>' + (cur + 1) + '. ' + esc(m.t) + '</h2><p>' + rich(m.g) + '</p><ol class="lab-steps">';
    m.steps.forEach(function (s, i) { h += '<li class="' + (got[i] ? 'done' : '') + '"><span>' + rich(s[0]) + '</span></li>'; });
    h += '</ol>';
    if (result) {
      h += '<div class="lab-result"><b>✔ أحسنت! أنهيت المهمة' + (result.fresh ? ' (+5 نقاط)' : '') + '</b><p>' + rich(m.why) + '</p><div class="lab-links">' +
        m.tools.map(function (t) { return '<a class="btn sm" href="tools/' + t + '.html">شرح ' + t + ' ←</a>'; }).join('') +
        (cur + 1 < M.length ? '<button class="btn sm primary" type="button" data-go="' + (cur + 1) + '">المهمة التالية</button>' : '') + '</div></div>';
    } else h += '<div class="lab-bact"><button class="btn sm" type="button" id="labHint">💡 تلميح</button></div>';
    el.brief.innerHTML = h;
    el.meter.textContent = got.filter(Boolean).length + ' / ' + m.steps.length + ' خطوات';
  }
  function drawGrid() {
    var h = '';
    LV.forEach(function (name, lv) {
      h += '<h3 class="lab-lvh">' + name + '</h3><div class="lab-grid">';
      M.forEach(function (m, i) { if (m.lv !== lv) return; h += '<button type="button" class="lab-card' + (isDone(i) ? ' done' : '') + (i === cur ? ' on' : '') + '" data-go="' + i + '"><span class="lab-n">' + (i + 1) + '</span><b>' + esc(m.t) + '</b><small>' + (isDone(i) ? '✓ منجزة' : m.steps.length + ' خطوات') + '</small></button>'; });
      h += '</div>';
    });
    el.grid.innerHTML = h;
  }
  function select(i, quiet) {
    cur = i; got = M[i].steps.map(function () { return false; }); cwd = HOME; setPs();
    el.log.innerHTML = '';
    line('sim-n', 'مرحبًا في مختبر CyberDex. الشبكة (10.0.0.0/24) والملفات وهمية، وكل ما تكتبه هنا محاكاة آمنة. اكتب help لعرض الأوامر.');
    line('sim-n', 'المهمة ' + (i + 1) + ': ' + M[i].t + ' — ' + M[i].g);
    drawBrief(); drawGrid(); drawSum();
    if (!quiet) { var b = document.querySelector('.lab-stage'); if (b && b.scrollIntoView) b.scrollIntoView({ block: 'start', behavior: 'smooth' }); }
  }

  function nextStep() { var m = M[cur]; for (var i = 0; i < m.steps.length; i++) if (!got[i]) return i; return -1; }
  function hint() {
    var i = nextStep(); if (i < 0) { line('sim-n', 'أنهيت كل خطوات المهمة. انتقل للمهمة التالية.'); return; }
    var s = M[cur].steps[i]; line('sim-n', 'الخطوة التالية: ' + s[0] + '\nجرّب هذا الأمر: ' + s[1]);
    el.in.value = s[1]; el.in.focus();
  }
  function judge(ev) {
    var m = M[cur], changed = false;
    m.steps.forEach(function (s, i) { if (!got[i] && s[2](ev)) { got[i] = true; changed = true; } });
    if (!changed) return;
    if (got.every(Boolean)) {
      var fresh = !isDone(cur);
      line('sim-ok', '✔ أنهيت المهمة ' + (cur + 1) + ': ' + m.t);
      if (fresh) { try { document.dispatchEvent(new CustomEvent('cdx-sim-done', { detail: { tool: 'lab-' + (cur + 1) } })); } catch (x) { } }
      drawBrief({ fresh: fresh }); setTimeout(function () { drawGrid(); drawSum(); }, 80);
    } else drawBrief();
  }

  // ------------------------------------------------------------ run a command line
  function tok(s) { var t = [], c = '', q = null, h = false; for (var i = 0; i < s.length; i++) { var ch = s[i]; if (q) { if (ch === q) q = null; else c += ch; } else if (ch === '"' || ch === "'") { q = ch; h = true; } else if (/\s/.test(ch)) { if (c || h) { t.push(c); c = ''; h = false; } } else c += ch; } if (c || h) t.push(c); return t; }
  function splitPipe(s) { var p = [], c = '', q = null; for (var i = 0; i < s.length; i++) { var ch = s[i]; if (q) { c += ch; if (ch === q) q = null; } else if (ch === '"' || ch === "'") { q = ch; c += ch; } else if (ch === '|') { p.push(c); c = ''; } else c += ch; } p.push(c); return p; }

  function run(raw) {
    raw = raw.trim(); if (!raw) return;
    var p = document.createElement('div'); p.className = 'sim-l'; p.innerHTML = '<i>' + esc('student@kali-lab:' + shortCwd() + '$') + '</i> '; p.appendChild(document.createTextNode(raw)); el.log.appendChild(p);
    hist.push(raw); hi = hist.length;
    var stages = splitPipe(raw), inp = null, evs = [], errs = [], notes = [], out = '', special = null;
    for (var i = 0; i < stages.length; i++) {
      var t = tok(stages[i]); if (!t.length) continue;
      if (t[0] === 'sudo') { t.shift(); if (!t.length) continue; }
      var name = t[0], args = t.slice(1), cwd0 = cwd, res;
      if (Object.prototype.hasOwnProperty.call(C, name)) res = C[name](args, inp) || {};
      else res = { e: 'bash: ' + name + ': command not found', n: 'هذه محاكاة تدعم أوامر المختبر فقط. اكتب help لعرضها.' };
      if (res.clear) { el.log.innerHTML = ''; return; }
      if (res.mission || res.hint) special = res.mission ? 'mission' : 'hint';
      var fx = fl(args).f, paths = args.filter(function (x) { return x.charAt(0) !== '-'; }).map(function (x) { return resolve(x, cwd0); });
      evs.push({ name: name, args: args, flags: fx, paths: paths, cwd: cwd, ok: !res.e });
      inp = res.o != null ? res.o : '';
      if (i === stages.length - 1) out = inp;
      if (res.e) errs.push(res.e); if (res.n) notes.push(res.n);
    }
    if (out) line('sim-o', out);
    errs.forEach(function (e) { line('sim-x', e); });
    notes.forEach(function (n) { line('sim-n', n); });
    setPs();
    if (special === 'hint') hint();
    else if (special === 'mission') line('sim-n', 'المهمة ' + (cur + 1) + ': ' + M[cur].t + '\n' + M[cur].g);
    evs.forEach(judge);
  }

  // ------------------------------------------------------------ input helpers
  function complete() {
    var v = el.in.value, caret = el.in.selectionStart == null ? v.length : el.in.selectionStart, left = v.slice(0, caret), w = left.match(/(\S*)$/)[1], before = left.slice(0, left.length - w.length), first = !before.trim() || /\|\s*$/.test(before), c;
    if (first) c = Object.keys(C).filter(function (k) { return k.indexOf(w) === 0 && k !== 'mission' || k === w; });
    else { var s = w.lastIndexOf('/'), dp = s >= 0 ? w.slice(0, s + 1) : '', fp = w.slice(s + 1), dir = resolve(dp || '.'); if (!isDir(dir)) return; c = listDir(dir).filter(function (n) { return n.indexOf(fp) === 0; }).map(function (n) { return dp + n + (isDir(resolve(dp + n)) ? '/' : ''); }); }
    if (!c.length) return;
    var rep;
    if (c.length === 1) rep = c[0] + (c[0].slice(-1) === '/' ? '' : ' ');
    else { var pre = c[0]; c.forEach(function (x) { while (x.indexOf(pre) !== 0) pre = pre.slice(0, -1); }); line('sim-o', c.join('  ')); rep = pre; }
    el.in.value = before + rep + v.slice(caret); var pos = (before + rep).length; el.in.setSelectionRange(pos, pos);
  }
  function histMove(d) { if (!hist.length) return; hi = Math.max(0, Math.min(hist.length, hi + d)); el.in.value = hist[hi] || ''; }
  function insert(txt) { var v = el.in.value, a = el.in.selectionStart == null ? v.length : el.in.selectionStart, b = el.in.selectionEnd == null ? a : el.in.selectionEnd; el.in.value = v.slice(0, a) + txt + v.slice(b); var p = a + txt.length; el.in.focus(); el.in.setSelectionRange(p, p); }

  function wire() {
    el.form.addEventListener('submit', function (e) { e.preventDefault(); var v = el.in.value; el.in.value = ''; run(v); });
    el.in.addEventListener('keydown', function (e) {
      if (e.key === 'Tab') { e.preventDefault(); complete(); } else if (e.key === 'ArrowUp') { e.preventDefault(); histMove(-1); } else if (e.key === 'ArrowDown') { e.preventDefault(); histMove(1); }
      else if (e.ctrlKey && e.key.toLowerCase() === 'l') { e.preventDefault(); el.log.innerHTML = ''; }
    });
    el.keys.addEventListener('click', function (e) { var b = e.target.closest('button'); if (!b) return; var k = b.getAttribute('data-k'); if (k === 'TAB') { el.in.focus(); complete(); } else if (k === 'UP') histMove(-1); else if (k === 'DOWN') histMove(1); else insert(k); });
    root.addEventListener('click', function (e) {
      var g = e.target.closest('[data-go]'); if (g) { select(+g.getAttribute('data-go')); return; }
      if (e.target.closest('#labHint')) hint();
    });
    el.log.addEventListener('click', function () { if (!window.getSelection || !String(window.getSelection())) el.in.focus(); });
    document.addEventListener('cdx-progress', function () { drawGrid(); drawSum(); });
    document.addEventListener('cdx-auth', function () { setTimeout(function () { drawGrid(); drawSum(); }, 400); });
  }

  function init() { if (!P()) return setTimeout(init, 100); build(); wire(); select(pick(), true); }
  if (document.readyState === 'complete') init(); else addEventListener('load', init);
})();
